<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Member Registration - APEX FITNESS</title>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body { background: #080808; color: #fff; font-family: 'Inter', sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .login-box { background: #161616; padding: 3rem; border-radius: 16px; width: 100%; max-width: 400px; border: 1px solid rgba(255,255,255,0.08); text-align: center; }
        .login-box h2 { font-family: 'Bebas Neue', sans-serif; font-size: 2.5rem; letter-spacing: 2px; margin-bottom: 1rem; }
        .login-box h2 span { color: #C8F03D; }
        .input-group { margin-bottom: 1.2rem; text-align: left; }
        .input-group label { display: block; font-size: 0.85rem; color: #888; margin-bottom: 0.5rem; }
        .input-group input, .input-group select { width: 100%; padding: 0.8rem; background: #080808; border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 8px; box-sizing: border-box; }
        .input-group input:focus, .input-group select:focus { outline: none; border-color: #C8F03D; }
        .btn { background: #C8F03D; color: #000; padding: 0.8rem; width: 100%; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; transition: opacity 0.2s; margin-top: 1rem; }
        .btn:hover { opacity: 0.8; }
        .error { color: #ff4444; font-size: 0.85rem; margin-bottom: 1rem; }
        .login-link { color: #C8F03D; text-decoration: none; font-size: 0.85rem; }
        .login-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>MEMBER<span>REGISTRATION</span></h2>
        <p style="color: #888; font-size: 0.9rem; margin-bottom: 2rem;">Join APEX and start your journey</p>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="error"><%= request.getAttribute("error") %></div>
        <% } %>

        <form action="${pageContext.request.contextPath}/member-register" method="post">
            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="name" required>
            </div>
            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div class="input-group">
                <label>Phone Number</label>
                <input type="text" name="phone" required>
            </div>
            <div class="input-group">
                <label>Membership Plan</label>
                <select name="planId" required>
                    <option value="FREE_TRIAL">7-Day Free Trial (No Commitment)</option>
                    <c:forEach var="plan" items="${plans}">
                        <option value="${plan.planId}">${plan.planName} - Rs.${plan.price}/mo</option>
                    </c:forEach>
                </select>
            </div>
            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>
            <button type="submit" class="btn">Register</button>
        </form>
        <div style="margin-top: 1.5rem;">
            <a href="${pageContext.request.contextPath}/member-login" class="login-link">Already have an account? Login</a><br><br>
            <a href="${pageContext.request.contextPath}/landing.html" style="color: #888; font-size: 0.85rem; text-decoration: none;">&larr; Back to Website</a>
        </div>
    </div>
</body>
</html>

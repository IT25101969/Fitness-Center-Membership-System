<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Members — FCMS</title>
    <meta name="description" content="Search for fitness center members by name, email, ID, or phone number.">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/static/css/style.css">
    <style>
        /* ── Search Hero ─────────────────────────────────────────── */
        .search-hero {
            background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);
            padding: 3rem 2rem 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        .search-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(ellipse at 60% 40%, rgba(139,92,246,.25) 0%, transparent 70%);
        }
        .search-hero h1 {
            font-size: clamp(1.6rem, 4vw, 2.5rem);
            font-weight: 800;
            color: #fff;
            letter-spacing: 1px;
            position: relative;
        }
        .search-hero p {
            color: rgba(255,255,255,.65);
            position: relative;
            margin-bottom: 0;
        }

        /* ── Search Input Card ───────────────────────────────────── */
        .search-card {
            background: var(--surface, #1e1e2e);
            border: 1px solid rgba(255,255,255,.08);
            border-radius: 1rem;
            padding: 2rem;
            margin: 2rem auto;
            max-width: 700px;
            box-shadow: 0 8px 32px rgba(0,0,0,.3);
        }
        .search-input-group {
            display: flex;
            gap: .75rem;
            align-items: center;
        }
        .search-input-group input {
            flex: 1;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(255,255,255,.12);
            border-radius: .75rem;
            color: #fff;
            padding: .85rem 1.25rem;
            font-size: 1rem;
            transition: border-color .2s, box-shadow .2s;
        }
        .search-input-group input:focus {
            outline: none;
            border-color: var(--accent, #8B5CF6);
            box-shadow: 0 0 0 3px rgba(139,92,246,.2);
            background: rgba(139,92,246,.07);
        }
        .search-input-group input::placeholder { color: rgba(255,255,255,.35); }
        .btn-search {
            background: linear-gradient(135deg, #8B5CF6, #6D28D9);
            border: none;
            border-radius: .75rem;
            color: #fff;
            padding: .85rem 1.75rem;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform .15s, box-shadow .15s;
            white-space: nowrap;
            display: flex;
            align-items: center;
            gap: .5rem;
        }
        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(139,92,246,.4);
        }
        .btn-search:active { transform: translateY(0); }

        /* ── Tips ────────────────────────────────────────────────── */
        .search-tips {
            display: flex;
            gap: .5rem;
            flex-wrap: wrap;
            margin-top: 1rem;
        }
        .tip-chip {
            background: rgba(139,92,246,.15);
            border: 1px solid rgba(139,92,246,.3);
            border-radius: 2rem;
            color: #c4b5fd;
            font-size: .78rem;
            padding: .2rem .75rem;
            cursor: pointer;
            transition: background .15s;
        }
        .tip-chip:hover { background: rgba(139,92,246,.3); }

        /* ── Results Section ─────────────────────────────────────── */
        .results-section {
            max-width: 1100px;
            margin: 0 auto 2rem;
            padding: 0 1.5rem;
        }
        .results-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
            flex-wrap: wrap;
            gap: .5rem;
        }
        .results-count {
            font-size: .9rem;
            color: rgba(255,255,255,.55);
        }
        .results-count strong {
            color: #8B5CF6;
            font-size: 1.1rem;
        }

        /* ── Result Cards ────────────────────────────────────────── */
        .result-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 1rem;
        }
        .result-card {
            background: var(--surface, #1e1e2e);
            border: 1px solid rgba(255,255,255,.07);
            border-radius: .875rem;
            padding: 1.25rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            transition: transform .2s, border-color .2s, box-shadow .2s;
            animation: cardIn .35s ease both;
        }
        .result-card:hover {
            transform: translateY(-3px);
            border-color: rgba(139,92,246,.4);
            box-shadow: 0 8px 24px rgba(139,92,246,.15);
        }
        @keyframes cardIn {
            from { opacity:0; transform: translateY(12px); }
            to   { opacity:1; transform: translateY(0); }
        }
        .result-avatar {
            width: 52px;
            height: 52px;
            border-radius: 50%;
            background: linear-gradient(135deg, #8B5CF6, #6D28D9);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.2rem;
            color: #fff;
            flex-shrink: 0;
            text-transform: uppercase;
        }
        .result-info { flex: 1; min-width: 0; }
        .result-name {
            font-weight: 700;
            font-size: 1rem;
            color: #fff;
            margin-bottom: .15rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .result-email {
            font-size: .8rem;
            color: rgba(255,255,255,.5);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .result-meta {
            display: flex;
            gap: .4rem;
            margin-top: .4rem;
            flex-wrap: wrap;
        }
        .result-actions {
            display: flex;
            flex-direction: column;
            gap: .4rem;
            flex-shrink: 0;
        }
        .btn-result-edit, .btn-result-delete {
            border: none;
            border-radius: .5rem;
            padding: .35rem .75rem;
            font-size: .78rem;
            font-weight: 600;
            cursor: pointer;
            transition: opacity .15s, transform .15s;
            display: flex;
            align-items: center;
            gap: .3rem;
        }
        .btn-result-edit {
            background: rgba(139,92,246,.2);
            color: #c4b5fd;
            text-decoration: none;
        }
        .btn-result-edit:hover { opacity: .8; color: #c4b5fd; }
        .btn-result-delete {
            background: rgba(239,68,68,.15);
            color: #fca5a5;
        }
        .btn-result-delete:hover { opacity: .8; }

        /* ── Empty / Idle States ─────────────────────────────────── */
        .state-box {
            text-align: center;
            padding: 4rem 2rem;
            color: rgba(255,255,255,.4);
        }
        .state-box i { font-size: 3.5rem; display: block; margin-bottom: 1rem; }
        .state-box h3 { color: rgba(255,255,255,.6); font-size: 1.2rem; margin-bottom: .5rem; }

        /* ── File Handling Badge ─────────────────────────────────── */
        .fh-badge {
            display: inline-flex;
            align-items: center;
            gap: .4rem;
            background: rgba(16,185,129,.12);
            border: 1px solid rgba(16,185,129,.3);
            border-radius: 2rem;
            color: #6ee7b7;
            font-size: .75rem;
            padding: .25rem .85rem;
            margin-top: .75rem;
        }
    </style>
</head>
<body>

<jsp:include page="navbar.jsp"/>

<main class="full-main">

    <!-- Hero Banner -->
    <div class="search-hero">
        <h1><i class="bi bi-search me-2"></i>Search Members</h1>
        <p>Find any member by name, email, ID, or phone — reads directly from <code>members.csv</code></p>
        <div class="fh-badge">
            <i class="bi bi-file-earmark-text-fill"></i>
            File Handling: server-side CSV search via <strong>FileBasedMemberService</strong>
        </div>
    </div>

    <!-- Quick Nav -->
    <div class="quick-nav fade-in-delay">
        <a href="${pageContext.request.contextPath}/home"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="${pageContext.request.contextPath}/members"><i class="bi bi-people-fill"></i> All Members</a>
        <a href="${pageContext.request.contextPath}/members/search" class="active"><i class="bi bi-search"></i> Search</a>
        <a href="${pageContext.request.contextPath}/members/new"><i class="bi bi-person-plus-fill"></i> Add Member</a>
    </div>

    <!-- Search Card -->
    <div class="search-card fade-in">
        <form method="get" action="${pageContext.request.contextPath}/members/search" id="searchForm">
            <div class="search-input-group">
                <input type="text"
                       id="searchQuery"
                       name="q"
                       value="${keyword}"
                       placeholder="Search by name, email, ID, or phone…"
                       autocomplete="off"
                       autofocus>
                <button type="submit" class="btn-search" id="searchBtn">
                    <i class="bi bi-search"></i> Search
                </button>
            </div>
            <!-- Quick suggestion chips -->
            <div class="search-tips">
                <span class="text-muted me-1" style="font-size:.78rem;line-height:2;">Try:</span>
                <span class="tip-chip" onclick="fillSearch('John')">John</span>
                <span class="tip-chip" onclick="fillSearch('ACTIVE')">ACTIVE</span>
                <span class="tip-chip" onclick="fillSearch('M001')">M001</span>
                <span class="tip-chip" onclick="fillSearch('PREMIUM')">PREMIUM</span>
                <span class="tip-chip" onclick="fillSearch('gmail')">gmail</span>
            </div>
        </form>
    </div>

    <!-- Results Section -->
    <div class="results-section">

        <!-- Idle State: no query yet -->
        <c:if test="${not hasQuery}">
            <div class="state-box fade-in">
                <i class="bi bi-person-lines-fill"></i>
                <h3>Start your search</h3>
                <p>Enter a name, email address, member ID, or phone number above to find members.</p>
            </div>
        </c:if>

        <!-- Has query results -->
        <c:if test="${hasQuery}">
            <div class="results-header fade-in">
                <div class="results-count">
                    Showing <strong>${resultCount}</strong>
                    result<c:if test="${resultCount != 1}">s</c:if>
                    for &ldquo;<strong style="color:#e2e8f0;">${keyword}</strong>&rdquo;
                    <span style="margin-left:.5rem;color:rgba(255,255,255,.35);font-size:.8rem;">
                        (read from members.csv)
                    </span>
                </div>
                <a href="${pageContext.request.contextPath}/members" class="btn-result-edit"
                   style="border-radius:.5rem;padding:.4rem 1rem;">
                    <i class="bi bi-list-ul"></i> View All
                </a>
            </div>

            <!-- Zero results -->
            <c:if test="${empty results}">
                <div class="state-box fade-in">
                    <i class="bi bi-inbox" style="color:#8B5CF6;"></i>
                    <h3>No members found</h3>
                    <p>No records match &ldquo;<strong>${keyword}</strong>&rdquo;.<br>
                       Try a different name, email, or ID.</p>
                    <a href="${pageContext.request.contextPath}/members/new"
                       class="btn-search" style="display:inline-flex;margin-top:1rem;">
                        <i class="bi bi-person-plus-fill"></i> Register New Member
                    </a>
                </div>
            </c:if>

            <!-- Result Cards Grid -->
            <c:if test="${not empty results}">
                <div class="result-grid">
                    <c:forEach var="m" items="${results}" varStatus="loop">
                        <div class="result-card fade-in" style="animation-delay: ${loop.index * 0.05}s;">

                            <!-- Avatar (first letter of name) -->
                            <div class="result-avatar">
                                ${m.name.substring(0,1)}
                            </div>

                            <!-- Info -->
                            <div class="result-info">
                                <div class="result-name">${m.name}</div>
                                <div class="result-email">${m.email}</div>
                                <div class="result-meta">
                                    <code style="font-size:.72rem;color:#a78bfa;">${m.id}</code>

                                    <!-- Status badge -->
                                    <c:choose>
                                        <c:when test="${m.status == 'ACTIVE'}">
                                            <span class="badge-status badge-active">
                                                <i class="bi bi-circle-fill" style="font-size:.45rem;"></i> Active
                                            </span>
                                        </c:when>
                                        <c:when test="${m.status == 'EXPIRED'}">
                                            <span class="badge-status badge-expired">
                                                <i class="bi bi-circle-fill" style="font-size:.45rem;"></i> Expired
                                            </span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="badge-status badge-inactive">
                                                <i class="bi bi-circle-fill" style="font-size:.45rem;"></i> Inactive
                                            </span>
                                        </c:otherwise>
                                    </c:choose>

                                    <!-- Type badge -->
                                    <c:if test="${m.type == 'PREMIUM'}">
                                        <span class="badge-status badge-premium">
                                            <i class="bi bi-star-fill" style="font-size:.6rem;"></i> Premium
                                        </span>
                                    </c:if>
                                    <c:if test="${m.type == 'TRIAL'}">
                                        <span class="badge-status badge-trial">
                                            <i class="bi bi-clock" style="font-size:.6rem;"></i> Trial
                                        </span>
                                    </c:if>
                                </div>
                                <!-- Plan name -->
                                <div style="font-size:.78rem;color:rgba(255,255,255,.4);margin-top:.25rem;">
                                    <i class="bi bi-card-list"></i>
                                    ${not empty m.planName ? m.planName : m.membershipPlanId}
                                    &nbsp;|&nbsp;
                                    <i class="bi bi-telephone"></i> ${m.phone}
                                </div>
                            </div>

                            <!-- Action buttons -->
                            <div class="result-actions">
                                <a href="${pageContext.request.contextPath}/members/edit?id=${m.id}"
                                   class="btn-result-edit" title="Edit member">
                                    <i class="bi bi-pencil-fill"></i> Edit
                                </a>
                                <button class="btn-result-delete" title="Delete member"
                                        onclick="confirmDelete('${pageContext.request.contextPath}/members/delete?id=${m.id}', '${m.name}')">
                                    <i class="bi bi-trash-fill"></i> Delete
                                </button>
                            </div>
                        </div>
                    </c:forEach>
                </div>
            </c:if>
        </c:if>
    </div>

</main>

<!-- Delete Confirmation Modal (reuse pattern from member-list.jsp) -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--danger);border-radius:var(--radius) var(--radius) 0 0;">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="padding:1.5rem;">
                <p>Are you sure you want to delete <strong id="deleteTargetName"></strong>?</p>
                <p class="text-muted" style="font-size:.85rem;">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmDeleteBtn" class="btn-fcms-danger">
                    <i class="bi bi-trash-fill me-1"></i>Delete Member
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/static/js/fcms.js"></script>
<script>
    /** Fill the search input with a suggestion chip and auto-submit. */
    function fillSearch(value) {
        document.getElementById('searchQuery').value = value;
        document.getElementById('searchForm').submit();
    }

    /** Live highlight of search keywords in result cards. */
    (function highlightResults() {
        const kw = "${keyword}".toLowerCase().trim();
        if (!kw) return;
        document.querySelectorAll('.result-name, .result-email').forEach(el => {
            const original = el.textContent;
            const regex = new RegExp('(' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi');
            el.innerHTML = original.replace(regex,
                '<mark style="background:rgba(139,92,246,.35);color:#e9d5ff;border-radius:2px;padding:0 2px;">$1</mark>');
        });
    })();
</script>
</body>
</html>

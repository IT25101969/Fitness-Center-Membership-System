<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Login — APEX FITNESS</title>
    <meta name="description" content="Sign in to your APEX FITNESS member portal to track your workouts, nutrition, and membership.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --accent: #C8F03D;
            --accent-dark: #a8cc2a;
            --bg: #080808;
            --surface: #111111;
            --surface-2: #1a1a1a;
            --border: rgba(255,255,255,0.07);
            --text: #ffffff;
            --text-muted: rgba(255,255,255,0.45);
            --font-display: 'Bebas Neue', sans-serif;
            --font-body: 'Inter', sans-serif;
        }

        html, body {
            height: 100%;
            background: var(--bg);
            color: var(--text);
            font-family: var(--font-body);
            overflow-x: hidden;
        }

        /* ── CANVAS PARTICLES ── */
        #particles { position: fixed; inset: 0; z-index: 0; pointer-events: none; }

        /* ── SPLIT LAYOUT ── */
        .login-page {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 1fr 1fr;
            position: relative;
            z-index: 1;
        }

        /* ── LEFT PANEL ── */
        .left-panel {
            background: linear-gradient(145deg, #0d0d0d 0%, #111 100%);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 2.5rem 3rem;
            position: relative;
            overflow: hidden;
            border-right: 1px solid var(--border);
        }
        .left-panel::before {
            content: '';
            position: absolute;
            top: -30%;
            left: -20%;
            width: 80%;
            height: 80%;
            background: radial-gradient(ellipse, rgba(200,240,61,0.07) 0%, transparent 70%);
            pointer-events: none;
        }
        .left-panel::after {
            content: '';
            position: absolute;
            bottom: -20%;
            right: -20%;
            width: 60%;
            height: 60%;
            background: radial-gradient(ellipse, rgba(200,240,61,0.04) 0%, transparent 70%);
            pointer-events: none;
        }

        .brand {
            font-family: var(--font-display);
            font-size: 1.6rem;
            letter-spacing: 3px;
            text-decoration: none;
            color: var(--text);
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .brand span { color: var(--accent); }

        .left-hero {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 3rem 0;
            position: relative;
            z-index: 1;
        }

        .left-tag {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(200,240,61,0.08);
            border: 1px solid rgba(200,240,61,0.2);
            color: var(--accent);
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 2px;
            text-transform: uppercase;
            padding: 0.45rem 1rem;
            border-radius: 50px;
            margin-bottom: 2rem;
            width: fit-content;
        }

        .left-title {
            font-family: var(--font-display);
            font-size: clamp(3.5rem, 5vw, 5.5rem);
            line-height: 0.95;
            letter-spacing: 2px;
            margin-bottom: 1.5rem;
        }
        .left-title .accent { color: var(--accent); }

        .left-desc {
            color: var(--text-muted);
            font-size: 0.95rem;
            line-height: 1.7;
            max-width: 380px;
            margin-bottom: 2.5rem;
        }

        .left-features {
            display: flex;
            flex-direction: column;
            gap: 0.85rem;
        }
        .left-feature {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            font-size: 0.875rem;
            color: rgba(255,255,255,0.7);
        }
        .left-feature i {
            color: var(--accent);
            font-size: 1rem;
            flex-shrink: 0;
        }

        .left-footer {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 0.78rem;
            color: var(--text-muted);
        }
        .status-dot {
            width: 8px; height: 8px;
            background: #4ade80;
            border-radius: 50%;
            box-shadow: 0 0 8px rgba(74,222,128,0.6);
            animation: pulse-green 2s ease-in-out infinite;
            flex-shrink: 0;
        }
        @keyframes pulse-green {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(1.3); }
        }

        /* ── RIGHT PANEL ── */
        .right-panel {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            background: var(--bg);
            position: relative;
        }
        .right-panel::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 500px; height: 500px;
            background: radial-gradient(circle, rgba(200,240,61,0.03) 0%, transparent 70%);
            pointer-events: none;
        }

        /* ── LOGIN CARD ── */
        .login-card {
            width: 100%;
            max-width: 420px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 2.5rem;
            position: relative;
            box-shadow: 0 40px 80px rgba(0,0,0,0.5);
        }

        .card-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .card-icon {
            width: 56px; height: 56px;
            background: rgba(200,240,61,0.08);
            border: 1px solid rgba(200,240,61,0.2);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.25rem;
            font-size: 1.4rem;
            color: var(--accent);
        }
        .card-title {
            font-family: var(--font-display);
            font-size: 2rem;
            letter-spacing: 2px;
            margin-bottom: 0.3rem;
        }
        .card-title span { color: var(--accent); }
        .card-subtitle {
            font-size: 0.82rem;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }

        /* ── ALERT ── */
        .alert {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            padding: 0.85rem 1rem;
            border-radius: 12px;
            font-size: 0.83rem;
            margin-bottom: 1.5rem;
        }
        .alert-error {
            background: rgba(255,68,68,0.08);
            border: 1px solid rgba(255,68,68,0.25);
            color: #ff7070;
        }
        .alert-success {
            background: rgba(200,240,61,0.08);
            border: 1px solid rgba(200,240,61,0.25);
            color: var(--accent);
        }

        /* ── FORM FIELDS ── */
        .field {
            margin-bottom: 1.25rem;
        }
        .field label {
            display: block;
            font-size: 0.73rem;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 0.55rem;
        }
        .field-wrap {
            position: relative;
        }
        .field-wrap .field-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255,255,255,0.25);
            font-size: 0.95rem;
            pointer-events: none;
            transition: color 0.2s;
        }
        .field-wrap input {
            width: 100%;
            padding: 0.9rem 1rem 0.9rem 2.75rem;
            background: rgba(255,255,255,0.035);
            border: 1px solid rgba(255,255,255,0.08);
            color: var(--text);
            border-radius: 12px;
            font-family: var(--font-body);
            font-size: 0.9rem;
            transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
            outline: none;
        }
        .field-wrap input::placeholder { color: rgba(255,255,255,0.2); }
        .field-wrap input:focus {
            border-color: var(--accent);
            background: rgba(200,240,61,0.04);
            box-shadow: 0 0 0 3px rgba(200,240,61,0.07);
        }
        .field-wrap input:focus ~ .field-icon,
        .field-wrap:focus-within .field-icon { color: var(--accent); }

        .toggle-pw {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: rgba(255,255,255,0.25);
            cursor: pointer;
            font-size: 1rem;
            padding: 0;
            transition: color 0.2s;
            display: flex;
            align-items: center;
        }
        .toggle-pw:hover { color: rgba(255,255,255,0.6); }

        /* ── SUBMIT BUTTON ── */
        .btn-submit {
            width: 100%;
            background: var(--accent);
            color: #000;
            border: none;
            border-radius: 12px;
            padding: 0.95rem;
            font-family: var(--font-body);
            font-size: 0.9rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s, opacity 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(200,240,61,0.25);
        }
        .btn-submit:active { transform: translateY(0); }

        /* ── DIVIDER ── */
        .divider {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin: 1.5rem 0;
            color: rgba(255,255,255,0.15);
            font-size: 0.75rem;
        }
        .divider::before, .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(255,255,255,0.07);
        }

        /* ── CARD FOOTER ── */
        .card-footer-links {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.75rem;
            margin-top: 1.25rem;
        }
        .card-footer-links a {
            color: var(--text-muted);
            font-size: 0.83rem;
            text-decoration: none;
            transition: color 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
        }
        .card-footer-links a:hover { color: var(--text); }
        .card-footer-links .link-accent {
            color: var(--accent);
            font-weight: 600;
        }
        .card-footer-links .link-accent:hover { color: var(--accent-dark); }

        /* ── BACK LINK ── */
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            color: var(--text-muted);
            font-size: 0.8rem;
            text-decoration: none;
            transition: color 0.2s;
            margin-bottom: 1.5rem;
        }
        .back-link:hover { color: var(--text); }

        /* ── RESPONSIVE ── */
        @media (max-width: 768px) {
            .login-page { grid-template-columns: 1fr; }
            .left-panel { display: none; }
            .right-panel { padding: 1.5rem; min-height: 100vh; }
            .login-card { padding: 2rem 1.5rem; }
        }

        /* ── FLOATING ELEMENTS ── */
        .float-ring {
            position: absolute;
            border-radius: 50%;
            border: 1px solid rgba(200,240,61,0.07);
            animation: float-rotate 20s linear infinite;
            pointer-events: none;
        }
        .float-ring-1 { width: 300px; height: 300px; bottom: 5%; right: -5%; }
        .float-ring-2 { width: 200px; height: 200px; top: 10%; left: 10%; animation-direction: reverse; animation-duration: 15s; }
        @keyframes float-rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>

<canvas id="particles"></canvas>

<div class="login-page">

    <!-- ── LEFT PANEL ── -->
    <div class="left-panel">
        <div class="float-ring float-ring-1"></div>
        <div class="float-ring float-ring-2"></div>

        <a href="${pageContext.request.contextPath}/landing.html" class="brand">APEX<span>FITNESS</span></a>

        <div class="left-hero">
            <div class="left-tag"><i class="bi bi-person-check-fill"></i> APEX Portal</div>
            <h1 class="left-title">WELCOME<br>BACK TO<br><span class="accent">APEX</span></h1>
            <p class="left-desc">Sign in to access your dashboard. Use your member email or admin credentials to continue.</p>
            <div class="left-features">
                <div class="left-feature"><i class="bi bi-graph-up-arrow"></i> Real-time workout & progress tracking</div>
                <div class="left-feature"><i class="bi bi-calendar-check-fill"></i> Class booking & schedule management</div>
                <div class="left-feature"><i class="bi bi-egg-fried"></i> Personalised nutrition & meal plans</div>
                <div class="left-feature"><i class="bi bi-credit-card-fill"></i> Membership & payment overview</div>
            </div>
        </div>

        <div class="left-footer">
            <div class="status-dot"></div>
            <span>APEX FITNESS is currently <strong>Open</strong> · Colombo 00300</span>
        </div>
    </div>

    <!-- ── RIGHT PANEL ── -->
    <div class="right-panel">
        <div style="width:100%;max-width:420px;">

            <a href="${pageContext.request.contextPath}/landing.html" class="back-link">
                <i class="bi bi-arrow-left"></i> Back to website
            </a>

            <div class="login-card">
                <div class="card-header">
                    <div class="card-icon"><i class="bi bi-box-arrow-in-right"></i></div>
                    <h2 class="card-title">SIGN <span>IN</span></h2>
                    <p class="card-subtitle">Member email or admin username</p>
                </div>

                <% if (request.getAttribute("error") != null) { %>
                <div class="alert alert-error">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    <%= request.getAttribute("error") %>
                </div>
                <% } %>

                <% if ("true".equals(request.getParameter("registered"))) { %>
                <div class="alert alert-success">
                    <i class="bi bi-check-circle-fill"></i>
                    Registration successful! Please sign in below.
                </div>
                <% } %>

                <form action="${pageContext.request.contextPath}/member-login" method="post" id="loginForm">
                    <div class="field">
                        <label for="email">Email or Username</label>
                        <div class="field-wrap">
                            <input type="text" id="email" name="email" placeholder="you@example.com or admin" required autocomplete="username">
                            <i class="bi bi-person-fill field-icon"></i>
                        </div>
                    </div>

                    <div class="field">
                        <label for="password">Password</label>
                        <div class="field-wrap">
                            <input type="password" id="password" name="password" placeholder="Enter your password" required autocomplete="current-password">
                            <i class="bi bi-lock-fill field-icon"></i>
                            <button type="button" class="toggle-pw" id="togglePw" aria-label="Toggle password visibility">
                                <i class="bi bi-eye-fill" id="pwIcon"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" class="btn-submit" id="submitBtn">
                        <i class="bi bi-box-arrow-in-right"></i> Sign In
                    </button>
                </form>

                <div class="divider">or</div>

                <div class="card-footer-links">
                    <a href="${pageContext.request.contextPath}/member-register" class="link-accent">
                        <i class="bi bi-person-plus-fill"></i> Don't have an account? Register free
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    /* Particle background */
    (function () {
        const canvas = document.getElementById('particles');
        const ctx = canvas.getContext('2d');
        let W, H, pts = [];
        function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        for (let i = 0; i < 60; i++) pts.push({ x: Math.random()*W, y: Math.random()*H, r: Math.random()*1.5+0.5, vx: (Math.random()-.5)*.15, vy: (Math.random()-.5)*.15, a: Math.random()*.3+.05, p: Math.random()*Math.PI*2 });
        function draw() {
            ctx.clearRect(0,0,W,H);
            pts.forEach(p => {
                p.p += .015; p.x += p.vx; p.y += p.vy;
                if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
                if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
                ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
                ctx.fillStyle = `rgba(200,240,61,${p.a*(0.6+0.4*Math.sin(p.p))})`; ctx.fill();
            });
            requestAnimationFrame(draw);
        }
        draw();
    })();

    /* Password toggle */
    const togglePw = document.getElementById('togglePw');
    const pwInput  = document.getElementById('password');
    const pwIcon   = document.getElementById('pwIcon');
    togglePw?.addEventListener('click', () => {
        const show = pwInput.type === 'password';
        pwInput.type = show ? 'text' : 'password';
        pwIcon.className = show ? 'bi bi-eye-slash-fill' : 'bi bi-eye-fill';
    });

    /* Submit button loading state */
    document.getElementById('loginForm')?.addEventListener('submit', function() {
        const btn = document.getElementById('submitBtn');
        btn.innerHTML = '<i class="bi bi-arrow-clockwise" style="animation:spin .8s linear infinite"></i> Signing in…';
        btn.disabled = true;
    });

    /* Inline spin keyframe */
    const style = document.createElement('style');
    style.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
    document.head.appendChild(style);
</script>
</body>
</html>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Member Management — APEX FITNESS</title>
<meta name="description" content="Manage all fitness center members.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<c:set var="pageTitle" value="Member Management"/>
<style>
:root{--accent:#C8F03D;--accent-rgb:200,240,61;--black:#0a0a0a;--card:#111113;--card2:#161618;--border:rgba(255,255,255,.07);--gray:rgba(255,255,255,.45);--font-display:'Bebas Neue',sans-serif;--font-body:'Inter',sans-serif;--radius:14px}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--black);color:#fff;font-family:var(--font-body)}

/* Layout */
.mm-page{display:flex;min-height:100vh}
.mm-sb{width:260px;background:var(--card);border-right:1px solid var(--border);padding:1.5rem 0;flex-shrink:0;position:sticky;top:0;height:100vh;overflow-y:auto;display:flex;flex-direction:column}
.mm-main{flex:1;padding:2rem 2.5rem;overflow-y:auto}
.mm-logo{font-family:var(--font-display);font-size:1.5rem;padding:0 1.5rem 1.5rem;letter-spacing:2px;border-bottom:1px solid var(--border);margin-bottom:1rem}.mm-logo span{color:var(--accent)}
.mm-sb-sec{padding:0 .8rem;margin-bottom:1rem}
.mm-sb-lbl{font-size:.6rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--gray);padding:.5rem .7rem}
.mm-sb-item{display:flex;align-items:center;gap:.6rem;padding:.55rem .7rem;border-radius:8px;font-size:.82rem;font-weight:500;color:rgba(255,255,255,.55);text-decoration:none;transition:all .2s;margin-bottom:.1rem}
.mm-sb-item:hover{background:rgba(255,255,255,.04);color:#fff}.mm-sb-item.active{background:rgba(var(--accent-rgb),.1);color:var(--accent);font-weight:700}
.mm-sb-item i{font-size:1rem;width:20px;text-align:center}

/* Header */
.mm-header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:2rem}
.mm-header h1{font-family:var(--font-display);font-size:2rem;letter-spacing:3px;margin:0}.mm-header h1 span{color:var(--accent)}
.mm-header p{color:var(--gray);font-size:.8rem;margin:.3rem 0 0}
.mm-header-actions{display:flex;gap:.5rem}
.mm-btn{display:flex;align-items:center;gap:.4rem;padding:.55rem 1rem;border-radius:10px;border:none;font-size:.78rem;font-weight:700;cursor:pointer;transition:all .2s;text-decoration:none;letter-spacing:.3px}
.mm-btn-primary{background:var(--accent);color:#000}.mm-btn-primary:hover{box-shadow:0 4px 20px rgba(200,240,61,.3);transform:scale(1.03);color:#000}
.mm-btn-outline{background:none;border:1px solid rgba(var(--accent-rgb),.3);color:var(--accent)}.mm-btn-outline:hover{background:rgba(var(--accent-rgb),.1);color:var(--accent)}
.mm-btn-ghost{background:none;border:1px solid var(--border);color:var(--gray)}.mm-btn-ghost:hover{border-color:rgba(139,92,246,.4);color:#c4b5fd}

/* Stats */
.mm-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.8rem}
.mm-stat{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:1rem;text-align:center;position:relative;overflow:hidden}
.mm-stat::after{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--accent),transparent);opacity:.2}
.mm-stat-val{font-family:var(--font-display);font-size:1.7rem;color:var(--accent)}.mm-stat-lbl{font-size:.6rem;color:var(--gray);text-transform:uppercase;letter-spacing:1.5px;margin-top:.1rem}

/* Flash */
.mm-flash{padding:.7rem 1.2rem;border-radius:10px;font-size:.8rem;font-weight:600;margin-bottom:1.5rem;display:flex;align-items:center;gap:.5rem;animation:fadeIn .3s ease}
.mm-flash-ok{background:rgba(52,211,153,.1);border:1px solid rgba(52,211,153,.25);color:#34d399}
.mm-flash-err{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.25);color:#f87171}

/* Search & Filter */
.mm-filters{display:flex;gap:.6rem;align-items:center;flex-wrap:wrap;margin-bottom:1.2rem}
.mm-search-wrap{flex:1;min-width:220px;position:relative}
.mm-search-wrap i{position:absolute;left:.8rem;top:50%;transform:translateY(-50%);color:var(--gray);font-size:.85rem}
.mm-search{width:100%;padding:.6rem .8rem .6rem 2.2rem;border-radius:10px;border:1px solid var(--border);background:rgba(255,255,255,.04);color:#fff;font-size:.82rem;font-family:var(--font-body);outline:none}.mm-search:focus{border-color:rgba(var(--accent-rgb),.4)}
.mm-select{padding:.55rem .8rem;border-radius:10px;border:1px solid var(--border);background:var(--card);color:#fff;font-size:.78rem;font-family:var(--font-body);outline:none;cursor:pointer;min-width:140px}.mm-select:focus{border-color:rgba(var(--accent-rgb),.4)}

/* Table */
.mm-table-wrap{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.mm-table-header{display:flex;align-items:center;justify-content:space-between;padding:.8rem 1.2rem;border-bottom:1px solid var(--border);background:rgba(255,255,255,.02)}
.mm-table-title{font-weight:700;font-size:.9rem;display:flex;align-items:center;gap:.5rem}.mm-table-title i{color:var(--accent)}
.mm-table-badge{padding:.2rem .6rem;border-radius:20px;font-size:.65rem;font-weight:700;background:rgba(var(--accent-rgb),.08);color:var(--accent);border:1px solid rgba(var(--accent-rgb),.15)}
.mm-tbl{width:100%;border-collapse:collapse}
.mm-tbl th{font-size:.6rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--gray);padding:.6rem 1rem;border-bottom:1px solid var(--border);text-align:left;white-space:nowrap}
.mm-tbl td{padding:.65rem 1rem;border-bottom:1px solid var(--border);font-size:.82rem;vertical-align:middle}
.mm-tbl tr:last-child td{border-bottom:none}
.mm-tbl tr:hover td{background:rgba(255,255,255,.015)}
.mm-tbl .mm-id{color:var(--accent);font-family:monospace;font-size:.75rem;font-weight:700}
.mm-avatar{width:32px;height:32px;border-radius:8px;background:linear-gradient(135deg,rgba(var(--accent-rgb),.2),rgba(var(--accent-rgb),.05));display:inline-flex;align-items:center;justify-content:center;font-weight:800;color:var(--accent);font-size:.75rem;border:1px solid rgba(var(--accent-rgb),.15);flex-shrink:0}
.mm-name-cell{display:flex;align-items:center;gap:.5rem}
.mm-name{font-weight:600;font-size:.82rem}
.mm-badge{display:inline-flex;align-items:center;gap:.25rem;padding:.15rem .5rem;border-radius:20px;font-size:.6rem;font-weight:700;letter-spacing:.5px;text-transform:uppercase;white-space:nowrap}
.mm-badge-plan{border:1px solid}.mm-badge-standard{background:rgba(var(--accent-rgb),.08);color:var(--accent);border-color:rgba(var(--accent-rgb),.2)}.mm-badge-premium{background:rgba(251,191,36,.08);color:#fbbf24;border-color:rgba(251,191,36,.2)}.mm-badge-basic{background:rgba(96,165,250,.08);color:#60a5fa;border-color:rgba(96,165,250,.2)}.mm-badge-trial{background:rgba(167,139,250,.08);color:#a78bfa;border-color:rgba(167,139,250,.2)}
.mm-badge-active{background:rgba(52,211,153,.08);color:#34d399;border:1px solid rgba(52,211,153,.2)}.mm-badge-inactive{background:rgba(248,113,113,.08);color:#f87171;border:1px solid rgba(248,113,113,.2)}.mm-badge-expired{background:rgba(251,191,36,.08);color:#fbbf24;border:1px solid rgba(251,191,36,.2)}
.mm-actions{display:flex;gap:.3rem;justify-content:center}
.mm-actions a,.mm-actions button{background:none;border:1px solid var(--border);border-radius:6px;color:var(--gray);font-size:.7rem;padding:.25rem .45rem;cursor:pointer;transition:all .2s;text-decoration:none;display:flex;align-items:center}
.mm-actions a:hover{border-color:var(--accent);color:var(--accent)}.mm-actions button:hover{border-color:#f87171;color:#f87171}
.mm-empty{text-align:center;padding:3rem;color:var(--gray)}.mm-empty i{font-size:2.5rem;display:block;margin-bottom:.8rem;opacity:.25}
.mm-pagination{display:flex;align-items:center;justify-content:center;gap:.3rem;padding:.8rem;border-top:1px solid var(--border)}

/* Modal */
.modal-content{background:var(--card)!important;border:1px solid var(--border)!important;color:#fff}
.modal-header{background:rgba(255,255,255,.03)!important;border-bottom:1px solid var(--border)!important;color:#fff!important}.modal-header .btn-close{filter:invert(1)}
.modal-footer{border-top:1px solid var(--border)!important}

@media(max-width:1024px){.mm-sb{display:none}.mm-main{padding:1.5rem}.mm-stats{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.mm-header{flex-direction:column;align-items:flex-start}.mm-filters{flex-direction:column}}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="mm-page">
<aside class="mm-sb">
  <div class="mm-logo">APEX<span>FITNESS</span></div>
  <div class="mm-sb-sec">
    <div class="mm-sb-lbl">Navigation</div>
    <a href="${pageContext.request.contextPath}/home" class="mm-sb-item"><i class="bi bi-speedometer2"></i> Dashboard</a>
    <a href="${pageContext.request.contextPath}/members" class="mm-sb-item active"><i class="bi bi-people-fill"></i> All Members</a>
    <a href="${pageContext.request.contextPath}/members/new" class="mm-sb-item"><i class="bi bi-person-plus-fill"></i> Add Member</a>
    <a href="${pageContext.request.contextPath}/members/search" class="mm-sb-item"><i class="bi bi-search"></i> Advanced Search</a>
  </div>
  <div class="mm-sb-sec">
    <div class="mm-sb-lbl">Management</div>
    <a href="${pageContext.request.contextPath}/home#sec-plans" class="mm-sb-item"><i class="bi bi-card-checklist"></i> Plans</a>
    <a href="${pageContext.request.contextPath}/home#sec-classes" class="mm-sb-item"><i class="bi bi-calendar3"></i> Classes</a>
    <a href="${pageContext.request.contextPath}/home#sec-trainers" class="mm-sb-item"><i class="bi bi-person-badge-fill"></i> Trainers</a>
    <a href="${pageContext.request.contextPath}/home#sec-exercises" class="mm-sb-item"><i class="bi bi-activity"></i> Exercises</a>
    <a href="${pageContext.request.contextPath}/home#sec-supplements" class="mm-sb-item"><i class="bi bi-capsule"></i> Supplements</a>
  </div>
  <div class="mm-sb-sec" style="margin-top:auto;padding-top:1rem;border-top:1px solid var(--border)">
    <a href="${pageContext.request.contextPath}/data/members.csv" class="mm-sb-item" download><i class="bi bi-download"></i> Export CSV</a>
    <a href="${pageContext.request.contextPath}/landing.html" class="mm-sb-item"><i class="bi bi-globe2"></i> View Website</a>
  </div>
</aside>

<div class="mm-main">
  <!-- Header -->
  <div class="mm-header" style="animation:fadeIn .4s ease">
    <div><h1>MEMBER <span>MANAGEMENT</span></h1><p><i class="bi bi-info-circle"></i> View, search, and manage all registered members</p></div>
    <div class="mm-header-actions">
      <a href="${pageContext.request.contextPath}/data/members.csv" class="mm-btn mm-btn-ghost" download><i class="bi bi-download"></i> Export CSV</a>
      <a href="${pageContext.request.contextPath}/members/search" class="mm-btn mm-btn-outline"><i class="bi bi-search"></i> Search</a>
      <a href="${pageContext.request.contextPath}/members/new" class="mm-btn mm-btn-primary"><i class="bi bi-person-plus-fill"></i> Add Member</a>
    </div>
  </div>

  <!-- Flash -->
  <c:if test="${param.msg == 'created'}"><div class="mm-flash mm-flash-ok"><i class="bi bi-check-circle-fill"></i> Member created successfully!</div></c:if>
  <c:if test="${param.msg == 'updated'}"><div class="mm-flash mm-flash-ok"><i class="bi bi-check-circle-fill"></i> Member updated successfully!</div></c:if>
  <c:if test="${param.msg == 'deleted'}"><div class="mm-flash mm-flash-err"><i class="bi bi-trash-fill"></i> Member deleted.</div></c:if>

  <!-- Stats -->
  <c:set var="activeCount" value="0"/><c:set var="premCount" value="0"/><c:set var="trialCount" value="0"/>
  <c:forEach var="m" items="${members}">
    <c:if test="${m.status == 'ACTIVE'}"><c:set var="activeCount" value="${activeCount + 1}"/></c:if>
    <c:if test="${m.type == 'PREMIUM'}"><c:set var="premCount" value="${premCount + 1}"/></c:if>
    <c:if test="${m.type == 'TRIAL'}"><c:set var="trialCount" value="${trialCount + 1}"/></c:if>
  </c:forEach>
  <div class="mm-stats" style="animation:fadeIn .45s ease">
    <div class="mm-stat"><div class="mm-stat-val">${fn:length(members)}</div><div class="mm-stat-lbl">Total Members</div></div>
    <div class="mm-stat"><div class="mm-stat-val" style="color:#34d399">${activeCount}</div><div class="mm-stat-lbl">Active</div></div>
    <div class="mm-stat"><div class="mm-stat-val" style="color:#fbbf24">${premCount}</div><div class="mm-stat-lbl">Premium</div></div>
    <div class="mm-stat"><div class="mm-stat-val" style="color:#a78bfa">${trialCount}</div><div class="mm-stat-lbl">Trial</div></div>
  </div>

  <!-- Filters -->
  <div class="mm-filters" style="animation:fadeIn .5s ease">
    <div class="mm-search-wrap"><i class="bi bi-search"></i><input type="text" class="mm-search" id="tableSearch" placeholder="Search by name, email, ID…"></div>
    <select class="mm-select" id="statusFilter"><option value="">All Statuses</option><option value="active">Active</option><option value="inactive">Inactive</option><option value="expired">Expired</option></select>
    <select class="mm-select" id="planFilter"><option value="">All Plans</option><option value="basic">Basic</option><option value="standard">Standard</option><option value="premium">Premium</option><option value="trial">Trial</option></select>
  </div>

  <!-- Table -->
  <div class="mm-table-wrap" style="animation:fadeIn .55s ease">
    <div class="mm-table-header">
      <div class="mm-table-title"><i class="bi bi-people-fill"></i> Members Registry</div>
      <span class="mm-table-badge">${fn:length(members)} member(s)</span>
    </div>
    <div style="overflow-x:auto">
    <table class="mm-tbl">
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Plan</th><th>Join Date</th><th>Type</th><th>Status</th><th style="text-align:center">Actions</th></tr></thead>
      <tbody id="memberTableBody">
        <c:forEach var="m" items="${members}" varStatus="st">
          <tr style="animation:fadeIn .3s ease ${st.index * 0.03}s both" data-status="${fn:toLowerCase(m.status)}" data-plan="${fn:toLowerCase(m.type)}">
            <td><span class="mm-id">${m.id}</span></td>
            <td><div class="mm-name-cell"><div class="mm-avatar">${m.name.substring(0,1)}</div><span class="mm-name">${m.name}</span></div></td>
            <td style="color:var(--gray);font-size:.8rem">${m.email}</td>
            <td style="font-size:.8rem">${m.phone}</td>
            <td><span class="mm-badge mm-badge-plan mm-badge-${fn:toLowerCase(m.type)}">${m.planName}</span></td>
            <td style="font-size:.78rem;color:var(--gray)">${m.joinDate}</td>
            <td><c:choose>
              <c:when test="${m.type == 'PREMIUM'}"><span class="mm-badge mm-badge-premium"><i class="bi bi-gem" style="font-size:.5rem"></i> Premium</span></c:when>
              <c:when test="${m.type == 'TRIAL'}"><span class="mm-badge mm-badge-trial"><i class="bi bi-clock" style="font-size:.5rem"></i> Trial</span></c:when>
              <c:otherwise><span class="mm-badge mm-badge-standard">Standard</span></c:otherwise>
            </c:choose></td>
            <td><c:choose>
              <c:when test="${m.status == 'ACTIVE'}"><span class="mm-badge mm-badge-active"><i class="bi bi-circle-fill" style="font-size:.35rem"></i> Active</span></c:when>
              <c:when test="${m.status == 'EXPIRED'}"><span class="mm-badge mm-badge-expired"><i class="bi bi-circle-fill" style="font-size:.35rem"></i> Expired</span></c:when>
              <c:otherwise><span class="mm-badge mm-badge-inactive"><i class="bi bi-circle-fill" style="font-size:.35rem"></i> Inactive</span></c:otherwise>
            </c:choose></td>
            <td><div class="mm-actions">
              <a href="${pageContext.request.contextPath}/members/edit?id=${m.id}" title="Edit"><i class="bi bi-pencil"></i></a>
              <button title="Delete" onclick="confirmDelete('${pageContext.request.contextPath}/members/delete?id=${m.id}','${m.name}')"><i class="bi bi-trash3"></i></button>
            </div></td>
          </tr>
        </c:forEach>
        <c:if test="${empty members}">
          <tr><td colspan="9"><div class="mm-empty"><i class="bi bi-inbox"></i><div style="font-size:1rem;font-weight:600;margin-bottom:.3rem">No Members Found</div><div style="font-size:.8rem"><a href="${pageContext.request.contextPath}/members/new" style="color:var(--accent)">Add the first member</a></div></div></td></tr>
        </c:if>
      </tbody>
    </table>
    </div>
  </div>
</div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content" style="border-radius:var(--radius)">
  <div class="modal-header" style="background:rgba(248,113,113,.1)!important"><h5 class="modal-title" style="font-family:var(--font-display);letter-spacing:2px"><i class="bi bi-exclamation-triangle-fill me-2" style="color:#f87171"></i>DELETE MEMBER</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body" style="padding:1.5rem;text-align:center"><p style="font-size:.9rem">Are you sure you want to delete <strong id="deleteTargetName" style="color:var(--accent)"></strong>?</p><p style="color:var(--gray);font-size:.8rem">This action cannot be undone.</p></div>
  <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="button" id="confirmDeleteBtn" style="padding:.5rem 1.2rem;border-radius:8px;border:none;background:#f87171;color:#000;font-weight:700;cursor:pointer"><i class="bi bi-trash3 me-1"></i>Delete Member</button></div>
</div></div></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function confirmDelete(url,name){
  document.getElementById('deleteTargetName').textContent=name;
  document.getElementById('confirmDeleteBtn').onclick=function(){window.location.href=url;};
  new bootstrap.Modal(document.getElementById('deleteModal')).show();
}
// Search & filter
var searchInput=document.getElementById('tableSearch');
var statusFilter=document.getElementById('statusFilter');
var planFilter=document.getElementById('planFilter');
function filterTable(){
  var q=(searchInput.value||'').toLowerCase();
  var sf=(statusFilter.value||'').toLowerCase();
  var pf=(planFilter.value||'').toLowerCase();
  var rows=document.querySelectorAll('#memberTableBody tr[data-status]');
  var shown=0;
  rows.forEach(function(r){
    var text=r.textContent.toLowerCase();
    var matchQ=!q||text.indexOf(q)>=0;
    var matchS=!sf||r.getAttribute('data-status')===sf;
    var matchP=!pf||r.getAttribute('data-plan')===pf;
    r.style.display=(matchQ&&matchS&&matchP)?'':'none';
    if(matchQ&&matchS&&matchP)shown++;
  });
}
if(searchInput)searchInput.addEventListener('input',filterTable);
if(statusFilter)statusFilter.addEventListener('change',filterTable);
if(planFilter)planFilter.addEventListener('change',filterTable);
setTimeout(function(){document.querySelectorAll('.mm-flash').forEach(function(f){f.style.opacity='0';setTimeout(function(){f.remove()},300)})},4000);
</script>
</body>
</html>

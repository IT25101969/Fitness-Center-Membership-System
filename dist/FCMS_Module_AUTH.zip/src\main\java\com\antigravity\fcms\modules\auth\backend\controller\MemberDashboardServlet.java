package com.antigravity.fcms.modules.auth.backend.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/member-dashboard")
public class MemberDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        if (session == null || !"member".equals(session.getAttribute("role"))) {
            resp.sendRedirect(req.getContextPath() + "/member-login");
            return;
        }
        req.getRequestDispatcher("/WEB-INF/views/member-dashboard.jsp").forward(req, resp);
    }
}

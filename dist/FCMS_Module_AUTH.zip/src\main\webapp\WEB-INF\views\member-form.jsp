<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${isEdit ? 'Edit Member' : 'Register Member'} — FCMS</title>
    <meta name="description" content="Register a new fitness center member or edit an existing member's profile.">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/static/css/style.css">
    <c:set var="pageTitle" value="${isEdit ? 'Edit Member' : 'Add Member'}"/>
</head>
<body>

<jsp:include page="navbar.jsp"/>

<main class="full-main">

    <!-- Banner -->
    <div class="page-banner fade-in">
        <img src="${pageContext.request.contextPath}/static/images/trainer.png" alt="" class="page-banner-bg">
        <div class="page-banner-overlay"></div>
        <div class="page-banner-content">
            <div>
                <h1 class="page-banner-title">
                    <i class="bi bi-person-${isEdit ? 'gear' : 'plus-fill'} me-2"></i>
                    ${isEdit ? 'EDIT MEMBER' : 'REGISTER NEW MEMBER'}
                </h1>
                <p class="page-banner-sub">${isEdit ? 'Update member profile details' : 'Fill in the details to register a new member'}</p>
            </div>
            <a href="${pageContext.request.contextPath}/members" class="btn-fcms-primary" style="background:transparent;border:1px solid var(--accent);color:var(--accent);">
                <i class="bi bi-arrow-left"></i> Back to Members
            </a>
        </div>
    </div>

    <!-- Quick Nav -->
    <div class="quick-nav fade-in-delay">
        <a href="${pageContext.request.contextPath}/home"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a href="${pageContext.request.contextPath}/members"><i class="bi bi-people-fill"></i> Members</a>
        <a href="${pageContext.request.contextPath}/members/new" class="active"><i class="bi bi-person-plus-fill"></i> Add Member</a>
        <a href="${pageContext.request.contextPath}/plans"><i class="bi bi-card-list"></i> Plans</a>
    </div>

    <!-- Server-side error alert -->
    <c:if test="${not empty error}">
        <div class="fcms-alert fcms-alert-danger">
            <i class="bi bi-exclamation-triangle-fill"></i> ${error}
        </div>
    </c:if>

    <form id="memberForm" method="post"
          action="${pageContext.request.contextPath}/members/${isEdit ? 'update' : 'create'}"
          novalidate>

        <c:if test="${isEdit}">
            <input type="hidden" name="id" value="${member.id}">
        </c:if>

        <!-- Section 1: Personal Info -->
        <div class="fcms-form-section">
            <p class="form-section-title"><i class="bi bi-person-vcard me-2"></i>Personal Information</p>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="name">Full Name <span style="color:var(--danger)">*</span></label>
                    <input type="text" id="name" name="name" class="form-control" required minlength="2"
                           placeholder="e.g. John Doe"
                           value="${not empty member ? member.name : (not empty formData ? formData.name : '')}">
                    <div class="invalid-feedback">Full name is required (min. 2 characters).</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="email">Email Address <span style="color:var(--danger)">*</span></label>
                    <input type="email" id="email" name="email" class="form-control" required
                           placeholder="e.g. john@example.com"
                           value="${not empty member ? member.email : (not empty formData ? formData.email : '')}">
                    <div class="invalid-feedback">A valid email address is required.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="phone">Phone Number <span style="color:var(--danger)">*</span></label>
                    <input type="tel" id="phone" name="phone" class="form-control" required
                           pattern="[0-9]{10}" placeholder="10-digit number"
                           value="${not empty member ? member.phone : (not empty formData ? formData.phone : '')}">
                    <div class="invalid-feedback">Phone must be exactly 10 digits.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="joinDate">Start Date</label>
                    <input type="date" id="joinDate" name="joinDate" class="form-control"
                           value="${not empty member ? member.joinDate : ''}">
                </div>
            </div>
        </div>

        <!-- Section 2: Membership -->
        <div class="fcms-form-section">
            <p class="form-section-title"><i class="bi bi-card-list me-2"></i>Membership Details</p>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="planId">Membership Plan <span style="color:var(--danger)">*</span></label>
                    <select id="planId" name="planId" class="form-select" required>
                        <option value="">— Select a Plan —</option>
                        <c:forEach var="plan" items="${plans}">
                            <option value="${plan.planId}"
                                ${(not empty member && member.membershipPlanId == plan.planId) ||
                                  (not empty formData && formData.planId == plan.planId) ? 'selected' : ''}>
                                ${plan.planName} — Rs.<fmt:formatNumber value="${plan.price}" pattern="#,##0"/>
                            </option>
                        </c:forEach>
                    </select>
                    <div class="invalid-feedback">Please select a membership plan.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="status">Membership Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="ACTIVE" ${(not empty member && member.status == 'ACTIVE') || empty member ? 'selected' : ''}>Active</option>
                        <option value="INACTIVE" ${not empty member && member.status == 'INACTIVE' ? 'selected' : ''}>Inactive</option>
                        <option value="EXPIRED" ${not empty member && member.status == 'EXPIRED' ? 'selected' : ''}>Expired</option>
                    </select>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Member Type <span style="color:var(--danger)">*</span></label>
                    <div style="display:flex;gap:1.5rem;margin-top:.25rem;">
                        <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;">
                            <input type="radio" name="type" value="STANDARD" id="typeStandard"
                                   ${(not empty member && member.type == 'PREMIUM') ? '' : 'checked'}>
                            <span style="font-size:.9rem;font-weight:500;">Standard Member</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;">
                            <input type="radio" name="type" value="PREMIUM" id="typePremium"
                                   ${not empty member && member.type == 'PREMIUM' ? 'checked' : ''}>
                            <span style="font-size:.9rem;font-weight:500;">
                                <i class="bi bi-star-fill" style="color:#8B5CF6;"></i> Premium Member
                            </span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 3: Premium Fields (hidden by default) -->
        <div class="fcms-form-section" id="premiumSection"
             style="display:${not empty member && member.type == 'PREMIUM' ? 'block' : 'none'};">
            <p class="form-section-title" style="color:#8B5CF6;">
                <i class="bi bi-star-fill me-2"></i>Premium Member Details
            </p>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="personalTrainerId">Personal Trainer ID</label>
                    <input type="text" id="personalTrainerId" name="personalTrainerId" class="form-control"
                           placeholder="e.g. T001">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="lockerNumber">Locker Number</label>
                    <input type="number" id="lockerNumber" name="lockerNumber" class="form-control"
                           placeholder="e.g. 42" min="1" max="999">
                </div>
            </div>
        </div>

        <!-- Section 4: Emergency Contact -->
        <div class="fcms-form-section">
            <p class="form-section-title"><i class="bi bi-telephone-fill me-2"></i>Emergency Contact & Notes</p>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label" for="emergencyContact">Emergency Contact Name</label>
                    <input type="text" id="emergencyContact" name="emergencyContact" class="form-control"
                           placeholder="Contact full name">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="emergencyPhone">Emergency Contact Phone</label>
                    <input type="tel" id="emergencyPhone" name="emergencyPhone" class="form-control"
                           placeholder="10-digit phone" pattern="[0-9]{10}">
                </div>
                <div class="col-12">
                    <label class="form-label" for="medicalNotes">Medical Notes</label>
                    <textarea id="medicalNotes" name="medicalNotes" class="form-control" rows="3"
                              placeholder="Any relevant medical conditions or notes…"></textarea>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div style="display:flex;gap:.75rem;justify-content:flex-end;margin-top:1rem;">
            <a href="${pageContext.request.contextPath}/members" class="btn btn-outline-secondary">
                Cancel
            </a>
            <button type="submit" class="btn-fcms-primary" id="submitMemberBtn">
                <i class="bi bi-${isEdit ? 'floppy-fill' : 'person-plus-fill'}"></i>
                ${isEdit ? 'Save Changes' : 'Register Member'}
            </button>
        </div>
    </form>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="${pageContext.request.contextPath}/static/js/fcms.js"></script>
</body>
</html>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Member Portal — APEX FITNESS</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="${pageContext.request.contextPath}/static/css/member-portal.css?t=<%= new java.util.Date().getTime() %>">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>window._ctx = '${pageContext.request.contextPath}';</script>
<script>
/* Inline showSec — always available regardless of external JS cache */
function showSec(id, btn) {
  document.querySelectorAll('.mp-sec').forEach(function(s) { s.classList.remove('active'); });
  var target = document.getElementById('sec-' + id);
  if (target) target.classList.add('active');
  document.querySelectorAll('.mp-side .si').forEach(function(b) { b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
  if (id === 'checkin' && typeof renderCalendar === 'function') renderCalendar();
  if (id === 'achieve' && typeof animateBadges === 'function') animateBadges();
  if (id === 'overview' && typeof animateRings === 'function') animateRings();
  if (id === 'exercise' && typeof ex2LoadServerImages === 'function') ex2LoadServerImages(typeof ex2Draw === 'function' ? ex2Draw : null);
}
window.showSec = showSec;

/* Nav dropdown toggle */
function toggleNavDropdown() {
  var dd = document.getElementById('navDropdown');
  var chev = document.querySelector('.nav-chev');
  if (dd) { dd.classList.toggle('open'); }
  if (chev) { chev.style.transform = dd && dd.classList.contains('open') ? 'rotate(180deg)' : 'rotate(0)'; }
}
window.toggleNavDropdown = toggleNavDropdown;
document.addEventListener('click', function(e) {
  var wrap = document.getElementById('navProfileWrap');
  var dd = document.getElementById('navDropdown');
  if (wrap && dd && !wrap.contains(e.target) && dd.classList.contains('open')) {
    dd.classList.remove('open');
    var chev = document.querySelector('.nav-chev');
    if (chev) chev.style.transform = 'rotate(0)';
  }
});
</script>
<style>
.sample-badge{display:inline-flex;align-items:center;gap:.35rem;padding:.25rem .7rem;border-radius:20px;font-size:.6rem;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.2);color:#fbbf24;margin-left:.75rem;vertical-align:middle;animation:samplePulse 3s ease-in-out infinite}
.sample-badge i{font-size:.55rem}
@keyframes samplePulse{0%,100%{opacity:.7}50%{opacity:1}}
.sample-banner{display:flex;align-items:center;gap:.5rem;padding:.5rem 1rem;border-radius:10px;font-size:.68rem;color:rgba(251,191,36,.8);background:rgba(251,191,36,.04);border:1px solid rgba(251,191,36,.1);margin-bottom:1.25rem;font-weight:500}
.sample-banner i{font-size:.8rem;color:#fbbf24}
</style>
</head><body>
<nav class="mp-nav"><a href="${pageContext.request.contextPath}/landing.html" class="mp-brand">APEX<span>FITNESS</span></a>
<div class="mp-nav-r">
  <!-- Notification Bell -->
  <button class="nav-icon-btn" onclick="showSec('notif',this)" title="Notifications" style="position:relative">
    <i class="bi bi-bell"></i>
    <span class="nav-notif-dot">3</span>
  </button>
  <!-- Plan Badge -->
  <div class="nav-plan-badge">
    <i class="bi bi-lightning-fill"></i>
    <span>${empty member.planName ? 'Standard' : member.planName}</span>
  </div>
  <!-- Member Avatar + Dropdown -->
  <div class="nav-profile-wrap" id="navProfileWrap">
    <button class="nav-avatar-btn" onclick="toggleNavDropdown()">
      <div class="nav-avatar">
        <img src="${pageContext.request.contextPath}/static/images/default-avatar.png" alt="avatar" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" style="width:100%;height:100%;object-fit:cover;border-radius:50%">
        <div style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-weight:700;font-size:.7rem;color:var(--accent);background:rgba(200,240,61,.08)">
          ${empty member.name ? 'U' : member.name.substring(0,1)}
        </div>
        <span class="nav-online-dot"></span>
      </div>
      <i class="bi bi-chevron-down nav-chev"></i>
    </button>
    <!-- Dropdown Menu -->
    <div class="nav-dropdown" id="navDropdown">
      <div class="nav-dd-header">
        <div class="nav-dd-name">${empty member.name ? 'Member' : member.name}</div>
        <div class="nav-dd-email">${empty member.email ? '' : member.email}</div>
      </div>
      <div class="nav-dd-divider"></div>
      <a class="nav-dd-item" onclick="showSec('profile',document.querySelector('.si[onclick*=profile]'));toggleNavDropdown()"><i class="bi bi-person"></i> My Profile</a>
      <a class="nav-dd-item" onclick="showSec('membership',document.querySelector('.si[onclick*=membership]'));toggleNavDropdown()"><i class="bi bi-credit-card"></i> Membership</a>
      <div class="nav-dd-divider"></div>
      <form action="${pageContext.request.contextPath}/member-profile" method="post" style="margin:0">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="nav-dd-item nav-dd-logout"><i class="bi bi-box-arrow-right"></i> Sign Out</button>
      </form>
    </div>
  </div>
</div></nav>
<div class="mp-layout">
<aside class="mp-side">
<div class="sidebar-toggle" id="sidebarToggle"><i class="bi bi-chevron-left"></i></div>
<div class="sl">Profile</div>
<div class="si active" onclick="showSec('overview',this)"><i class="bi bi-speedometer2"></i> <span>Overview</span></div>
<div class="si" onclick="showSec('profile',this)"><i class="bi bi-person-fill"></i> <span>My Profile</span></div>
<div class="si" onclick="showSec('checkin',this)"><i class="bi bi-qr-code-scan"></i> <span>Check-In</span><span class="si-badge">NEW</span></div>
<div class="si" onclick="showSec('plans',this)"><i class="bi bi-credit-card-fill"></i> <span>Membership</span></div>
<div class="sl">Fitness</div>
<div class="si" onclick="showSec('workout',this)"><i class="bi bi-calendar3"></i> <span>Workouts</span></div>

<div class="sl">Progress</div>
<div class="si" onclick="showSec('achieve',this)"><i class="bi bi-star-fill"></i> <span>Achievements</span></div>
<div class="si" onclick="showSec('progress',this)"><i class="bi bi-graph-up"></i> <span>Progress</span></div>
<div class="si" onclick="showSec('goals',this)"><i class="bi bi-trophy-fill"></i> <span>Goals</span></div>
<div class="si" onclick="showSec('health',this)"><i class="bi bi-heart-pulse-fill"></i> <span>Health</span></div>
<div class="sl">More</div>
<div class="si" onclick="showSec('ai',this)"><i class="bi bi-robot"></i> <span>AI Insights</span><span class="si-badge">PRO</span></div>
<div class="si" onclick="showSec('chat',this)"><i class="bi bi-chat-dots-fill"></i> <span>Chat & Alerts</span></div>
<div class="si" onclick="showSec('notif',this)"><i class="bi bi-bell-fill"></i> <span>Notifications</span></div>
<div class="si" onclick="showSec('payments',this)"><i class="bi bi-receipt"></i> <span>Payments</span></div>
<a href="${pageContext.request.contextPath}/landing.html" class="si"><i class="bi bi-house-fill"></i> <span>Back to Site</span></a>
</aside>
<main class="mp-main">
<!-- OVERVIEW -->
<div class="mp-sec active" id="sec-overview">
<% com.antigravity.fcms.modules.auth.backend.model.Member m = (com.antigravity.fcms.modules.auth.backend.model.Member) request.getAttribute("member"); String initial = (m != null && m.getName() != null && !m.getName().isEmpty()) ? String.valueOf(m.getName().charAt(0)).toUpperCase() : "?"; %>

<!-- ─── Premium Hero Card ─── -->
<div class="ov-hero-card">
  <div class="ov-hero-glow"></div>
  <div class="ov-hero-pattern"></div>
  <div class="ov-hero-inner">
    <!-- Left: Avatar + Info -->
    <div class="ov-hero-left">
      <div class="ov-avatar-ring">
        <div class="ov-avatar" id="ovAvatar">
          <span id="ovAvatarInitial"><%= initial %></span>
          <img id="ovAvatarImg" class="ov-avatar-img" style="display:none" alt="Profile">
        </div>
      </div>
      <div class="ov-hero-info">
        <div class="ov-hero-greeting" id="ovGreeting">Good Afternoon</div>
        <div class="ov-hero-name">${member.name}</div>
        <div class="ov-hero-badges">
          <span class="ov-badge plan"><i class="bi bi-gem"></i> ${empty member.planName ? 'Standard' : member.planName}</span>
          <span class="ov-badge id"><i class="bi bi-hash"></i>${member.id}</span>
          <span class="ov-badge status"><i class="bi bi-circle-fill"></i> ${empty member.status ? 'ACTIVE' : member.status}</span>
        </div>
        <div class="ov-hero-since"><i class="bi bi-calendar3"></i> Member since ${empty member.joinDate ? 'N/A' : member.joinDate}</div>
      </div>
    </div>
    <!-- Right: Streak + Date -->
    <div class="ov-hero-right">
      <div class="streak-badge"><i class="bi bi-fire"></i> <span data-bind="streak">7</span> Day Streak!</div>
      <div class="ov-date" id="ovDate"></div>
      <div class="ov-time" id="ovTime"></div>
    </div>
  </div>
</div>

<!-- ─── Quote Bar ─── -->
<div class="ov-quote">
  <i class="bi bi-quote ov-quote-icon"></i>
  <div class="ov-quote-body">
    <div class="ov-quote-text" id="quoteText">"The only bad workout is the one that didn't happen."</div>
    <div class="ov-quote-author" id="quoteAuthor">&mdash; Unknown</div>
  </div>
</div>

<!-- ─── Today's Metrics Row ─── -->
<div class="sample-banner"><i class="bi bi-info-circle-fill"></i> You're viewing a preview of your fitness dashboard. Start training and your personal stats, progress & achievements will come to life here!</div>
<div class="ov-metrics">
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(200,240,61,.1);color:var(--accent)"><i class="bi bi-fire"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val" data-bind="totalCalBurned" id="ovCalVal">450</div><div class="ov-metric-lbl">Cal Burned</div></div>
  </div>
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(96,165,250,.1);color:#60a5fa"><i class="bi bi-calendar-check"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val">12</div><div class="ov-metric-lbl">Classes</div></div>
  </div>
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(248,113,113,.1);color:#f87171"><i class="bi bi-heart-pulse"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val">85</div><div class="ov-metric-lbl">Avg BPM</div></div>
  </div>
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(251,191,36,.1);color:#fbbf24"><i class="bi bi-trophy"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val" data-bind="streak" id="ovStreakVal">7</div><div class="ov-metric-lbl">Day Streak</div></div>
  </div>
</div>

<!-- ─── Activity Rings Row ─── -->
<div class="mp-card" style="margin-bottom:1.5rem">
  <h4><i class="bi bi-circle"></i> Today's Activity Rings</h4>
  <div class="rings-wrap">
    <div class="ring-item">
      <svg class="ring-svg" width="90" height="90" viewBox="0 0 90 90">
        <circle class="ring-track" cx="45" cy="45" r="40"/>
        <circle class="ring-prog move" cx="45" cy="45" r="40" id="ringMove" style="stroke-dashoffset:60"/>
      </svg>
      <div class="ring-val-wrap"><div class="ring-val" style="color:#f87171">420</div><div class="ring-lbl">Move (cal)</div></div>
    </div>
    <div class="ring-item">
      <svg class="ring-svg" width="90" height="90" viewBox="0 0 90 90">
        <circle class="ring-track" cx="45" cy="45" r="40"/>
        <circle class="ring-prog exercise" cx="45" cy="45" r="40" id="ringEx" style="stroke-dashoffset:80"/>
      </svg>
      <div class="ring-val-wrap"><div class="ring-val" style="color:#34d399">45 <span style="font-size:.7rem">min</span></div><div class="ring-lbl">Exercise</div></div>
    </div>
    <div class="ring-item">
      <svg class="ring-svg" width="90" height="90" viewBox="0 0 90 90">
        <circle class="ring-track" cx="45" cy="45" r="40"/>
        <circle class="ring-prog stand" cx="45" cy="45" r="40" id="ringStand" style="stroke-dashoffset:100"/>
      </svg>
      <div class="ring-val-wrap"><div class="ring-val" style="color:#60a5fa">10 <span style="font-size:.7rem">hrs</span></div><div class="ring-lbl">Stand</div></div>
    </div>
    <div class="ring-item">
      <svg class="ring-svg" width="90" height="90" viewBox="0 0 90 90">
        <circle class="ring-track" cx="45" cy="45" r="40"/>
        <circle class="ring-prog calories" cx="45" cy="45" r="40" id="ringCal" style="stroke-dashoffset:50"/>
      </svg>
      <div class="ring-val-wrap"><div class="ring-val" style="color:var(--accent)">2,100</div><div class="ring-lbl">Total Cal</div></div>
    </div>
  </div>
</div>
<!-- ─── AI + Chart Row ─── -->
<div class="mp-grid2">
  <div class="ai-card neon-card">
    <div class="ai-tag"><i class="bi bi-stars"></i> Today's AI Plan</div>
    <h4>Upper Body Power</h4>
    <p>Based on your recovery score of 88%, we recommend focusing on hypertrophy. Drink at least 3L of water today.</p>
    <div style="margin-top:1rem;display:flex;gap:.5rem;flex-wrap:wrap">
      <span class="inline-badge"><i class="bi bi-fire"></i> High Intensity</span>
      <span class="inline-badge"><i class="bi bi-clock"></i> 55 min</span>
      <span class="inline-badge"><i class="bi bi-droplet"></i> 3L water</span>
    </div>
  </div>
  <div class="mp-card"><h4><i class="bi bi-graph-up-arrow"></i> Weekly Performance</h4><canvas id="weeklyChart" height="150"></canvas></div>
</div>
</div>


<!-- PROFILE -->
<div class="mp-sec" id="sec-profile">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:1.5rem">MY <span style="color:var(--accent)">PROFILE</span></h2>
<div class="mp-grid3">
<!-- Photo Upload Card -->
<div class="mp-card prof-photo-card">
<h4><i class="bi bi-camera-fill"></i> Profile Photo</h4>
<div class="prof-photo-wrap">
<div class="prof-photo" id="profPhoto">
<span class="prof-photo-initial" id="profInitial"><%= initial %></span>
<img id="profPhotoImg" class="prof-photo-img" style="display:none" alt="Profile">
<label class="prof-photo-overlay" for="photoUploadInput"><i class="bi bi-camera-fill"></i><span>Change Photo</span></label>
<input type="file" id="photoUploadInput" accept="image/*" style="display:none" onchange="handlePhotoUpload(this)">
</div>
<div class="prof-photo-name">${member.name}</div>
<div class="prof-photo-plan"><i class="bi bi-gem"></i> ${empty member.planName ? 'Standard' : member.planName} Plan</div>
</div>
</div>
<!-- Personal Details -->
<div class="mp-card"><h4><i class="bi bi-person-lines-fill"></i> Personal Details</h4>
<div class="ir"><div class="ir-lbl" style="width:80px">Name</div><div class="ir-val">${member.name}</div></div>
<div class="ir"><div class="ir-lbl" style="width:80px">Email</div><div class="ir-val">${member.email}</div></div>
<div class="ir"><div class="ir-lbl" style="width:80px">Phone</div><div class="ir-val">${empty member.phone ? 'Not provided' : member.phone}</div></div>
<div class="ir"><div class="ir-lbl" style="width:80px">Join Date</div><div class="ir-val">${empty member.joinDate ? 'N/A' : member.joinDate}</div></div>
<div class="ir"><div class="ir-lbl" style="width:80px">Status</div><div class="ir-val" style="color:var(--accent);font-weight:700">${empty member.status ? 'ACTIVE' : member.status}</div></div>
<button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openModal('editProfileModal')"><i class="bi bi-pencil-square"></i> Edit Profile</button>
</div>
<!-- Member Pass -->
<div class="mp-card" style="text-align:center"><h4><i class="bi bi-qr-code-scan"></i> Member Pass</h4>
<div style="background:#fff;padding:1rem;border-radius:12px;display:inline-block;margin:1rem 0"><img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${member.id}" alt="QR" style="width:120px;height:120px;mix-blend-mode:multiply"></div>
<div style="font-family:var(--font-display);font-size:1.5rem;letter-spacing:2px;color:var(--accent)">${member.id}</div><div style="font-size:.7rem;color:var(--gray)">Scan at front desk</div>
</div>
</div></div>

<!-- CHECKIN -->
<div class="mp-sec" id="sec-checkin">
<h2 class="sec-title">SMART <span>CHECK-IN</span></h2>
<div class="mp-grid2">
<div class="mp-card" style="text-align:center">
<h4><i class="bi bi-qr-code-scan"></i> Gym Access Pass</h4>
<div style="background:#fff;padding:1rem;border-radius:12px;display:inline-block;margin:1rem 0"><img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${member.id}" alt="QR" style="width:180px;height:180px;mix-blend-mode:multiply"></div>
<div style="font-family:var(--font-display);font-size:1.5rem;letter-spacing:2px;color:var(--accent)">${member.id}</div>
<form method="post" action="${pageContext.request.contextPath}/attendance/checkin" style="margin-top:1rem;width:100%">
  <input type="hidden" name="memberId" value="${member.id}">
  <button type="submit" class="btn-solid" style="width:100%" id="checkInBtn">
    <i class="bi bi-qr-code-scan me-1"></i> Check In Now
  </button>
</form>
</div>
<div class="mp-card">
<h4><i class="bi bi-calendar2-check"></i> Attendance (This Month)</h4>
<div class="cal-grid" id="attendanceGrid">
<div class="cal-head">Sun</div><div class="cal-head">Mon</div><div class="cal-head">Tue</div><div class="cal-head">Wed</div><div class="cal-head">Thu</div><div class="cal-head">Fri</div><div class="cal-head">Sat</div>
</div>
<div style="margin-top:2rem">
<h4><i class="bi bi-clock-history"></i> Recent Visits</h4>
<div class="tl-vert">
<div class="tl-entry"><div class="tl-entry-time">Yesterday · 17:30</div><div class="tl-entry-text">Apex Fitness — Colombo</div></div>
<div class="tl-entry"><div class="tl-entry-time">Mon, 12th · 06:15</div><div class="tl-entry-text">Apex Fitness — Colombo</div></div>
</div>
</div>
</div>
</div>
</div>

<!-- MEMBERSHIP -->
<div class="mp-sec" id="sec-plans">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:1.5rem">MY <span style="color:var(--accent)">MEMBERSHIP</span></h2>

<!-- ─── Current Plan Hero ─── -->
<div class="mem-hero">
  <div class="mem-hero-glow"></div>
  <div class="mem-hero-inner">
    <div class="mem-hero-left">
      <div class="mem-plan-ring">
        <svg viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="8"/>
          <circle cx="60" cy="60" r="52" fill="none" stroke="var(--accent)" stroke-width="8"
            stroke-dasharray="327" stroke-dashoffset="82" stroke-linecap="round" style="transform:rotate(-90deg);transform-origin:center"/>
        </svg>
        <div class="mem-plan-ring-center">
          <div class="mem-ring-pct">75%</div>
          <div class="mem-ring-lbl">remaining</div>
        </div>
      </div>
      <div class="mem-plan-info">
        <div class="mem-plan-label">CURRENT PLAN</div>
        <div class="mem-plan-name">${empty member.planName ? 'Standard Plan' : member.planName}</div>
        <div class="mem-plan-meta">
          <span class="mem-status-pill"><i class="bi bi-circle-fill"></i> ${empty member.status ? 'ACTIVE' : member.status}</span>
          <span class="mem-id-pill"><i class="bi bi-person-badge"></i> ${member.id}</span>
        </div>
      </div>
    </div>
    <div class="mem-hero-right">
      <div class="mem-date-row"><i class="bi bi-calendar-check"></i><div><div class="mem-date-lbl">Start Date</div><div class="mem-date-val">${empty member.joinDate ? 'N/A' : member.joinDate}</div></div></div>
      <div class="mem-date-row"><i class="bi bi-calendar-x"></i><div><div class="mem-date-lbl">Expires</div><div class="mem-date-val">In 15 days</div></div></div>
      <div class="mem-date-row"><i class="bi bi-credit-card-2-front"></i><div><div class="mem-date-lbl">Next Billing</div><div class="mem-date-val">Rs. 4,500</div></div></div>
    </div>
  </div>
  <div class="mem-hero-actions">
    <button class="btn-solid"><i class="bi bi-arrow-clockwise"></i> Renew Now</button>
    <button class="btn-g" onclick="document.getElementById('planCards').scrollIntoView({behavior:'smooth'})"><i class="bi bi-arrow-up-circle"></i> Upgrade Plan</button>
    <button class="btn-g" style="background:rgba(255,255,255,.03);border-color:rgba(255,255,255,.08)"><i class="bi bi-receipt"></i> Billing History</button>
  </div>
</div>

<!-- ─── Membership Stats ─── -->
<div class="ov-metrics" style="margin-bottom:2rem">
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(200,240,61,.1);color:var(--accent)"><i class="bi bi-calendar-check-fill"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val">45</div><div class="ov-metric-lbl">Days Active</div></div>
  </div>
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(96,165,250,.1);color:#60a5fa"><i class="bi bi-door-open-fill"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val">38</div><div class="ov-metric-lbl">Check-ins</div></div>
  </div>
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(248,113,113,.1);color:#f87171"><i class="bi bi-cash-stack"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val">Rs.13.5K</div><div class="ov-metric-lbl">Total Paid</div></div>
  </div>
  <div class="ov-metric">
    <div class="ov-metric-icon" style="background:rgba(52,211,153,.1);color:#34d399"><i class="bi bi-piggy-bank-fill"></i></div>
    <div class="ov-metric-data"><div class="ov-metric-val">Rs.4.5K</div><div class="ov-metric-lbl">Saved</div></div>
  </div>
</div>

<!-- ─── Plan Comparison Cards ─── -->
<div class="mem-plan-heading" id="planCards"><i class="bi bi-grid-3x3-gap-fill"></i> Choose Your Plan</div>
<div class="plan-cards-row">
  <!-- Basic -->
  <div class="plan-card">
    <div class="plan-card-header basic">
      <div class="plan-card-icon"><i class="bi bi-lightning-fill"></i></div>
      <div class="plan-card-tier">Basic</div>
      <div class="plan-card-price">Rs.2,500<span>/mo</span></div>
    </div>
    <div class="plan-card-body">
      <ul class="plan-features">
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Gym Floor Access</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Locker Room</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Free Wi-Fi</li>
        <li class="no"><i class="bi bi-x-circle"></i> Group Classes</li>
        <li class="no"><i class="bi bi-x-circle"></i> Personal Trainer</li>
        <li class="no"><i class="bi bi-x-circle"></i> Sauna & Pool</li>
        <li class="no"><i class="bi bi-x-circle"></i> Nutrition Plan</li>
      </ul>
      <button class="plan-card-btn basic">Select Basic</button>
    </div>
  </div>
  <!-- Standard (Popular) -->
  <div class="plan-card popular">
    <div class="plan-popular-tag"><i class="bi bi-star-fill"></i> MOST POPULAR</div>
    <div class="plan-card-header standard">
      <div class="plan-card-icon"><i class="bi bi-gem"></i></div>
      <div class="plan-card-tier">Standard</div>
      <div class="plan-card-price">Rs.4,500<span>/mo</span></div>
    </div>
    <div class="plan-card-body">
      <ul class="plan-features">
        <li class="yes"><i class="bi bi-check-circle-fill"></i> 24/7 Gym Access</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> All Group Classes</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Locker & Towels</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Free Wi-Fi</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Sauna Access</li>
        <li class="no"><i class="bi bi-x-circle"></i> Personal Trainer</li>
        <li class="no"><i class="bi bi-x-circle"></i> Custom Nutrition</li>
      </ul>
      <button class="plan-card-btn popular">Current Plan</button>
    </div>
  </div>
  <!-- Premium -->
  <div class="plan-card premium-tier">
    <div class="plan-card-header premium">
      <div class="plan-card-icon"><i class="bi bi-trophy-fill"></i></div>
      <div class="plan-card-tier">Premium</div>
      <div class="plan-card-price">Rs.7,500<span>/mo</span></div>
    </div>
    <div class="plan-card-body">
      <ul class="plan-features">
        <li class="yes"><i class="bi bi-check-circle-fill"></i> 24/7 VIP Access</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> All Classes + Priority</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Dedicated Trainer</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Sauna, Pool & Spa</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Custom Nutrition Plan</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Body Composition Scan</li>
        <li class="yes"><i class="bi bi-check-circle-fill"></i> Guest Pass (2/mo)</li>
      </ul>
      <button class="plan-card-btn upgrade" onclick="openModal('checkoutModal')"><i class="bi bi-arrow-up-circle"></i> Upgrade Now</button>
    </div>
  </div>
</div>

<!-- ─── Member Benefits ─── -->
<div class="mem-benefits">
  <div class="mem-benefit"><i class="bi bi-shield-check"></i><div><strong>Money-Back Guarantee</strong><span>30-day refund, no questions</span></div></div>
  <div class="mem-benefit"><i class="bi bi-arrow-repeat"></i><div><strong>Freeze Anytime</strong><span>Pause up to 2 months/year</span></div></div>
  <div class="mem-benefit"><i class="bi bi-people-fill"></i><div><strong>Refer & Earn</strong><span>Get Rs.500 per referral</span></div></div>
  <div class="mem-benefit"><i class="bi bi-percent"></i><div><strong>Annual Discount</strong><span>Save 20% on yearly plans</span></div></div>
</div>

<!-- ─── Promo Code ─── -->
<div class="mem-promo">
  <div class="mem-promo-left"><i class="bi bi-tag-fill"></i><div><strong>Have a Promo Code?</strong><span>Enter below to apply a discount to your next billing</span></div></div>
  <div class="mem-promo-form">
    <input type="text" placeholder="Enter code e.g. APEX20" id="promoInput">
    <button class="btn-solid" onclick="applyPromo()">Apply</button>
  </div>
</div>
</div>

<!-- WORKOUTS -->
<div class="mp-sec" id="sec-workout">
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:1.5rem">
  <h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin:0">MY <span style="color:var(--accent)">WORKOUTS</span></h2>
  <div style="display:flex;gap:.5rem">
    <button class="btn-g" onclick="openModal('customWorkoutModal')"><i class="bi bi-plus-lg"></i> Custom Workout</button>
    <button class="btn-g" onclick="openModal('workoutHistoryModal')"><i class="bi bi-clock-history"></i> History</button>
  </div>
</div>
<!-- Dynamic Weekly strip -->
<div class="mp-card" style="display:flex;gap:.75rem;overflow-x:auto;padding-bottom:.5rem;margin-bottom:0;border-radius:14px 14px 0 0" id="weekStrip"></div>

<!-- Day Workout Plan Panel -->
<div class="neon-card" id="dayPlanPanel" style="border-radius:0 0 14px 14px;margin-bottom:1.5rem;padding:1.2rem 1.5rem;display:none">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;flex-wrap:wrap;gap:.5rem">
    <div><div style="font-size:.6rem;color:var(--accent);font-weight:700;letter-spacing:2px;text-transform:uppercase" id="dpLabel">TODAY'S PLAN</div><div style="font-size:1.1rem;font-weight:700" id="dpTitle">Upper Body Power</div></div>
    <div style="display:flex;gap:.8rem;font-size:.72rem;color:var(--gray)"><span><i class="bi bi-clock"></i> <span id="dpDuration">55 min</span></span><span><i class="bi bi-fire"></i> <span id="dpCal">420 kcal</span></span><span id="dpDiffWrap"><span class="wplan-diff hard" id="dpDiff">Hard</span></span></div>
  </div>
  <div id="dpExercises" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:.5rem;margin-bottom:1rem"></div>
  <div style="display:flex;gap:.5rem;flex-wrap:wrap">
    <button class="btn-solid" style="padding:.5rem 1.5rem" onclick="startDayWorkout()"><i class="bi bi-play-fill"></i> Start Workout</button>
    <button class="btn-g" style="padding:.5rem 1rem" onclick="document.getElementById('dayPlanPanel').style.display='none'"><i class="bi bi-x-lg"></i> Close</button>
  </div>
</div>

<script>
var weeklyPlans={
  0:{name:'Upper Body Power',duration:'55 min',cal:'420 kcal',diff:'Hard',diffCls:'hard',exercises:['Bench Press 4×10','Overhead Press 3×8','Pull-Ups 3×10','Barbell Rows 4×8','Dumbbell Curls 3×12','Tricep Dips 3×12']},
  1:{name:'Leg Day Destroyer',duration:'50 min',cal:'380 kcal',diff:'Hard',diffCls:'hard',exercises:['Squats 4×8','Romanian Deadlift 3×10','Leg Press 4×12','Lunges 3×10','Calf Raises 4×15','Leg Curls 3×12']},
  2:{name:'HIIT Cardio Blast',duration:'30 min',cal:'350 kcal',diff:'Medium',diffCls:'med',exercises:['Burpees 4×12','Mountain Climbers 3×30s','Box Jumps 3×10','Battle Ropes 3×30s']},
  3:{name:'Core & Abs Focus',duration:'35 min',cal:'280 kcal',diff:'Easy',diffCls:'easy',exercises:['Planks 3×60s','Russian Twists 3×20','Hanging Leg Raises 3×12','Ab Rollouts 3×10','Side Planks 3×30s']},
  4:{name:'Full Body Strength',duration:'75 min',cal:'520 kcal',diff:'Hard',diffCls:'hard',exercises:['Deadlifts 4×6','Bench Press 4×8','Squats 3×10','Pull-Ups 3×8','Overhead Press 3×8','Barbell Rows 3×10','Plank 3×60s','Farmer Walk 3×40m']},
  5:{name:'Yoga & Flexibility',duration:'40 min',cal:'180 kcal',diff:'Easy',diffCls:'easy',exercises:['Sun Salutation Flow','Warrior Pose Series','Hip Opener Sequence','Pigeon Pose Hold','Seated Forward Fold','Savasana']},
  6:{name:'Rest Day',duration:'—',cal:'—',diff:'Rest',diffCls:'easy',exercises:['Active recovery','Light stretching','Foam rolling','Hydrate well']}
};
var completedDays=[0,1];
(function(){
  var d=new Date(),dow=d.getDay(),mon=new Date(d);
  mon.setDate(d.getDate()-(dow===0?6:dow-1));
  var days=['MON','TUE','WED','THU','FRI','SAT','SUN'],html='';
  for(var i=0;i<7;i++){
    var dd=new Date(mon);dd.setDate(mon.getDate()+i);
    var isToday=dd.toDateString()===d.toDateString();
    var isDone=completedDays.indexOf(i)>=0&&dd<=d;
    html+='<div class="week-day-pill'+(isToday?' active':'')+'" style="cursor:pointer" onclick="showDayPlan('+i+',this)">'
      +'<div class="wdp-day">'+days[i]+'</div><div class="wdp-num">'+dd.getDate()+'</div>'
      +(isDone?'<div class="af-dot green"></div>':'')
      +'</div>';
  }
  document.getElementById('weekStrip').innerHTML=html;
})();

function showDayPlan(dayIdx,el){
  var p=weeklyPlans[dayIdx];if(!p)return;
  document.querySelectorAll('.week-day-pill').forEach(function(e){e.classList.remove('selected');});
  if(el)el.classList.add('selected');
  var panel=document.getElementById('dayPlanPanel');
  panel.style.display='block';
  var dayNames=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  document.getElementById('dpLabel').textContent=dayNames[dayIdx]+' Plan';
  document.getElementById('dpTitle').textContent=p.name;
  document.getElementById('dpDuration').textContent=p.duration;
  document.getElementById('dpCal').textContent=p.cal;
  document.getElementById('dpDiff').textContent=p.diff;
  document.getElementById('dpDiff').className='wplan-diff '+p.diffCls;
  var exHtml='';
  for(var i=0;i<p.exercises.length;i++){
    var isDone=completedDays.indexOf(dayIdx)>=0;
    exHtml+='<div style="display:flex;align-items:center;gap:.6rem;padding:.5rem .7rem;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:8px">'
      +'<div style="width:26px;height:26px;border-radius:6px;background:'+(isDone?'rgba(200,240,61,.15)':'rgba(255,255,255,.05)')+';display:flex;align-items:center;justify-content:center;font-size:.7rem;color:'+(isDone?'var(--accent)':'var(--gray)')+'">'+(isDone?'<i class="bi bi-check-lg"></i>':(i+1))+'</div>'
      +'<div style="font-size:.78rem;font-weight:500">'+p.exercises[i]+'</div></div>';
  }
  document.getElementById('dpExercises').innerHTML=exHtml;
}
function startDayWorkout(){showToast('Workout started! Let\'s go! 💪');}
window.showDayPlan=showDayPlan;window.startDayWorkout=startDayWorkout;
</script>

<!-- Stats row -->
<div class="mp-grid4" style="margin-bottom:1.5rem">
  <div class="ms"><div class="ms-icon green"><i class="bi bi-fire"></i></div><div class="ms-val" data-bind="workoutsThisWeek">3/5</div><div class="ms-lbl">Workouts This Week</div></div>
  <div class="ms"><div class="ms-icon blue"><i class="bi bi-clock-fill"></i></div><div class="ms-val" data-bind="totalTimeMins">4h 20m</div><div class="ms-lbl">Total Time</div></div>
  <div class="ms"><div class="ms-icon red"><i class="bi bi-lightning-charge-fill"></i></div><div class="ms-val" data-bind="totalCalBurned">1,320</div><div class="ms-lbl">Kcal Burned</div></div>
  <div class="ms"><div class="ms-icon yellow"><i class="bi bi-trophy-fill"></i></div><div class="ms-val" data-bind="weeklyGoalPct">68%</div><div class="ms-lbl">Weekly Goal</div></div>
</div>
<!-- Choose a workout plan -->
<div class="sec-subheading"><i class="bi bi-collection-fill"></i> Choose a Workout Plan</div>
<div class="wplan-grid">
  <div class="wplan-card" onclick="openWorkoutSession('upper')">
    <div class="wplan-badge">TODAY</div>
    <div class="wplan-icon" style="background:rgba(200,240,61,.12)"><i class="bi bi-lightning-charge-fill" style="color:var(--accent)"></i></div>
    <div class="wplan-info">
      <div class="wplan-name">Upper Body Power</div>
      <div class="wplan-meta"><span><i class="bi bi-list-check"></i> 6 exercises</span><span><i class="bi bi-clock"></i> 55 min</span><span class="wplan-diff hard">Hard</span></div>
    </div>
    <button class="btn-solid wplan-btn"><i class="bi bi-play-fill"></i> Start Workout</button>
  </div>
  <div class="wplan-card" onclick="openWorkoutSession('legs')">
    <div class="wplan-icon" style="background:rgba(96,165,250,.12)"><i class="bi bi-person-walking" style="color:#60a5fa"></i></div>
    <div class="wplan-info">
      <div class="wplan-name">Leg Day Destroyer</div>
      <div class="wplan-meta"><span><i class="bi bi-list-check"></i> 5 exercises</span><span><i class="bi bi-clock"></i> 50 min</span><span class="wplan-diff hard">Hard</span></div>
    </div>
    <button class="btn-g wplan-btn"><i class="bi bi-play-fill"></i> Start Workout</button>
  </div>
  <div class="wplan-card" onclick="openWorkoutSession('hiit')">
    <div class="wplan-icon" style="background:rgba(248,113,113,.12)"><i class="bi bi-heart-pulse-fill" style="color:#f87171"></i></div>
    <div class="wplan-info">
      <div class="wplan-name">HIIT Cardio Blast</div>
      <div class="wplan-meta"><span><i class="bi bi-list-check"></i> 4 exercises</span><span><i class="bi bi-clock"></i> 30 min</span><span class="wplan-diff med">Medium</span></div>
    </div>
    <button class="btn-g wplan-btn"><i class="bi bi-play-fill"></i> Start Workout</button>
  </div>
  <div class="wplan-card" onclick="openWorkoutSession('core')">
    <div class="wplan-icon" style="background:rgba(251,191,36,.12)"><i class="bi bi-bullseye" style="color:#fbbf24"></i></div>
    <div class="wplan-info">
      <div class="wplan-name">Core & Abs Focus</div>
      <div class="wplan-meta"><span><i class="bi bi-list-check"></i> 5 exercises</span><span><i class="bi bi-clock"></i> 35 min</span><span class="wplan-diff easy">Easy</span></div>
    </div>
    <button class="btn-g wplan-btn"><i class="bi bi-play-fill"></i> Start Workout</button>
  </div>
  <div class="wplan-card" onclick="openWorkoutSession('full')">
    <div class="wplan-icon" style="background:rgba(167,139,250,.12)"><i class="bi bi-stars" style="color:#a78bfa"></i></div>
    <div class="wplan-info">
      <div class="wplan-name">Full Body Strength</div>
      <div class="wplan-meta"><span><i class="bi bi-list-check"></i> 8 exercises</span><span><i class="bi bi-clock"></i> 75 min</span><span class="wplan-diff hard">Hard</span></div>
    </div>
    <button class="btn-g wplan-btn"><i class="bi bi-play-fill"></i> Start Workout</button>
  </div>
  <div class="wplan-card" onclick="openWorkoutSession('yoga')">
    <div class="wplan-icon" style="background:rgba(52,211,153,.12)"><i class="bi bi-person-arms-up" style="color:#34d399"></i></div>
    <div class="wplan-info">
      <div class="wplan-name">Yoga & Flexibility</div>
      <div class="wplan-meta"><span><i class="bi bi-list-check"></i> 6 exercises</span><span><i class="bi bi-clock"></i> 40 min</span><span class="wplan-diff easy">Easy</span></div>
    </div>
    <button class="btn-g wplan-btn"><i class="bi bi-play-fill"></i> Start Workout</button>
  </div>
</div>

<!-- Recent Activity -->
<div class="sec-subheading" style="margin-top:2rem"><i class="bi bi-clock-history"></i> Recent Activity</div>
<div class="mp-grid2">
  <div class="mp-card">
    <div class="tl-vert" id="workoutTimeline">
      <div class="tl-entry"><div class="tl-entry-time">Today · 07:15 AM</div><div class="tl-entry-text"><strong>Upper Body Power</strong> — 55 min · 420 kcal · 6 exercises</div></div>
      <div class="tl-entry"><div class="tl-entry-time">Yesterday · 06:30 AM</div><div class="tl-entry-text"><strong>HIIT Cardio Blast</strong> — 32 min · 380 kcal · 4 exercises</div></div>
      <div class="tl-entry"><div class="tl-entry-time">Mon, 28th · 17:00</div><div class="tl-entry-text"><strong>Leg Day Destroyer</strong> — 48 min · 350 kcal · 5 exercises</div></div>
    </div>
  </div>
  <div class="mp-card"><h4><i class="bi bi-bar-chart-fill"></i> Weekly Volume</h4><canvas id="workoutVolumeChart" height="180"></canvas></div>
</div>
<script>
if(typeof Chart!=='undefined'&&document.getElementById('workoutVolumeChart')){
  new Chart(document.getElementById('workoutVolumeChart'),{type:'bar',data:{labels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],datasets:[{label:'Volume (kg)',data:[2400,0,3100,2800,0,4200,0],backgroundColor:'rgba(200,240,61,.25)',borderColor:'#C8F03D',borderWidth:1,borderRadius:6,barThickness:24}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{callback:function(v){return v/1000+'k'}}}}}});
}
</script>

<!-- Custom Workout Modal -->
<div class="modal-overlay" id="customWorkoutModal">
<div class="modal-box wide">
<button class="modal-close" onclick="closeModal('customWorkoutModal')">&times;</button>
<h3 class="m-title">CREATE <span style="color:var(--accent)">WORKOUT</span></h3>
<div class="edit-form-field"><label>Workout Name</label><input type="text" id="cwName" placeholder="e.g. Push Day"></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
  <div class="edit-form-field"><label>Duration (min)</label><input type="number" id="cwDuration" placeholder="45"></div>
  <div class="edit-form-field"><label>Difficulty</label><select id="cwDiff"><option>Easy</option><option selected>Medium</option><option>Hard</option></select></div>
</div>
<div class="edit-form-field"><label>Exercises (one per line)</label><textarea id="cwExercises" rows="5" placeholder="Bench Press - 4x10&#10;Incline DB Press - 3x12&#10;Cable Flyes - 3x15" style="width:100%;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;padding:.7rem 1rem;color:#fff;font-size:.85rem;font-family:var(--font-body);outline:none;resize:vertical"></textarea></div>
<button class="btn-solid" style="width:100%;padding:.75rem" onclick="saveCustomWorkout()"><i class="bi bi-check-lg"></i> Save Workout</button>
</div></div>

<!-- History Modal -->
<div class="modal-overlay" id="workoutHistoryModal">
<div class="modal-box wide">
<button class="modal-close" onclick="closeModal('workoutHistoryModal')">&times;</button>
<h3 class="m-title">WORKOUT <span style="color:var(--accent)">HISTORY</span></h3>
<div id="workoutHistoryList" style="display:flex;flex-direction:column;gap:.6rem">
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:42px;height:42px;border-radius:12px;background:rgba(200,240,61,.1);display:flex;align-items:center;justify-content:center;color:var(--accent)"><i class="bi bi-lightning-charge-fill"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">Upper Body Power</div><div style="font-size:.7rem;color:var(--gray)">Today · 55 min · 420 kcal</div></div><span class="pay-status paid">DONE</span></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:42px;height:42px;border-radius:12px;background:rgba(248,113,113,.1);display:flex;align-items:center;justify-content:center;color:#f87171"><i class="bi bi-heart-pulse-fill"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">HIIT Cardio Blast</div><div style="font-size:.7rem;color:var(--gray)">Yesterday · 32 min · 380 kcal</div></div><span class="pay-status paid">DONE</span></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:42px;height:42px;border-radius:12px;background:rgba(96,165,250,.1);display:flex;align-items:center;justify-content:center;color:#60a5fa"><i class="bi bi-person-walking"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">Leg Day Destroyer</div><div style="font-size:.7rem;color:var(--gray)">Mon · 48 min · 350 kcal</div></div><span class="pay-status paid">DONE</span></div>
</div>
</div></div>

<script>
function saveCustomWorkout(){
  var n=document.getElementById('cwName').value.trim();
  if(!n){showToast('Please enter a workout name','error');return;}
  closeModal('customWorkoutModal');
  showToast('Custom workout "'+n+'" saved! 🎯');
  document.getElementById('cwName').value='';
  document.getElementById('cwExercises').value='';
}
window.saveCustomWorkout=saveCustomWorkout;
</script>
</div>

<!-- EXERCISES -->
<!-- CLASS BOOKING -->
<div class="mp-sec" id="sec-classes">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:.3rem">CLASS <span style="color:var(--accent)">BOOKING</span></h2>
<div class="sec-subtitle">Reserve your spot in upcoming group sessions</div>
<div style="display:flex;gap:.75rem;margin:1.25rem 0;flex-wrap:wrap">
  <div class="pill pill-accent" onclick="filterClasses('all',this)" style="cursor:pointer">All Classes</div>
  <div class="pill" style="border:1px solid var(--border);cursor:pointer" onclick="filterClasses('yoga',this)">Yoga</div>
  <div class="pill" style="border:1px solid var(--border);cursor:pointer" onclick="filterClasses('hiit',this)">HIIT</div>
  <div class="pill" style="border:1px solid var(--border);cursor:pointer" onclick="filterClasses('spin',this)">Spin</div>
  <div class="pill" style="border:1px solid var(--border);cursor:pointer" onclick="filterClasses('box',this)">Boxing</div>
</div>
<div class="class-grid" id="classGrid">
  <div class="class-card" data-type="yoga">
    <div class="class-card-banner yoga"><i class="bi bi-person-arms-up" style="color:#34d399"></i></div>
    <div class="class-card-body">
      <div class="class-name">Vinyasa Yoga</div>
      <div class="class-meta"><span><i class="bi bi-clock"></i>6:30 AM</span><span><i class="bi bi-calendar"></i>Mon &amp; Wed</span><span><i class="bi bi-person"></i>Coach Priya</span></div>
      <div class="class-spots"><div class="spots-bar"><div class="spots-fill" style="width:70%"></div></div><span style="color:var(--gray)">6 left</span></div>
      <button class="class-btn book" onclick="bookClass(this,'Vinyasa Yoga')">Book Now</button>
    </div>
  </div>
  <div class="class-card" data-type="hiit">
    <div class="class-card-banner hiit"><i class="bi bi-lightning-charge-fill" style="color:#f87171"></i></div>
    <div class="class-card-body">
      <div class="class-name">HIIT Blast</div>
      <div class="class-meta"><span><i class="bi bi-clock"></i>7:00 AM</span><span><i class="bi bi-calendar"></i>Tue &amp; Thu</span><span><i class="bi bi-person"></i>Coach Ravi</span></div>
      <div class="class-spots"><div class="spots-bar"><div class="spots-fill warn" style="width:90%"></div></div><span style="color:#fbbf24">2 left</span></div>
      <button class="class-btn book" onclick="bookClass(this,'HIIT Blast')">Book Now</button>
    </div>
  </div>
  <div class="class-card" data-type="spin">
    <div class="class-card-banner spin"><i class="bi bi-bicycle" style="color:var(--accent)"></i></div>
    <div class="class-card-body">
      <div class="class-name">Power Spin</div>
      <div class="class-meta"><span><i class="bi bi-clock"></i>8:00 AM</span><span><i class="bi bi-calendar"></i>Mon-Fri</span><span><i class="bi bi-person"></i>Coach Sam</span></div>
      <div class="class-spots"><div class="spots-bar"><div class="spots-fill full" style="width:100%"></div></div><span style="color:#f87171">Full</span></div>
      <button class="class-btn full" disabled>Class Full</button>
    </div>
  </div>
  <div class="class-card" data-type="box">
    <div class="class-card-banner box"><i class="bi bi-hand-index-thumb-fill" style="color:#a78bfa"></i></div>
    <div class="class-card-body">
      <div class="class-name">Boxing Fundamentals</div>
      <div class="class-meta"><span><i class="bi bi-clock"></i>5:30 PM</span><span><i class="bi bi-calendar"></i>Sat</span><span><i class="bi bi-person"></i>Coach Mike</span></div>
      <div class="class-spots"><div class="spots-bar"><div class="spots-fill" style="width:40%"></div></div><span style="color:var(--gray)">12 left</span></div>
      <button class="class-btn book" onclick="bookClass(this,'Boxing Fundamentals')">Book Now</button>
    </div>
  </div>
  <div class="class-card" data-type="yoga">
    <div class="class-card-banner pilates"><i class="bi bi-activity" style="color:#fbbf24"></i></div>
    <div class="class-card-body">
      <div class="class-name">Pilates Core</div>
      <div class="class-meta"><span><i class="bi bi-clock"></i>10:00 AM</span><span><i class="bi bi-calendar"></i>Wed &amp; Fri</span><span><i class="bi bi-person"></i>Coach Tara</span></div>
      <div class="class-spots"><div class="spots-bar"><div class="spots-fill" style="width:55%"></div></div><span style="color:var(--gray)">9 left</span></div>
      <button class="class-btn book" onclick="bookClass(this,'Pilates Core')">Book Now</button>
    </div>
  </div>
  <div class="class-card" data-type="hiit">
    <div class="class-card-banner zumba"><i class="bi bi-music-note-beamed" style="color:#60a5fa"></i></div>
    <div class="class-card-body">
      <div class="class-name">Zumba Dance</div>
      <div class="class-meta"><span><i class="bi bi-clock"></i>6:00 PM</span><span><i class="bi bi-calendar"></i>Tue &amp; Sat</span><span><i class="bi bi-person"></i>Coach Nadia</span></div>
      <div class="class-spots"><div class="spots-bar"><div class="spots-fill warn" style="width:80%"></div></div><span style="color:#fbbf24">4 left</span></div>
      <button class="class-btn book" onclick="bookClass(this,'Zumba Dance')">Book Now</button>
    </div>
  </div>
</div>
<div class="sec-divider"><div class="sec-divider-text">My Booked Classes</div></div>
<div id="myBookings" style="display:flex;flex-direction:column;gap:.75rem"></div>
<script>
function renderMyBookings(){
  var el=document.getElementById('myBookings');
  var bookings=[];
  try{bookings=JSON.parse(localStorage.getItem('apex_booked_classes')||'[]');}catch(e){}
  if(!bookings.length){
    el.innerHTML='<div style="text-align:center;padding:2rem;color:var(--gray);font-size:.82rem"><i class="bi bi-calendar-x" style="font-size:1.5rem;display:block;margin-bottom:.5rem;opacity:.4"></i>No classes booked yet.<br><a href="/classes.html" style="color:var(--accent);text-decoration:none;font-weight:700">Browse Classes →</a></div>';
    return;
  }
  var html='';
  bookings.forEach(function(b,i){
    var iconColor=b.color||'var(--accent)';
    var iconCls=b.icon||'bi-calendar3';
    html+='<div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem 1.5rem">';
    html+='<div style="width:42px;height:42px;border-radius:12px;background:'+iconColor.replace(')',',0.1)').replace('#','rgba(').replace(/([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})/i,function(m,r,g,bl){return parseInt(r,16)+','+parseInt(g,16)+','+parseInt(bl,16);})+';display:flex;align-items:center;justify-content:center;color:'+iconColor+';font-size:1.1rem"><i class="bi '+iconCls+'"></i></div>';
    html+='<div style="flex:1"><div style="font-weight:700;font-size:.9rem">'+b.name+'</div><div style="font-size:.72rem;color:var(--gray)">'+b.schedule+' · '+b.trainer+'</div></div>';
    html+='<span class="pay-status paid" style="font-size:.65rem">BOOKED</span>';
    html+='<button class="btn-g" style="font-size:.72rem;padding:.35rem .75rem" onclick="cancelBooking('+i+')">Cancel</button>';
    html+='</div>';
  });
  el.innerHTML=html;
}
function cancelBooking(idx){
  var bookings=[];
  try{bookings=JSON.parse(localStorage.getItem('apex_booked_classes')||'[]');}catch(e){}
  var name=bookings[idx]?bookings[idx].name:'Class';
  bookings.splice(idx,1);
  localStorage.setItem('apex_booked_classes',JSON.stringify(bookings));
  renderMyBookings();
  if(typeof showToast==='function') showToast(name+' booking cancelled.','error');
}
document.addEventListener('DOMContentLoaded',renderMyBookings);
// Re-render when Classes tab is clicked
document.querySelectorAll('.si').forEach(function(s){
  if(s.textContent.indexOf('Classes')>=0) s.addEventListener('click',function(){setTimeout(renderMyBookings,100);});
});
</script>
</div>

<!-- PERSONAL RECORDS -->
<div class="mp-sec" id="sec-records">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:.3rem">PERSONAL <span style="color:var(--accent)">RECORDS</span><span class="sample-badge"><i class="bi bi-info-circle"></i> Sample Data</span></h2>
<div class="sec-subtitle">Your all-time best lifts and performance milestones</div>
<div class="sec-divider" style="margin:1.25rem 0"><div class="sec-divider-text">Strength PRs</div></div>
<div class="pr-grid">
  <div class="pr-card lift"><div class="pr-exercise">Bench Press</div><div class="pr-weight">120 <span>kg</span></div><div class="pr-date"><i class="bi bi-calendar3"></i> Mar 15, 2026</div></div>
  <div class="pr-card lift"><div class="pr-exercise">Squat</div><div class="pr-weight">150 <span>kg</span></div><div class="pr-date"><i class="bi bi-calendar3"></i> Feb 28, 2026</div></div>
  <div class="pr-card lift"><div class="pr-exercise">Deadlift</div><div class="pr-weight">180 <span>kg</span></div><div class="pr-date"><i class="bi bi-calendar3"></i> Apr 10, 2026</div></div>
  <div class="pr-card lift"><div class="pr-exercise">Overhead Press</div><div class="pr-weight">85 <span>kg</span></div><div class="pr-date"><i class="bi bi-calendar3"></i> Jan 20, 2026</div></div>
  <div class="pr-card lift"><div class="pr-exercise">Pull-ups</div><div class="pr-weight">22 <span>reps</span></div><div class="pr-date"><i class="bi bi-calendar3"></i> Apr 5, 2026</div></div>
  <div class="pr-card lift"><div class="pr-exercise">Plank Hold</div><div class="pr-weight">4:30 <span>min</span></div><div class="pr-date"><i class="bi bi-calendar3"></i> Mar 22, 2026</div></div>
</div>
<div class="sec-divider" style="margin:1.5rem 0"><div class="sec-divider-text">Cardio PRs</div></div>
<div class="mp-grid3">
  <div class="mp-card lift" style="text-align:center">
    <div style="font-size:.65rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">5K Run</div>
    <div style="font-family:var(--font-display);font-size:2.5rem;color:var(--accent);margin:.5rem 0">24:10</div>
    <div style="font-size:.72rem;color:var(--gray)">Apr 3, 2026 · Treadmill</div>
    <div class="pbar" style="margin-top:.75rem"><div class="pbar-fill green" style="width:80%"></div></div>
    <div style="font-size:.65rem;color:var(--gray);margin-top:.3rem">Goal: 22:00 · 80% there</div>
  </div>
  <div class="mp-card lift" style="text-align:center">
    <div style="font-size:.65rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">Rowing 2K</div>
    <div style="font-family:var(--font-display);font-size:2.5rem;color:#60a5fa;margin:.5rem 0">7:45</div>
    <div style="font-size:.72rem;color:var(--gray)">Mar 29, 2026 · Ergometer</div>
    <div class="pbar" style="margin-top:.75rem"><div class="pbar-fill blue" style="width:65%"></div></div>
    <div style="font-size:.65rem;color:var(--gray);margin-top:.3rem">Goal: 7:00 · 65% there</div>
  </div>
  <div class="mp-card lift" style="text-align:center">
    <div style="font-size:.65rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">Bike 10K</div>
    <div style="font-family:var(--font-display);font-size:2.5rem;color:#fbbf24;margin:.5rem 0">19:30</div>
    <div style="font-size:.72rem;color:var(--gray)">Apr 15, 2026 · Spin Bike</div>
    <div class="pbar" style="margin-top:.75rem"><div class="pbar-fill yellow" style="width:90%"></div></div>
    <div style="font-size:.65rem;color:var(--gray);margin-top:.3rem">Goal: 18:00 · 90% there</div>
  </div>
</div>
<div class="sec-divider" style="margin:1.5rem 0"><div class="sec-divider-text">Body Composition History</div></div>
<div class="body-comp-grid">
  <div class="bcomp-card"><div class="bcomp-lbl">Body Weight</div><div class="bcomp-val" style="color:#fff">78 <span style="font-size:.9rem">kg</span></div><div class="bcomp-change down"><i class="bi bi-arrow-down"></i> -4kg since joining</div></div>
  <div class="bcomp-card"><div class="bcomp-lbl">Body Fat %</div><div class="bcomp-val" style="color:#f87171">18%</div><div class="bcomp-change down"><i class="bi bi-arrow-down"></i> -3% improvement</div></div>
  <div class="bcomp-card"><div class="bcomp-lbl">Muscle Mass</div><div class="bcomp-val" style="color:var(--accent)">35 <span style="font-size:.9rem">kg</span></div><div class="bcomp-change up"><i class="bi bi-arrow-up"></i> +2.5kg gained</div></div>
  <div class="bcomp-card"><div class="bcomp-lbl">BMI</div><div class="bcomp-val" style="color:#60a5fa">23.4</div><div class="bcomp-change same"><i class="bi bi-dash"></i> Normal range</div></div>
  <div class="bcomp-card"><div class="bcomp-lbl">Visceral Fat</div><div class="bcomp-val" style="color:#34d399">8</div><div class="bcomp-change down"><i class="bi bi-arrow-down"></i> Low risk level</div></div>
  <div class="bcomp-card"><div class="bcomp-lbl">Metabolic Age</div><div class="bcomp-val" style="color:#a78bfa">24</div><div class="bcomp-change same"><i class="bi bi-arrow-down"></i> -3 yrs vs actual</div></div>
</div>
</div>

<div class="mp-sec" id="sec-exercise">
<link rel="stylesheet" href="${pageContext.request.contextPath}/static/css/exercise-detail.css">
<style>
.ex2-accent{color:#C8F03D}.ex2-tag{font-size:.58rem;font-weight:700;letter-spacing:3px;text-transform:uppercase;color:#C8F03D;margin-bottom:.3rem}
.ex2-title{font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:2px;margin-bottom:1.5rem}
.ex2-panel{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:1.8rem 2rem;margin-bottom:2rem}
.ex2-cols{display:flex;gap:0}
.ex2-col{flex:1;padding:0 1.5rem}
.ex2-col:first-child{padding-left:0}
.ex2-col:last-child{padding-right:0;border-right:none}
.ex2-col+.ex2-col{border-left:1px solid rgba(255,255,255,.07)}
.ex2-col-hd{font-size:.62rem;font-weight:800;letter-spacing:3px;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:1.1rem}
.ex2-row{display:flex;align-items:center;gap:.7rem;margin-bottom:.15rem}
.ex2-row-left{display:flex;flex-direction:column;gap:.05rem}
.ex2-thumb{display:none}
.ex2-link{display:flex;align-items:flex-start;gap:.7rem;padding:.5rem .6rem;border-radius:9px;text-decoration:none;transition:background .18s;cursor:pointer}
.ex2-link:hover{background:rgba(200,240,61,.06)}
.ex2-link:hover .ex2-lname{color:#C8F03D}
.ex2-lname{font-size:.72rem;font-weight:700;letter-spacing:.4px;text-transform:uppercase;color:#fff;transition:color .18s;display:inline-flex;align-items:center;gap:.3rem}
.ex2-lname i{font-size:.65rem;color:#C8F03D}
.ex2-lsub{font-size:.65rem;color:rgba(255,255,255,.38);margin-top:.05rem}
.ex2-equip-hd{font-family:'Bebas Neue',sans-serif;font-size:1.8rem;letter-spacing:2px;margin-bottom:1.2rem}
.ex2-equip-grid{display:flex;gap:.7rem;flex-wrap:wrap;margin-bottom:1.8rem}
.ex2-equip-box{display:flex;flex-direction:column;align-items:center;gap:.5rem;padding:.9rem .7rem;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:12px;cursor:pointer;transition:all .2s;min-width:75px;text-decoration:none}
.ex2-equip-box:hover{border-color:#C8F03D;background:rgba(200,240,61,.06)}
.ex2-equip-box span{font-size:.62rem;color:rgba(255,255,255,.6);text-align:center;line-height:1.3;font-weight:600}
.ex2-equip-box i{font-size:1.6rem;color:rgba(255,255,255,.5)}
.ex2-equip-box:hover i{color:#C8F03D}
.ex2-search-wrap{position:relative;margin-bottom:1.8rem}
.ex2-search-wrap i.si{position:absolute;left:1.2rem;top:50%;transform:translateY(-50%);color:rgba(255,255,255,.3);pointer-events:none;font-size:.95rem}
.ex2-search-wrap input{width:100%;padding:.85rem 1.5rem .85rem 3.2rem;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:#fff;font-size:.88rem;outline:none;transition:border-color .25s}
.ex2-search-wrap input:focus{border-color:rgba(200,240,61,.4)}
.ex2-search-wrap input::placeholder{color:rgba(255,255,255,.3)}
.ex2-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.3rem}
.ex2-card{background:rgba(10,20,15,.85);border:1px solid rgba(255,255,255,.08);border-radius:16px;overflow:hidden;transition:border-color .25s,transform .25s,box-shadow .25s;cursor:pointer;display:flex;flex-direction:column;position:relative}
.ex2-card:hover{border-color:rgba(200,240,61,.3);transform:translateY(-4px);box-shadow:0 16px 40px rgba(0,0,0,.5)}
.ex2-card.has-custom{border-color:rgba(200,240,61,.2)}
.ex2-card.has-custom:hover{border-color:rgba(200,240,61,.5);box-shadow:0 16px 40px rgba(200,240,61,.08)}
.ex2-img{height:200px;overflow:hidden;position:relative;background:linear-gradient(135deg,#0a1a12,#0d2318);flex-shrink:0}
.ex2-img img{width:100%;height:100%;object-fit:cover;object-position:center;transition:transform .5s ease;display:block}
.ex2-card:hover .ex2-img img{transform:scale(1.08)}
.ex2-img-overlay{position:absolute;inset:0;background:linear-gradient(to top,rgba(10,20,15,.95) 0%,rgba(10,20,15,.3) 50%,transparent 100%);pointer-events:none;z-index:1}
.ex2-img-shimmer{position:absolute;inset:0;background:linear-gradient(105deg,transparent 40%,rgba(200,240,61,.04) 50%,transparent 60%);opacity:0;transition:opacity .3s;pointer-events:none;z-index:2}
.ex2-card:hover .ex2-img-shimmer{opacity:1;animation:ex2Shimmer 1.2s ease infinite}
@keyframes ex2Shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
.ex2-no-img{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.6rem;background:linear-gradient(135deg,#0a1a12 0%,#0d2318 100%);background-image:linear-gradient(135deg,#0a1a12 0%,#0d2318 100%),repeating-linear-gradient(0deg,transparent,transparent 24px,rgba(255,255,255,.02) 24px,rgba(255,255,255,.02) 25px),repeating-linear-gradient(90deg,transparent,transparent 24px,rgba(255,255,255,.02) 24px,rgba(255,255,255,.02) 25px)}
.ex2-no-img i{font-size:2.2rem;color:rgba(255,255,255,.12)}
.ex2-no-img span{font-size:.58rem;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.1)}
.ex2-custom-badge{position:absolute;top:.65rem;right:.65rem;z-index:3;background:rgba(200,240,61,.18);border:1px solid rgba(200,240,61,.4);color:#C8F03D;font-size:.55rem;font-weight:800;letter-spacing:1px;padding:.2rem .55rem;border-radius:20px;backdrop-filter:blur(4px)}
.ex2-body{padding:1rem 1.15rem 1.15rem;display:flex;flex-direction:column;flex:1}
.ex2-cname{font-size:.8rem;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:#fff;margin-bottom:.35rem;line-height:1.3}
.ex2-cdesc{font-size:.69rem;color:rgba(255,255,255,.45);line-height:1.65;margin-bottom:.8rem;flex:1;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.ex2-tags{display:flex;flex-wrap:wrap;gap:.3rem;margin-bottom:.75rem}
.ex2-pill{padding:.15rem .5rem;border-radius:4px;font-size:.57rem;font-weight:700;letter-spacing:.4px;background:rgba(255,255,255,.07);color:rgba(255,255,255,.5);border:1px solid rgba(255,255,255,.05)}
.ex2-foot{display:flex;align-items:center;justify-content:space-between;padding-top:.6rem;border-top:1px solid rgba(255,255,255,.06)}
.ex2-equip-lbl{font-size:.62rem;color:rgba(255,255,255,.35);display:flex;align-items:center;gap:.35rem}
.ex2-arr{width:28px;height:28px;border-radius:7px;background:rgba(200,240,61,.1);display:flex;align-items:center;justify-content:center;color:#C8F03D;font-size:.78rem;transition:all .2s;flex-shrink:0}
.ex2-card:hover .ex2-arr{background:#C8F03D;color:#000;transform:rotate(45deg)}
.ex2-load{text-align:center;margin-top:1.5rem;display:none}
.ex2-load button{padding:.7rem 2rem;border-radius:50px;border:1px solid rgba(200,240,61,.3);background:rgba(200,240,61,.06);color:#C8F03D;font-size:.78rem;font-weight:700;cursor:pointer;transition:all .2s}
.ex2-load button:hover{background:#C8F03D;color:#000}
@media(max-width:900px){.ex2-grid{grid-template-columns:1fr 1fr}}
@media(max-width:800px){.ex2-cols{flex-direction:column}.ex2-col+.ex2-col{border-left:none;border-top:1px solid rgba(255,255,255,.07);padding-top:1rem;margin-top:1rem}}
@media(max-width:500px){.ex2-grid{grid-template-columns:1fr}}
</style>

<!-- FIND YOUR FOCUS -->
<div class="ex2-tag">Build, Focus &amp; Training Goals</div>
<div class="ex2-title">FIND YOUR <span class="ex2-accent">FOCUS</span></div>
<div class="ex2-panel">
  <div class="ex2-cols">
    <!-- BUILD -->
    <div class="ex2-col">
      <div class="ex2-col-hd">Build</div>
      <a class="ex2-link" data-kw="abs core" onclick="setEx2Filter('abs')">
        <div class="ex2-row-left"><div class="ex2-lname">Ab Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Core strength and definition</div></div>
      </a>
      <a class="ex2-link" data-kw="arms biceps triceps" onclick="setEx2Filter('arms')">
        <div class="ex2-row-left"><div class="ex2-lname">Arm Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Biceps and triceps</div></div>
      </a>
      <a class="ex2-link" data-kw="back upper lower" onclick="setEx2Filter('back')">
        <div class="ex2-row-left"><div class="ex2-lname">Back Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Upper and lower back</div></div>
      </a>
      <a class="ex2-link" data-kw="chest pectoral" onclick="setEx2Filter('chest')">
        <div class="ex2-row-left"><div class="ex2-lname">Chest Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Pectoral muscles</div></div>
      </a>
      <a class="ex2-link" data-kw="glutes shape" onclick="setEx2Filter('glutes')">
        <div class="ex2-row-left"><div class="ex2-lname">Glute Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Shape and strengthen</div></div>
      </a>
      <a class="ex2-link" data-kw="legs quads hamstrings calves" onclick="setEx2Filter('legs')">
        <div class="ex2-row-left"><div class="ex2-lname">Leg Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Quads, hamstrings, calves</div></div>
      </a>
      <a class="ex2-link" data-kw="shoulders deltoids traps" onclick="setEx2Filter('shoulders')">
        <div class="ex2-row-left"><div class="ex2-lname">Shoulder Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Deltoids and traps</div></div>
      </a>
    </div>
    <!-- FOCUS -->
    <div class="ex2-col">
      <div class="ex2-col-hd">Focus</div>
      <a class="ex2-link" onclick="setEx2Filter('bodybuilding')"><div class="ex2-row-left"><div class="ex2-lname">Bodybuilding Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Muscle growth and aesthetics</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('crossfit')"><div class="ex2-row-left"><div class="ex2-lname">Crossfit Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Functional fitness</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('hiit')"><div class="ex2-row-left"><div class="ex2-lname">HIIT Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">High intensity intervals</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('hyrox')"><div class="ex2-row-left"><div class="ex2-lname">Hyrox Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Endurance racing</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('recovery')"><div class="ex2-row-left"><div class="ex2-lname">Recovery Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Active rest and healing</div></div></a>
    </div>
    <!-- TRAINING GOALS -->
    <div class="ex2-col">
      <div class="ex2-col-hd">Training Goals</div>
      <a class="ex2-link" onclick="setEx2Filter('cardio')"><div class="ex2-row-left"><div class="ex2-lname">Cardio Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Heart health and stamina</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('core')"><div class="ex2-row-left"><div class="ex2-lname">Core Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Stability and balance</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('endurance')"><div class="ex2-row-left"><div class="ex2-lname">Endurance Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Extend workout capacity</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('mobility')"><div class="ex2-row-left"><div class="ex2-lname">Mobility Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Flexibility and range</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('strength')"><div class="ex2-row-left"><div class="ex2-lname">Strength Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Build power and force</div></div></a>
      <a class="ex2-link" onclick="setEx2Filter('stretching')"><div class="ex2-row-left"><div class="ex2-lname">Stretching Exercises <i class="bi bi-arrow-up-right"></i></div><div class="ex2-lsub">Muscle recovery and flexibility</div></div></a>
    </div>
  </div>
</div>

<!-- PICK YOUR EQUIPMENT -->
<div class="ex2-equip-hd">PICK YOUR <span class="ex2-accent">EQUIPMENT</span></div>
<div class="ex2-equip-grid">
  <a class="ex2-equip-box" onclick="setEx2Equip('barbell')"><i class="bi bi-bar-chart-steps"></i><span>Barbell</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('bodyweight')"><i class="bi bi-person-arms-up"></i><span>Bodyweight exercises</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('cable')"><i class="bi bi-diagram-3-fill"></i><span>Cable</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('dumbbell')"><i class="bi bi-collection-fill"></i><span>Dumbbell</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('foam')"><i class="bi bi-circle-fill"></i><span>Foam roller</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('kettlebell')"><i class="bi bi-droplet-fill"></i><span>Kettlebell</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('machine')"><i class="bi bi-gear-wide-connected"></i><span>Machine</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('medicine')"><i class="bi bi-record-circle-fill"></i><span>Medicine Ball</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('')"><i class="bi bi-three-dots"></i><span>Other</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('band')"><i class="bi bi-link-45deg"></i><span>Resistance Band</span></a>
  <a class="ex2-equip-box" onclick="setEx2Equip('stability')"><i class="bi bi-disc-fill"></i><span>Stability ball</span></a>
</div>

<!-- SEARCH -->
<div class="ex2-search-wrap">
  <i class="bi bi-search si"></i>
  <input type="text" id="ex2SearchInput" placeholder="Search..." oninput="ex2Render()">
</div>

<!-- EXERCISE CARDS GRID -->
<div class="ex2-grid" id="ex2Grid"></div>
<div class="ex2-load" id="ex2LoadWrap"><button onclick="ex2LoadMore()">Load More <i class="bi bi-chevron-down"></i></button></div>

<script>
var EX2_DATA=[
  {id:'90-degree-alternate-heel-touch',name:'90 Degree Alternate Heel Touch',desc:'Trains controlled side bending for core control and coordination through slow, precise movement.',muscle:'Abs / Core',equip:'Bodyweight',tags:['Core','HIIT','Bodybuilding'],img:'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80',cat:'abs'},
  {id:'90-degree-heel-touch',name:'90 Degree Heel Touch',desc:'Builds controlled side-to-side core tension, helping improve stability and coordination.',muscle:'Abs / Core',equip:'Bodyweight',tags:['Core','HIIT','Bodybuilding'],img:'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80',cat:'abs'},
  {id:'90-90-stretch',name:'90/90 Stretch',desc:'Improves hip mobility and control by guiding your hips through a stable, seated rotation position.',muscle:'Hips',equip:'Bodyweight',tags:['Stretching','Mobility','Recovery','Cool-down'],img:'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=80',cat:'stretching'},
  {id:'abdominal-air-bike',name:'Abdominal Air Bike',desc:'Bodyweight core exercise combining controlled rotation with steady tension to build strength and endurance.',muscle:'Abs / Core',equip:'Bodyweight',tags:['Cardio','Endurance','HIIT','Crossfit'],img:'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80',cat:'abs'},
  {id:'alternate-heel-touchers',name:'Alternate Heel Touchers',desc:'Simple core exercise that builds control and endurance using small side-to-side movements under tension.',muscle:'Abs / Core',equip:'Bodyweight',tags:['Core','Endurance','HIIT','Recovery'],img:'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80',cat:'abs'},
  {id:'alternate-leg-raise',name:'Alternate Leg Raise',desc:'Controlled core exercise that builds strength and stability by lifting one leg at a time while staying steady.',muscle:'Abs / Core',equip:'Bodyweight',tags:['Core','Endurance','HIIT'],img:'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=600&q=80',cat:'abs'},
  {id:'barbell-bench-press',name:'Barbell Bench Press',desc:'Foundational chest exercise used to build upper-body pushing strength with a barbell on a flat bench.',muscle:'Chest',equip:'Barbell',tags:['Strength','Powerlifting','Bodybuilding'],img:'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&q=80',cat:'chest'},
  {id:'barbell-squat',name:'Barbell Squat',desc:'Foundational lower-body compound movement that builds strength in quads, glutes and the posterior chain.',muscle:'Legs',equip:'Barbell',tags:['Strength','Powerlifting','Bodybuilding'],img:'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&q=80',cat:'legs'},
  {id:'barbell-deadlift',name:'Barbell Deadlift',desc:'Foundational strength exercise that builds full-body power and proper lifting mechanics from the floor.',muscle:'Legs / Back',equip:'Barbell',tags:['Strength','Powerlifting','Bodybuilding'],img:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80',cat:'back'},
  {id:'barbell-curl',name:'Barbell Curl',desc:'Basic arm exercise that builds strength and size by lifting a bar through a controlled bending motion.',muscle:'Arms',equip:'Barbell',tags:['Strength','Bodybuilding'],img:'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=600&q=80',cat:'arms'},
  {id:'barbell-hip-thrust',name:'Barbell Hip Thrust',desc:'Compound lower-body strength exercise that builds glute power through loaded hip extension movement.',muscle:'Glutes',equip:'Barbell',tags:['Strength','Bodybuilding','Powerlifting'],img:'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=600&q=80',cat:'glutes'},
  {id:'barbell-bent-over-row',name:'Barbell Bent Over Row',desc:'Powerful compound exercise that builds back strength, improves posture and supports overall pulling performance.',muscle:'Back',equip:'Barbell',tags:['Strength','Bodybuilding','Powerlifting'],img:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80',cat:'back'},
  {id:'barbell-front-raise',name:'Barbell Front Raise',desc:'Builds shoulder strength and control by lifting a fixed bar through a controlled front-to-shoulder range.',muscle:'Shoulders',equip:'Barbell',tags:['Strength','Bodybuilding'],img:'https://images.unsplash.com/photo-1532029837206-abbe267f536e?w=600&q=80',cat:'shoulders'},
  {id:'band-resisted-push-up',name:'Band Resisted Push Up',desc:'Push-up variation that increases upper-body strength by adding band resistance to the pressing movement.',muscle:'Chest',equip:'Band',tags:['Strength','HIIT','Bodybuilding'],img:'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&q=80',cat:'chest'},
  {id:'assisted-pull-up',name:'Assisted Pull-Up',desc:'Helps build pulling strength by reducing bodyweight resistance making it easier to learn proper technique.',muscle:'Back',equip:'Machine',tags:['Strength','Bodybuilding','HIIT'],img:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80',cat:'back'},
  {id:'assault-bike-run',name:'Assault Bike Run',desc:'Full-body conditioning movement that uses steady pedaling and pushing to build stamina and work capacity.',muscle:'Full Body',equip:'Machine',tags:['Endurance','Cardio','HIIT','Crossfit'],img:'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&q=80',cat:'cardio'},
  {id:'barbell-lunge',name:'Barbell Lunge',desc:'Compound lower-body exercise that builds leg strength, balance and control through unilateral loading.',muscle:'Legs',equip:'Barbell',tags:['Strength','Bodybuilding','HIIT'],img:'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&q=80',cat:'legs'},
  {id:'barbell-clean-and-jerk',name:'Barbell Clean And Jerk',desc:'Explosive full-body lift that builds power, coordination and total-body strength in one fluid movement.',muscle:'Full Body',equip:'Barbell',tags:['Strength','Crossfit','Powerlifting'],img:'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=600&q=80',cat:'crossfit'},
  {id:'back-extension-stability-ball',name:'Back Extension On Stability Ball',desc:'Controlled bodyweight exercise that strengthens the lower back while improving balance and core control.',muscle:'Back',equip:'Stability',tags:['Strength','Core','Recovery'],img:'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600&q=80',cat:'back'}
];
var ex2Cat='',ex2Equip='',ex2Page=1,ex2PageSize=8;
var ex2ServerImages={};
var EX2_IMG_API='${pageContext.request.contextPath}/api/exercise-images';

function ex2LoadServerImages(cb){
  fetch(EX2_IMG_API+'/list').then(function(r){return r.json();}).then(function(ids){
    ex2ServerImages={};
    ids.forEach(function(id){ex2ServerImages[id]=true;});
    if(cb)cb();
  }).catch(function(){if(cb)cb();});
}
function ex2ImgUrl(id){return EX2_IMG_API+'?id='+encodeURIComponent(id);}

function ex2Filtered(){
  var q=(document.getElementById('ex2SearchInput')||{}).value||'';
  q=q.toLowerCase();
  return EX2_DATA.filter(function(e){
    if(ex2Cat&&e.cat!==ex2Cat&&e.tags.join(' ').toLowerCase().indexOf(ex2Cat)<0)return false;
    if(ex2Equip&&e.equip.toLowerCase().indexOf(ex2Equip)<0)return false;
    if(q&&e.name.toLowerCase().indexOf(q)<0&&e.desc.toLowerCase().indexOf(q)<0&&e.tags.join(' ').toLowerCase().indexOf(q)<0)return false;
    return true;
  });
}
function ex2Render(){
  ex2Page=1;ex2Draw();
}
function ex2Draw(){
  var list=ex2Filtered();
  var vis=list.slice(0,ex2Page*ex2PageSize);
  var g=document.getElementById('ex2Grid');
  var lw=document.getElementById('ex2LoadWrap');
  lw.style.display=vis.length<list.length?'block':'none';
  var html='';
  vis.forEach(function(e,i){
    var hasServerImg=!!ex2ServerImages[e.id];
    var customImg=!hasServerImg&&e.id?localStorage.getItem('eximg_'+e.id):null;
    var imgSrc=hasServerImg?ex2ImgUrl(e.id):(customImg||null);
    var hasCustomCls=imgSrc?' has-custom':'';
    var customBadge=hasServerImg?'<div class="ex2-custom-badge"><i class="bi bi-check2"></i> CUSTOM</div>':'';
    var imgContent=imgSrc
      ?'<img src="'+imgSrc+'" alt="'+e.name+'" loading="lazy">'
      :'<div class="ex2-no-img"><i class="bi bi-camera"></i><span>Admin Upload Pending</span></div>';
    var tags=e.tags.slice(0,3).map(function(t){return'<span class="ex2-pill">'+t+'</span>';}).join('');
    var extra=e.tags.length>3?'<span class="ex2-pill">+'+(e.tags.length-3)+'</span>':'';
    html+='<div class="ex2-card'+hasCustomCls+'" onclick="openExDetail(\''+e.id+'\')">'; 
    html+='<div class="ex2-img">'+imgContent+'<div class="ex2-img-overlay"></div><div class="ex2-img-shimmer"></div>'+customBadge+'</div>';
    html+='<div class="ex2-body">';
    html+='<div class="ex2-cname">'+e.name+'</div>';
    html+='<div class="ex2-cdesc">'+e.desc+'</div>';
    html+='<div class="ex2-tags">'+tags+extra+'</div>';
    html+='<div class="ex2-foot"><div class="ex2-equip-lbl"><i class="bi bi-grid-3x3-gap-fill"></i>'+e.equip+'</div><div class="ex2-arr"><i class="bi bi-arrow-up-right"></i></div></div>';
    html+='</div></div>';
  });
  if(vis.length===0)html='<div style="grid-column:1/-1;text-align:center;padding:4rem;color:rgba(255,255,255,.25)"><i class="bi bi-search" style="font-size:2.5rem;display:block;margin-bottom:1rem"></i><div style="font-size:.85rem">No exercises found. Try a different filter or search term.</div></div>';
  g.innerHTML=html;
}
function ex2LoadMore(){ex2Page++;ex2Draw();}
function setEx2Filter(cat){ex2Cat=cat;ex2Equip='';ex2Render();}
function setEx2Equip(eq){ex2Equip=eq;ex2Cat='';ex2Render();}
document.addEventListener('DOMContentLoaded',function(){ex2LoadServerImages(ex2Draw);});
// Refresh cards whenever the exercise tab is activated so admin-uploaded images appear instantly
document.querySelectorAll('.si[onclick*="exercise"]').forEach(function(btn){
  btn.addEventListener('click',function(){ex2LoadServerImages(ex2Draw);});
});
// Exercise image refresh is handled by the click listener above (lines 808-810)
</script>
<script src="${pageContext.request.contextPath}/static/js/exercise-detail.js"></script>
</div>


<!-- NUTRITION -->
<div class="mp-sec" id="sec-nutrition">
<h2 class="sec-title">NUTRITION <span>INTELLIGENCE</span><span class="sample-badge"><i class="bi bi-info-circle"></i> Sample Data</span></h2>
<div class="mp-grid3">
<div class="mp-card" style="grid-column:span 2">
<h4><i class="bi bi-pie-chart-fill"></i> Daily Macros</h4>
<div style="display:flex;align-items:center;gap:2rem;flex-wrap:wrap">
<div style="width:150px;height:150px"><canvas id="macroChart"></canvas></div>
<div style="flex:1;min-width:200px">
<div class="ir"><div class="ir-lbl" style="width:60px">Protein</div><div class="pbar" style="flex:1;margin-top:0"><div class="pbar-fill green" style="width:75%"></div></div><div class="ir-val" style="width:60px;text-align:right">160/200g</div></div>
<div class="ir"><div class="ir-lbl" style="width:60px">Carbs</div><div class="pbar" style="flex:1;margin-top:0"><div class="pbar-fill blue" style="width:60%"></div></div><div class="ir-val" style="width:60px;text-align:right">220/300g</div></div>
<div class="ir"><div class="ir-lbl" style="width:60px">Fats</div><div class="pbar" style="flex:1;margin-top:0"><div class="pbar-fill red" style="width:80%"></div></div><div class="ir-val" style="width:60px;text-align:right">65/80g</div></div>
</div>
</div>
</div>
<div class="ai-card">
<div class="ai-tag"><i class="bi bi-stars"></i> AI Recommendation</div>
<h4>Post-Workout Meal</h4>
<p>Your muscle recovery needs a boost. We suggest a high-protein meal: Grilled Salmon with Quinoa within the next hour.</p>
<button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openModal('groceryListModal')"><i class="bi bi-basket"></i> View Grocery List</button>
</div>
</div>
<div class="mp-grid2" style="margin-top:1.5rem">
<div class="mp-card">
<h4><i class="bi bi-card-checklist"></i> Diet Preferences</h4>
<div class="toggle-wrap"><div class="toggle-label">Vegan Diet<div class="toggle-sub">No animal products</div></div><button class="toggle-switch" onclick="toggleSwitch(this)"></button></div>
<div class="toggle-wrap"><div class="toggle-label">Keto Friendly<div class="toggle-sub">Low carb, high fat</div></div><button class="toggle-switch" onclick="toggleSwitch(this)"></button></div>
<div class="toggle-wrap"><div class="toggle-label">Intermittent Fasting<div class="toggle-sub">16:8 protocol</div></div><button class="toggle-switch on" onclick="toggleSwitch(this)"></button></div>
</div>
<div class="mp-card">
<h4><i class="bi bi-fire"></i> Cheat Meal Allowance</h4>
<div style="font-size:2rem;font-weight:700;color:var(--accent);line-height:1">1 <span style="font-size:.9rem;color:var(--gray)">remaining this week</span></div>
<div class="pbar" style="margin:1rem 0"><div class="pbar-fill yellow" style="width:50%"></div></div>
<button class="btn-solid" style="width:100%" onclick="showToast('Cheat meal logged! Enjoy it guilt-free.','success')">Log Cheat Meal</button>
</div>
</div>
</div>

<!-- MEALS -->
<div class="mp-sec" id="sec-meals">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem"><h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin:0">MY <span style="color:var(--accent)">MEAL PLAN</span></h2><button class="btn-g"><i class="bi bi-download"></i> Download PDF</button></div>
<div class="mp-grid4" style="margin-bottom:1.5rem">
<div class="ms"><div class="ms-icon blue"><i class="bi bi-droplet"></i></div><div class="ms-val">2.5<span style="font-size:.8rem;color:var(--gray)">L</span></div><div class="ms-lbl">Water Logged</div></div>
<div class="ms"><div class="ms-icon red"><i class="bi bi-fire"></i></div><div class="ms-val">2200</div><div class="ms-lbl">Target Cal</div></div>
<div class="ms"><div class="ms-icon green"><i class="bi bi-egg-fried"></i></div><div class="ms-val">160<span style="font-size:.8rem;color:var(--gray)">g</span></div><div class="ms-lbl">Protein</div></div>
<div class="ms"><div class="ms-icon yellow"><i class="bi bi-pie-chart"></i></div><div class="ms-val">40<span style="font-size:.8rem;color:var(--gray)">%</span></div><div class="ms-lbl">Carbs</div></div></div>
<div class="mp-grid3">
<div class="meal-card"><div style="display:flex;justify-content:space-between"><div class="meal-time">Breakfast</div><i class="bi bi-check-circle-fill" style="color:var(--success)"></i></div><div class="meal-name">Oatmeal & Protein Shake</div><div class="meal-cal">450 kcal</div><div class="macro-row"><div class="macro" style="color:var(--accent)">P: 35g</div><div class="macro" style="color:#fbbf24">C: 50g</div><div class="macro" style="color:#f87171">F: 10g</div></div></div>
<div class="meal-card"><div style="display:flex;justify-content:space-between"><div class="meal-time">Lunch</div><i class="bi bi-circle" style="color:var(--gray)"></i></div><div class="meal-name">Grilled Chicken Salad</div><div class="meal-cal">550 kcal</div><div class="macro-row"><div class="macro" style="color:var(--accent)">P: 45g</div><div class="macro" style="color:#fbbf24">C: 20g</div><div class="macro" style="color:#f87171">F: 25g</div></div></div>
<div class="meal-card"><div style="display:flex;justify-content:space-between"><div class="meal-time">Dinner</div><i class="bi bi-circle" style="color:var(--gray)"></i></div><div class="meal-name">Salmon & Sweet Potato</div><div class="meal-cal">600 kcal</div><div class="macro-row"><div class="macro" style="color:var(--accent)">P: 40g</div><div class="macro" style="color:#fbbf24">C: 45g</div><div class="macro" style="color:#f87171">F: 20g</div></div></div>
</div></div>

<!-- SUPPS -->
<div class="mp-sec" id="sec-supps">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:1.5rem">SUPPLEMENTS <span style="color:var(--accent)">& NUTRITION</span></h2>
<div class="mp-grid4" style="gap:1.5rem">
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/image-removebg-preview_19_b6335e67-cb44-4e3c-aa33-0e5f7e0d6a5d_1024x1024.png" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">MuscleTech Nitro Tech Whey</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 15,000</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('MuscleTech Nitro Tech Whey', 15000)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/image-removebg-preview_15_ebae186e-6a80-49ad-9d7b-d4faeeadb1a0_1024x1024.png" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">Applied Nutrition Critical Whey</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 14,500</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('Applied Nutrition Critical Whey', 14500)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/5146_0f4b0454aca7_1024x1024.webp" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">Scitec Nutrition 100% Whey Pro</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 16,000</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('Scitec Nutrition 100% Whey Pro', 16000)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/DymatizeISO100_1024x1024.png" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">Dymatize ISO100 Hydrolyzed</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 18,000</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('Dymatize ISO100 Hydrolyzed', 18000)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/MusclemedsCarnivore4lbs_1024x1024.png" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">Musclemeds Carnivore Beef</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 15,500</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('Musclemeds Carnivore Beef', 15500)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/NitroTechwheyGold2.27KG_1024x1024.png" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">Nitrotech 100% Whey Gold</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 17,000</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('Nitrotech 100% Whey Gold', 17000)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/extremegold_1024x1024.jpg" style="max-height:100%;max-width:100%;object-fit:cover;border-radius:8px"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">ON Gold Standard Whey</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 20,000</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('ON Gold Standard Whey', 20000)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
<div class="supp-card" style="text-align:center;padding:1.5rem;background:var(--card);border:1px solid var(--border);border-radius:16px">
  <div style="height:140px;display:flex;align-items:center;justify-content:center;margin-bottom:1rem"><img src="https://fitnessisland.lk/cdn/shop/files/image-removebg-preview_22_2830b01d-d93f-40a7-a2d0-ae6a34c53586_1024x1024.png" style="max-height:100%;max-width:100%;object-fit:contain"></div>
  <div class="supp-name" style="font-weight:700;font-size:.95rem;margin-bottom:.5rem;min-height:40px">BPI ISO HD Isolate Protein</div>
  <div class="supp-use" style="color:var(--accent);font-size:1.1rem;font-weight:700">Rs. 16,500</div>
  <button class="btn-g" style="margin-top:1rem;width:100%;justify-content:center" onclick="openCheckout('BPI ISO HD Isolate', 16500)"><i class="bi bi-cart-plus"></i> Buy Now</button>
</div>
</div></div>

<!-- ACHIEVEMENTS -->
<div class="mp-sec" id="sec-achieve">
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:1.5rem">
  <h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin:0">AWARDS & <span style="color:var(--accent)">ACHIEVEMENTS</span></h2>
  <div style="display:flex;gap:.5rem">
    <button class="btn-g" onclick="openModal('challengeModal')"><i class="bi bi-flag-fill"></i> Challenges</button>
    <button class="btn-g" onclick="shareAchievements()"><i class="bi bi-share"></i> Share</button>
  </div>
</div>

<!-- XP Level Hero -->
<div class="neon-card" style="display:flex;align-items:center;gap:2rem;padding:2rem;margin-bottom:1.5rem;flex-wrap:wrap">
  <div style="position:relative;width:100px;height:100px;flex-shrink:0">
    <svg viewBox="0 0 120 120" width="100" height="100" style="transform:rotate(-90deg)">
      <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="10"/>
      <circle cx="60" cy="60" r="52" fill="none" stroke="#fbbf24" stroke-width="10" stroke-linecap="round" stroke-dasharray="327" stroke-dashoffset="98" id="xpRing"/>
    </svg>
    <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
      <div style="font-size:.55rem;color:var(--gray);letter-spacing:1px">LEVEL</div>
      <div style="font-family:var(--font-display);font-size:2.5rem;color:#fbbf24;line-height:1">12</div>
    </div>
  </div>
  <div style="flex:1;min-width:200px">
    <div style="font-size:.65rem;color:#fbbf24;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:.3rem">Fitness Warrior</div>
    <div style="font-size:.85rem;font-weight:600;margin-bottom:.6rem"><span data-bind="xp">2,340</span> / 3,000 XP to Level 13</div>
    <div class="pbar" style="height:10px;border-radius:5px;margin:0"><div class="pbar-fill" style="width:78%;background:linear-gradient(90deg,#fbbf24,var(--accent));border-radius:5px"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.65rem;color:var(--gray);margin-top:.3rem"><span>660 XP to next level</span><span style="color:var(--accent);font-weight:700">78%</span></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:.5rem;min-width:180px">
    <div style="text-align:center;padding:.5rem;background:rgba(251,191,36,.05);border-radius:10px;border:1px solid rgba(251,191,36,.15)"><div style="font-family:var(--font-display);font-size:1.3rem;color:#fbbf24">47</div><div style="font-size:.55rem;color:var(--gray)">WORKOUTS</div></div>
    <div style="text-align:center;padding:.5rem;background:rgba(200,240,61,.05);border-radius:10px;border:1px solid rgba(200,240,61,.15)"><div style="font-family:var(--font-display);font-size:1.3rem;color:var(--accent)">4/8</div><div style="font-size:.55rem;color:var(--gray)">BADGES</div></div>
    <div style="text-align:center;padding:.5rem;background:rgba(248,113,113,.05);border-radius:10px;border:1px solid rgba(248,113,113,.15)"><div style="font-family:var(--font-display);font-size:1.3rem;color:#f87171" data-bind="streak">7</div><div style="font-size:.55rem;color:var(--gray)">DAY STREAK</div></div>
    <div style="text-align:center;padding:.5rem;background:rgba(96,165,250,.05);border-radius:10px;border:1px solid rgba(96,165,250,.15)"><div style="font-family:var(--font-display);font-size:1.3rem;color:#60a5fa">#3</div><div style="font-size:.55rem;color:var(--gray)">RANK</div></div>
  </div>
</div>

<!-- Streak Tracker -->
<div class="mp-card" style="margin-bottom:1.5rem">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem"><h4 style="margin:0"><i class="bi bi-fire"></i> Current Streak</h4><div style="display:inline-flex;align-items:center;gap:.3rem;padding:.25rem .7rem;border-radius:50px;background:rgba(248,113,113,.1);color:#f87171;font-size:.7rem;font-weight:700"><i class="bi bi-fire"></i> 7 Day Streak!</div></div>
  <div style="display:flex;gap:.4rem;flex-wrap:wrap" id="streakDays">
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.08);border:1px solid rgba(200,240,61,.2)"><div style="font-size:.6rem;color:var(--gray)">MON</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+50 XP</div></div>
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.08);border:1px solid rgba(200,240,61,.2)"><div style="font-size:.6rem;color:var(--gray)">TUE</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+50 XP</div></div>
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.08);border:1px solid rgba(200,240,61,.2)"><div style="font-size:.6rem;color:var(--gray)">WED</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+50 XP</div></div>
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.08);border:1px solid rgba(200,240,61,.2)"><div style="font-size:.6rem;color:var(--gray)">THU</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+50 XP</div></div>
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.08);border:1px solid rgba(200,240,61,.2)"><div style="font-size:.6rem;color:var(--gray)">FRI</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+50 XP</div></div>
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.08);border:1px solid rgba(200,240,61,.2)"><div style="font-size:.6rem;color:var(--gray)">SAT</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+50 XP</div></div>
    <div style="flex:1;min-width:80px;text-align:center;padding:.6rem .3rem;border-radius:10px;background:rgba(200,240,61,.12);border:2px solid var(--accent)"><div style="font-size:.6rem;color:var(--accent);font-weight:700">TODAY</div><div style="font-size:1rem;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="font-size:.55rem;color:var(--accent);font-weight:700">+100 XP</div></div>
  </div>
</div>

<!-- Badges + Leaderboard -->
<div class="mp-grid3">
<div class="mp-card" style="grid-column:span 2">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem"><h4 style="margin:0"><i class="bi bi-award"></i> My Badges</h4><span style="font-size:.72rem;color:var(--gray)">4 of 8 unlocked</span></div>
<div class="badge-grid">
<div class="badge-item unlocked" style="cursor:pointer" onclick="showBadgeDetail('First Blood','Completed your very first workout at Apex Fitness!','fire','+100 XP')"><div class="badge-icon"><i class="bi bi-fire"></i></div><div class="badge-name">First Blood</div><div class="badge-desc">Completed 1st workout</div></div>
<div class="badge-item unlocked" style="cursor:pointer" onclick="showBadgeDetail('7-Day Streak','Worked out 7 days in a row!','lightning-fill','+200 XP')"><div class="badge-icon"><i class="bi bi-lightning-fill"></i></div><div class="badge-name">7-Day Streak</div><div class="badge-desc">7 days straight</div></div>
<div class="badge-item unlocked" style="cursor:pointer" onclick="showBadgeDetail('Hydro King','Logged 3L water for 5 days!','droplet-fill','+150 XP')"><div class="badge-icon"><i class="bi bi-droplet-fill"></i></div><div class="badge-name">Hydro King</div><div class="badge-desc">3L water 5 days</div></div>
<div class="badge-item unlocked" style="cursor:pointer" onclick="showBadgeDetail('Deep Sleep','Recorded 8+ hours of quality sleep!','moon-stars-fill','+100 XP')"><div class="badge-icon"><i class="bi bi-moon-stars-fill"></i></div><div class="badge-name">Deep Sleep</div><div class="badge-desc">8 hours sleep recorded</div></div>
<div class="badge-item locked" style="cursor:pointer" onclick="showBadgeDetail('30-Day Streak','Work out 30 consecutive days. 7/30 done.','trophy-fill','Locked')"><div class="badge-icon"><i class="bi bi-trophy-fill"></i></div><div class="badge-name">30-Day Streak</div><div class="badge-desc">7/30 days</div><div class="pbar" style="margin-top:.3rem"><div class="pbar-fill green" style="width:23%"></div></div></div>
<div class="badge-item locked" style="cursor:pointer" onclick="showBadgeDetail('Iron Pusher','Lift 10,000kg total. 6,200/10,000.','speedometer2','Locked')"><div class="badge-icon"><i class="bi bi-speedometer2"></i></div><div class="badge-name">Iron Pusher</div><div class="badge-desc">6,200/10,000 kg</div><div class="pbar" style="margin-top:.3rem"><div class="pbar-fill blue" style="width:62%"></div></div></div>
<div class="badge-item locked" style="cursor:pointer" onclick="showBadgeDetail('Cardio Bunny','Run 50km total. 32/50km.','bicycle','Locked')"><div class="badge-icon"><i class="bi bi-bicycle"></i></div><div class="badge-name">Cardio Bunny</div><div class="badge-desc">32/50 km</div><div class="pbar" style="margin-top:.3rem"><div class="pbar-fill red" style="width:64%"></div></div></div>
<div class="badge-item locked" style="cursor:pointer" onclick="showBadgeDetail('Apex Legend','1 year membership. 4/12 months.','star-fill','Locked')"><div class="badge-icon"><i class="bi bi-star-fill"></i></div><div class="badge-name">Apex Legend</div><div class="badge-desc">4/12 months</div><div class="pbar" style="margin-top:.3rem"><div class="pbar-fill yellow" style="width:33%"></div></div></div>
</div>
</div>

<div class="mp-card">
<h4><i class="bi bi-list-ol"></i> Weekly Leaderboard</h4>
<div class="lb-row"><div class="lb-rank gold">1</div><div class="lb-name">Alex Johnson</div><div class="lb-pts">2,450</div></div>
<div class="lb-row"><div class="lb-rank silver">2</div><div class="lb-name">Sarah Connor</div><div class="lb-pts">2,100</div></div>
<div class="lb-row" style="background:rgba(200,240,61,.05);border:1px solid rgba(200,240,61,.15);border-radius:10px"><div class="lb-rank bronze">3</div><div class="lb-name me">You</div><div class="lb-pts">1,850</div></div>
<div class="lb-row"><div class="lb-rank normal">4</div><div class="lb-name">Mike Tyson</div><div class="lb-pts">1,600</div></div>
<div class="lb-row"><div class="lb-rank normal">5</div><div class="lb-name">Bruce Lee</div><div class="lb-pts">1,420</div></div>
<div id="lbExtra" style="max-height:0;overflow:hidden;transition:max-height .4s ease">
<div class="lb-row"><div class="lb-rank normal">6</div><div class="lb-name">Kasun Silva</div><div class="lb-pts">1,380</div></div>
<div class="lb-row"><div class="lb-rank normal">7</div><div class="lb-name">Priya Jayasuriya</div><div class="lb-pts">1,250</div></div>
<div class="lb-row"><div class="lb-rank normal">8</div><div class="lb-name">Daniel Perera</div><div class="lb-pts">1,190</div></div>
<div class="lb-row"><div class="lb-rank normal">9</div><div class="lb-name">Nadeesha Silva</div><div class="lb-pts">1,100</div></div>
<div class="lb-row"><div class="lb-rank normal">10</div><div class="lb-name">Ravi Mendis</div><div class="lb-pts">980</div></div>
</div>
<button class="btn-g" id="lbToggleBtn" style="margin-top:1rem;width:100%;justify-content:center" onclick="toggleLeaderboard()"><i class="bi bi-chevron-down"></i> View Full Standings</button>
</div>
</div>

<!-- Challenges Modal -->
<div class="modal-overlay" id="challengeModal">
<div class="modal-box wide">
<button class="modal-close" onclick="closeModal('challengeModal')">&times;</button>
<h3 class="m-title">ACTIVE <span style="color:var(--accent)">CHALLENGES</span></h3>
<div style="display:flex;flex-direction:column;gap:.8rem">
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:46px;height:46px;border-radius:12px;background:rgba(200,240,61,.1);display:flex;align-items:center;justify-content:center;color:var(--accent);font-size:1.2rem"><i class="bi bi-fire"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">Burn 2,000 Calories</div><div style="font-size:.68rem;color:var(--gray)">This week &middot; 300 XP</div><div class="pbar" style="margin-top:.4rem"><div class="pbar-fill green" style="width:65%"></div></div><div style="font-size:.6rem;color:var(--accent);margin-top:.2rem">1,300 / 2,000 kcal</div></div></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:46px;height:46px;border-radius:12px;background:rgba(96,165,250,.1);display:flex;align-items:center;justify-content:center;color:#60a5fa;font-size:1.2rem"><i class="bi bi-people-fill"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">Attend 3 Group Classes</div><div style="font-size:.68rem;color:var(--gray)">This week &middot; 200 XP</div><div class="pbar" style="margin-top:.4rem"><div class="pbar-fill blue" style="width:33%"></div></div><div style="font-size:.6rem;color:#60a5fa;margin-top:.2rem">1 / 3 classes</div></div></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:46px;height:46px;border-radius:12px;background:rgba(52,211,153,.1);display:flex;align-items:center;justify-content:center;color:#34d399;font-size:1.2rem"><i class="bi bi-droplet-fill"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">Hydration Hero</div><div style="font-size:.68rem;color:var(--gray)">Log 2L daily for 5 days &middot; 250 XP</div><div class="pbar" style="margin-top:.4rem"><div class="pbar-fill" style="width:80%;background:#34d399"></div></div><div style="font-size:.6rem;color:#34d399;margin-top:.2rem">4 / 5 days</div></div></div>
</div>
</div></div>

<!-- Badge Detail Modal -->
<div class="modal-overlay" id="badgeDetailModal">
<div class="modal-box narrow" style="text-align:center">
<button class="modal-close" onclick="closeModal('badgeDetailModal')">&times;</button>
<div style="width:80px;height:80px;border-radius:50%;background:rgba(200,240,61,.1);display:flex;align-items:center;justify-content:center;margin:1rem auto;font-size:2rem;color:var(--accent)" id="bdIcon"></div>
<h3 class="m-title" id="bdName"></h3>
<p style="color:var(--gray);font-size:.85rem;margin-bottom:1rem" id="bdDesc"></p>
<div style="display:inline-flex;padding:.3rem .8rem;border-radius:50px;font-size:.75rem;font-weight:700;margin-bottom:1rem" id="bdXP"></div>
<button class="btn-solid" style="width:100%;padding:.75rem" onclick="closeModal('badgeDetailModal')">Close</button>
</div></div>

<script>
function toggleLeaderboard(){var el=document.getElementById('lbExtra'),btn=document.getElementById('lbToggleBtn');if(el.style.maxHeight==='0px'||el.style.maxHeight==='0'){el.style.maxHeight=el.scrollHeight+'px';btn.innerHTML='<i class="bi bi-chevron-up"></i> Show Top 5';}else{el.style.maxHeight='0';btn.innerHTML='<i class="bi bi-chevron-down"></i> View Full Standings';}}
function showBadgeDetail(name,desc,icon,xp){document.getElementById('bdName').textContent=name;document.getElementById('bdDesc').textContent=desc;document.getElementById('bdIcon').innerHTML='<i class="bi bi-'+icon+'"></i>';var el=document.getElementById('bdXP');el.textContent=xp;if(xp==='Locked'){el.style.background='rgba(255,255,255,.05)';el.style.color='var(--gray)';}else{el.style.background='rgba(200,240,61,.1)';el.style.color='var(--accent)';}openModal('badgeDetailModal');}
function shareAchievements(){openModal('shareModal');}
window.showBadgeDetail=showBadgeDetail;window.shareAchievements=shareAchievements;window.toggleLeaderboard=toggleLeaderboard;
</script>

<!-- Share Modal -->
<div class="modal-overlay" id="shareModal">
<div class="modal-box" style="max-width:480px;padding:0;overflow-y:auto;max-height:90vh">
<button class="modal-close" onclick="closeModal('shareModal')" style="z-index:2;top:1rem;right:1rem;color:rgba(255,255,255,.5)">&times;</button>

<!-- Header -->
<div style="background:linear-gradient(135deg,rgba(200,240,61,.08),rgba(251,191,36,.04));padding:1.8rem 2rem 1.2rem;border-bottom:1px solid rgba(200,240,61,.1)">
  <div style="display:flex;align-items:center;gap:.8rem;margin-bottom:.6rem">
    <div style="width:44px;height:44px;border-radius:14px;background:rgba(200,240,61,.12);border:1px solid rgba(200,240,61,.2);display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:var(--accent)"><i class="bi bi-share-fill"></i></div>
    <div>
      <div style="font-family:var(--font-display);font-size:1.4rem;letter-spacing:1px">SHARE <span style="color:var(--accent)">ACHIEVEMENTS</span></div>
      <div style="font-size:.7rem;color:var(--gray)">Show off your fitness progress</div>
    </div>
  </div>
  <!-- Preview Card -->
  <div style="padding:.7rem 1rem;background:rgba(0,0,0,.3);border-radius:12px;border:1px solid rgba(200,240,61,.08)">
    <div style="display:flex;align-items:center;gap:.6rem">
      <div style="font-size:1.4rem">🏆</div>
      <div>
        <div style="font-size:.78rem;font-weight:700">Level 12 — Fitness Warrior</div>
        <div style="font-size:.65rem;color:var(--gray)">4 Badges • 7 Day Streak • Rank #3</div>
      </div>
    </div>
  </div>
</div>

<!-- Share Options -->
<div style="padding:1.5rem 2rem 2rem">
  <div style="font-size:.68rem;font-weight:700;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:.8rem">Share via</div>

  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.6rem;margin-bottom:1.2rem">
    <!-- WhatsApp -->
    <button onclick="shareVia('whatsapp')" style="display:flex;flex-direction:column;align-items:center;gap:.4rem;padding:.9rem .5rem;background:rgba(37,211,102,.06);border:1px solid rgba(37,211,102,.15);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='rgba(37,211,102,.15)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(37,211,102,.06)';this.style.transform='none'">
      <i class="bi bi-whatsapp" style="font-size:1.5rem;color:#25d366"></i>
      <span style="font-size:.68rem;font-weight:600">WhatsApp</span>
    </button>
    <!-- Email -->
    <button onclick="shareVia('email')" style="display:flex;flex-direction:column;align-items:center;gap:.4rem;padding:.9rem .5rem;background:rgba(96,165,250,.06);border:1px solid rgba(96,165,250,.15);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='rgba(96,165,250,.15)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(96,165,250,.06)';this.style.transform='none'">
      <i class="bi bi-envelope-fill" style="font-size:1.5rem;color:#60a5fa"></i>
      <span style="font-size:.68rem;font-weight:600">Email</span>
    </button>
    <!-- Facebook -->
    <button onclick="shareVia('facebook')" style="display:flex;flex-direction:column;align-items:center;gap:.4rem;padding:.9rem .5rem;background:rgba(66,103,178,.06);border:1px solid rgba(66,103,178,.15);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='rgba(66,103,178,.15)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(66,103,178,.06)';this.style.transform='none'">
      <i class="bi bi-facebook" style="font-size:1.5rem;color:#4267B2"></i>
      <span style="font-size:.68rem;font-weight:600">Facebook</span>
    </button>
    <!-- Twitter/X -->
    <button onclick="shareVia('twitter')" style="display:flex;flex-direction:column;align-items:center;gap:.4rem;padding:.9rem .5rem;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='rgba(255,255,255,.08)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(255,255,255,.03)';this.style.transform='none'">
      <i class="bi bi-twitter-x" style="font-size:1.5rem;color:#fff"></i>
      <span style="font-size:.68rem;font-weight:600">X</span>
    </button>
    <!-- LinkedIn -->
    <button onclick="shareVia('linkedin')" style="display:flex;flex-direction:column;align-items:center;gap:.4rem;padding:.9rem .5rem;background:rgba(10,102,194,.06);border:1px solid rgba(10,102,194,.15);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='rgba(10,102,194,.15)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(10,102,194,.06)';this.style.transform='none'">
      <i class="bi bi-linkedin" style="font-size:1.5rem;color:#0a66c2"></i>
      <span style="font-size:.68rem;font-weight:600">LinkedIn</span>
    </button>
    <!-- Copy Link -->
    <button onclick="shareVia('copy')" style="display:flex;flex-direction:column;align-items:center;gap:.4rem;padding:.9rem .5rem;background:rgba(200,240,61,.04);border:1px solid rgba(200,240,61,.12);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='rgba(200,240,61,.1)';this.style.transform='translateY(-2px)'" onmouseout="this.style.background='rgba(200,240,61,.04)';this.style.transform='none'">
      <i class="bi bi-link-45deg" style="font-size:1.5rem;color:var(--accent)"></i>
      <span style="font-size:.68rem;font-weight:600">Copy Link</span>
    </button>
  </div>

  <!-- Divider -->
  <div style="display:flex;align-items:center;gap:.8rem;margin-bottom:1.2rem">
    <div style="flex:1;height:1px;background:rgba(255,255,255,.06)"></div>
    <span style="font-size:.65rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">or download</span>
    <div style="flex:1;height:1px;background:rgba(255,255,255,.06)"></div>
  </div>

  <!-- Download PDF Button -->
  <button onclick="downloadAchievementsPDF()" style="width:100%;display:flex;align-items:center;justify-content:center;gap:.6rem;padding:.9rem;background:linear-gradient(135deg,rgba(248,113,113,.08),rgba(251,191,36,.06));border:1px solid rgba(248,113,113,.15);border-radius:14px;cursor:pointer;transition:all .2s;color:#fff" onmouseover="this.style.background='linear-gradient(135deg,rgba(248,113,113,.15),rgba(251,191,36,.1))';this.style.transform='translateY(-1px)'" onmouseout="this.style.background='linear-gradient(135deg,rgba(248,113,113,.08),rgba(251,191,36,.06))';this.style.transform='none'">
    <i class="bi bi-file-earmark-pdf-fill" style="font-size:1.3rem;color:#f87171"></i>
    <div style="text-align:left">
      <div style="font-size:.82rem;font-weight:700">Download as PDF</div>
      <div style="font-size:.62rem;color:var(--gray)">Full achievements report with badges & stats</div>
    </div>
  </button>

  <!-- Tip -->
  <div style="display:flex;align-items:center;gap:.5rem;margin-top:1rem;padding:.5rem .8rem;background:rgba(200,240,61,.03);border-radius:8px;border:1px solid rgba(200,240,61,.06)">
    <i class="bi bi-info-circle" style="color:var(--accent);font-size:.8rem;flex-shrink:0"></i>
    <span style="font-size:.68rem;color:rgba(255,255,255,.45)">PDF includes your level, badges, streak history, and leaderboard rank.</span>
  </div>
</div>
</div>
</div>
</div>

<!-- PROGRESS -->
<div class="mp-sec" id="sec-progress">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:1.5rem">TRACK <span style="color:var(--accent)">PROGRESS</span><span class="sample-badge"><i class="bi bi-info-circle"></i> Sample Data</span></h2>
<div class="mp-grid2">
<div class="mp-card"><h4><i class="bi bi-graph-up"></i> Weight Progress (kg)</h4><canvas id="weightChart" height="200"></canvas></div>
<div class="mp-card"><h4><i class="bi bi-activity"></i> Weekly Activity</h4><canvas id="activityChart" height="200"></canvas></div>
</div></div>

<!-- GOALS -->
<div class="mp-sec" id="sec-goals">
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:1.5rem">
  <h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin:0">MY <span style="color:var(--accent)">GOALS</span></h2>
  <div style="display:flex;gap:.5rem">
    <button class="btn-g" onclick="openModal('addGoalModal')"><i class="bi bi-plus-lg"></i> New Goal</button>
    <button class="btn-g" onclick="resetGoals()"><i class="bi bi-arrow-counterclockwise"></i> Reset</button>
  </div>
</div>

<!-- Overall Progress Hero -->
<div class="neon-card" style="display:flex;align-items:center;gap:2rem;padding:2rem;margin-bottom:1.5rem;flex-wrap:wrap">
  <div style="position:relative;width:100px;height:100px;flex-shrink:0">
    <svg viewBox="0 0 120 120" width="100" height="100" style="transform:rotate(-90deg)">
      <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="10"/>
      <circle cx="60" cy="60" r="52" fill="none" stroke="var(--accent)" stroke-width="10" stroke-linecap="round" stroke-dasharray="327" id="goalRing" style="stroke-dashoffset:111;transition:stroke-dashoffset 1s"/>
    </svg>
    <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
      <div style="font-family:var(--font-display);font-size:2.2rem;color:var(--accent);line-height:1" id="goalPctVal">66</div>
      <div style="font-size:.55rem;color:var(--gray);letter-spacing:1px">% DONE</div>
    </div>
  </div>
  <div style="flex:1;min-width:200px">
    <div style="font-size:.65rem;color:var(--accent);font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:.3rem">Overall Goal Progress</div>
    <div style="font-size:1rem;font-weight:700;margin-bottom:.5rem">You're on track! Keep pushing.</div>
    <div style="font-size:.78rem;color:var(--gray);line-height:1.5">4 of 6 goals are actively progressing. You've hit 2 milestones this month. Weight loss goal is 80% complete!</div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.5rem;min-width:250px">
    <div style="text-align:center;padding:.5rem;background:rgba(200,240,61,.05);border-radius:10px;border:1px solid rgba(200,240,61,.15)"><div style="font-family:var(--font-display);font-size:1.4rem;color:var(--accent)">6</div><div style="font-size:.55rem;color:var(--gray)">ACTIVE</div></div>
    <div style="text-align:center;padding:.5rem;background:rgba(52,211,153,.05);border-radius:10px;border:1px solid rgba(52,211,153,.15)"><div style="font-family:var(--font-display);font-size:1.4rem;color:#34d399">2</div><div style="font-size:.55rem;color:var(--gray)">COMPLETED</div></div>
    <div style="text-align:center;padding:.5rem;background:rgba(251,191,36,.05);border-radius:10px;border:1px solid rgba(251,191,36,.15)"><div style="font-family:var(--font-display);font-size:1.4rem;color:#fbbf24">4</div><div style="font-size:.55rem;color:var(--gray)">MILESTONES</div></div>
  </div>
</div>

<!-- Goal Cards Grid -->
<div class="mp-grid3" style="margin-bottom:1.5rem">
  <!-- Weight Goal -->
  <div class="mp-card" style="position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:var(--accent);opacity:.3"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><h4 style="margin:0"><i class="bi bi-bullseye"></i> Target Weight</h4><span style="font-size:.6rem;padding:.15rem .5rem;border-radius:50px;background:rgba(200,240,61,.1);color:var(--accent);font-weight:700" id="goalPctWeight">80%</span></div>
    <div style="display:flex;align-items:baseline;gap:.3rem;margin-bottom:.5rem"><span style="font-family:var(--font-display);font-size:2.5rem;color:var(--accent)">75</span><span style="font-size:.9rem;color:var(--gray)">kg target</span></div>
    <div class="pbar" style="height:8px;margin-bottom:.5rem"><div class="pbar-fill green" style="width:80%" id="goalBarWeight"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--gray)"><span>Current: <strong style="color:#fff" data-bind="weight">78</strong> kg</span><span>3 kg to go</span></div>
    <div style="display:flex;gap:.5rem;margin-top:.8rem">
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="updateGoalProgress('weight')"><i class="bi bi-pencil"></i> Update</button>
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="showGoalDetails('weight')"><i class="bi bi-eye"></i> Details</button>
    </div>
  </div>

  <!-- Workouts Goal -->
  <div class="mp-card" style="position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:#60a5fa;opacity:.3"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><h4 style="margin:0"><i class="bi bi-lightning-fill"></i> Weekly Workouts</h4><span style="font-size:.6rem;padding:.15rem .5rem;border-radius:50px;background:rgba(96,165,250,.1);color:#60a5fa;font-weight:700" id="goalPctWorkout">50%</span></div>
    <div style="display:flex;align-items:baseline;gap:.3rem;margin-bottom:.5rem"><span style="font-family:var(--font-display);font-size:2.5rem;color:#60a5fa">4</span><span style="font-size:.9rem;color:var(--gray)">days / week</span></div>
    <div class="pbar" style="height:8px;margin-bottom:.5rem"><div class="pbar-fill blue" style="width:50%" id="goalBarWorkout"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--gray)"><span>Done: <strong style="color:#fff" data-bind="workoutsThisWeek">2 days</strong></span><span>2 remaining</span></div>
    <div style="display:flex;gap:.5rem;margin-top:.8rem">
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="updateGoalProgress('workout')"><i class="bi bi-pencil"></i> Update</button>
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="showGoalDetails('workout')"><i class="bi bi-eye"></i> Details</button>
    </div>
  </div>

  <!-- Hydration Goal -->
  <div class="mp-card" style="position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:#34d399;opacity:.3"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><h4 style="margin:0"><i class="bi bi-droplet-fill"></i> Daily Hydration</h4><span style="font-size:.6rem;padding:.15rem .5rem;border-radius:50px;background:rgba(52,211,153,.1);color:#34d399;font-weight:700" id="goalPctHydration">60%</span></div>
    <div style="display:flex;align-items:baseline;gap:.3rem;margin-bottom:.5rem"><span style="font-family:var(--font-display);font-size:2.5rem;color:#34d399">3.0</span><span style="font-size:.9rem;color:var(--gray)">L daily</span></div>
    <div class="pbar" style="height:8px;margin-bottom:.5rem"><div class="pbar-fill" style="width:60%;background:#34d399" id="goalBarHydration"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--gray)"><span>Current: <strong style="color:#fff" data-bind="waterIntakeL">1.8</strong> L</span><span>1.2 L to go</span></div>
    <div style="display:flex;gap:.5rem;margin-top:.8rem">
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="updateGoalProgress('hydration')"><i class="bi bi-pencil"></i> Update</button>
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="showGoalDetails('hydration')"><i class="bi bi-eye"></i> Details</button>
    </div>
  </div>

  <!-- Sleep Goal -->
  <div class="mp-card" style="position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:#a78bfa;opacity:.3"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><h4 style="margin:0"><i class="bi bi-moon-fill"></i> Sleep Quality</h4><span style="font-size:.6rem;padding:.15rem .5rem;border-radius:50px;background:rgba(167,139,250,.1);color:#a78bfa;font-weight:700" id="goalPctSleep">85%</span></div>
    <div style="display:flex;align-items:baseline;gap:.3rem;margin-bottom:.5rem"><span style="font-family:var(--font-display);font-size:2.5rem;color:#a78bfa">8</span><span style="font-size:.9rem;color:var(--gray)">hrs / night</span></div>
    <div class="pbar" style="height:8px;margin-bottom:.5rem"><div class="pbar-fill" style="width:85%;background:#a78bfa" id="goalBarSleep"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--gray)"><span>Average: <strong style="color:#fff" data-bind="sleepHrs">7.2 hrs</strong></span><span>Nearly there!</span></div>
    <div style="display:flex;gap:.5rem;margin-top:.8rem">
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="updateGoalProgress('sleep')"><i class="bi bi-pencil"></i> Update</button>
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="showGoalDetails('sleep')"><i class="bi bi-eye"></i> Details</button>
    </div>
  </div>

  <!-- Steps Goal -->
  <div class="mp-card" style="position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:#f87171;opacity:.3"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><h4 style="margin:0"><i class="bi bi-footsteps"></i> Daily Steps</h4><span style="font-size:.6rem;padding:.15rem .5rem;border-radius:50px;background:rgba(248,113,113,.1);color:#f87171;font-weight:700" id="goalPctSteps">56%</span></div>
    <div style="display:flex;align-items:baseline;gap:.3rem;margin-bottom:.5rem"><span style="font-family:var(--font-display);font-size:2.5rem;color:#f87171">10K</span><span style="font-size:.9rem;color:var(--gray)">steps</span></div>
    <div class="pbar" style="height:8px;margin-bottom:.5rem"><div class="pbar-fill red" style="width:56%" id="goalBarSteps"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--gray)"><span>Today: <strong style="color:#fff" data-bind="stepsToday">5,600</strong></span><span>4,400 to go</span></div>
    <div style="display:flex;gap:.5rem;margin-top:.8rem">
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="updateGoalProgress('steps')"><i class="bi bi-pencil"></i> Update</button>
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="showGoalDetails('steps')"><i class="bi bi-eye"></i> Details</button>
    </div>
  </div>

  <!-- Body Fat Goal -->
  <div class="mp-card" style="position:relative;overflow:hidden">
    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:#fbbf24;opacity:.3"></div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.8rem"><h4 style="margin:0"><i class="bi bi-percent"></i> Body Fat</h4><span style="font-size:.6rem;padding:.15rem .5rem;border-radius:50px;background:rgba(251,191,36,.1);color:#fbbf24;font-weight:700" id="goalPctBf">40%</span></div>
    <div style="display:flex;align-items:baseline;gap:.3rem;margin-bottom:.5rem"><span style="font-family:var(--font-display);font-size:2.5rem;color:#fbbf24">15</span><span style="font-size:.9rem;color:var(--gray)">% target</span></div>
    <div class="pbar" style="height:8px;margin-bottom:.5rem"><div class="pbar-fill yellow" style="width:40%" id="goalBarBf"></div></div>
    <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--gray)"><span>Current: <strong style="color:#fff" data-bind="bodyFat">18</strong>%</span><span>3% to lose</span></div>
    <div style="display:flex;gap:.5rem;margin-top:.8rem">
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="updateGoalProgress('bf')"><i class="bi bi-pencil"></i> Update</button>
      <button class="btn-g" style="flex:1;font-size:.65rem;padding:.35rem;justify-content:center" onclick="showGoalDetails('bf')"><i class="bi bi-eye"></i> Details</button>
    </div>
  </div>
</div>

<!-- Milestones -->
<div class="sec-subheading"><i class="bi bi-flag-fill"></i> Recent Milestones</div>
<div class="mp-grid2" style="margin-bottom:1.5rem">
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:42px;height:42px;border-radius:12px;background:rgba(200,240,61,.1);display:flex;align-items:center;justify-content:center;color:var(--accent)"><i class="bi bi-check-circle-fill"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">Lost 4kg since starting!</div><div style="font-size:.68rem;color:var(--gray)">Weight goal milestone &middot; 2 days ago</div></div><span class="pay-status paid" style="font-size:.6rem">ACHIEVED</span></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:1rem;padding:1rem"><div style="width:42px;height:42px;border-radius:12px;background:rgba(167,139,250,.1);display:flex;align-items:center;justify-content:center;color:#a78bfa"><i class="bi bi-check-circle-fill"></i></div><div style="flex:1"><div style="font-weight:700;font-size:.88rem">7-day sleep streak (7+ hrs)</div><div style="font-size:.68rem;color:var(--gray)">Sleep goal milestone &middot; 5 days ago</div></div><span class="pay-status paid" style="font-size:.6rem">ACHIEVED</span></div>
</div>

<!-- Add Goal Modal -->
<div class="modal-overlay" id="addGoalModal">
<div class="modal-box">
<button class="modal-close" onclick="closeModal('addGoalModal')">&times;</button>
<h3 class="m-title">NEW <span style="color:var(--accent)">GOAL</span></h3>
<div class="edit-form-field"><label>Goal Name</label><input type="text" id="newGoalName" placeholder="e.g. Run 5K"></div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
  <div class="edit-form-field"><label>Target Value</label><input type="text" id="newGoalTarget" placeholder="e.g. 5 km"></div>
  <div class="edit-form-field"><label>Deadline</label><input type="date" id="newGoalDeadline"></div>
</div>
<div class="edit-form-field"><label>Category</label><select id="newGoalCat"><option>Fitness</option><option>Nutrition</option><option>Health</option><option>Weight</option><option>Custom</option></select></div>
<button class="btn-solid" style="width:100%;padding:.75rem;margin-top:1rem" onclick="saveNewGoal()"><i class="bi bi-check-lg"></i> Create Goal</button>
</div></div>

<!-- Update Goal Modal -->
<div class="modal-overlay" id="updateGoalModal">
<div class="modal-box">
<button class="modal-close" onclick="closeModal('updateGoalModal')">&times;</button>
<h3 class="m-title">UPDATE <span style="color:var(--accent)" id="ugTitle">GOAL</span></h3>
<div style="text-align:center;margin:1.5rem 0">
  <div style="font-family:var(--font-display);font-size:3rem;color:var(--accent)" id="ugValueDisplay">78</div>
  <div style="font-size:.75rem;color:var(--gray)" id="ugUnit">kg</div>
</div>
<div class="edit-form-field"><label>Current Progress</label><input type="range" id="ugSlider" min="0" max="100" value="78" style="width:100%;accent-color:var(--accent)" oninput="document.getElementById('ugValueDisplay').textContent=this.value"></div>
<div style="display:flex;justify-content:space-between;font-size:.7rem;color:var(--gray);margin-bottom:1rem"><span id="ugMin">0</span><span id="ugMax">100</span></div>
<div class="edit-form-field"><label>Notes (optional)</label><input type="text" id="ugNotes" placeholder="e.g. Feeling great today!"></div>
<button class="btn-solid" style="width:100%;padding:.75rem;margin-top:.5rem" onclick="saveGoalUpdate()"><i class="bi bi-check-lg"></i> Save Progress</button>
</div></div>

<!-- Goal Details Modal -->
<div class="modal-overlay" id="goalDetailModal">
<div class="modal-box wide">
<button class="modal-close" onclick="closeModal('goalDetailModal')">&times;</button>
<h3 class="m-title"><span style="color:var(--accent)" id="gdTitle">GOAL</span> DETAILS</h3>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.5rem">
  <div class="neon-card" style="padding:1rem;text-align:center"><div style="font-size:.6rem;color:var(--gray);letter-spacing:1px;margin-bottom:.3rem">CURRENT</div><div style="font-family:var(--font-display);font-size:1.8rem" id="gdCurrent">78 kg</div></div>
  <div class="neon-card" style="padding:1rem;text-align:center"><div style="font-size:.6rem;color:var(--gray);letter-spacing:1px;margin-bottom:.3rem">TARGET</div><div style="font-family:var(--font-display);font-size:1.8rem;color:var(--accent)" id="gdTarget">75 kg</div></div>
</div>
<div class="neon-card" style="padding:1rem;margin-bottom:1rem">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem"><span style="font-weight:700;font-size:.85rem">Progress</span><span style="color:var(--accent);font-weight:700;font-size:.85rem" id="gdPct">80%</span></div>
  <div class="pbar" style="height:10px"><div class="pbar-fill green" style="width:80%" id="gdBar"></div></div>
</div>
<div style="font-weight:700;font-size:.85rem;margin-bottom:.6rem"><i class="bi bi-clock-history"></i> Recent Updates</div>
<div style="display:flex;flex-direction:column;gap:.5rem;margin-bottom:1.2rem" id="gdHistory">
  <div class="neon-card" style="display:flex;align-items:center;gap:.8rem;padding:.7rem"><div style="width:8px;height:8px;border-radius:50%;background:var(--accent);flex-shrink:0"></div><div style="flex:1;font-size:.78rem">Updated to <strong id="gdH1Val">78 kg</strong></div><div style="font-size:.65rem;color:var(--gray)">Today</div></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:.8rem;padding:.7rem"><div style="width:8px;height:8px;border-radius:50%;background:rgba(200,240,61,.4);flex-shrink:0"></div><div style="flex:1;font-size:.78rem">Updated to <strong id="gdH2Val">79 kg</strong></div><div style="font-size:.65rem;color:var(--gray)">3 days ago</div></div>
  <div class="neon-card" style="display:flex;align-items:center;gap:.8rem;padding:.7rem"><div style="width:8px;height:8px;border-radius:50%;background:rgba(200,240,61,.2);flex-shrink:0"></div><div style="flex:1;font-size:.78rem">Started at <strong id="gdH3Val">82 kg</strong></div><div style="font-size:.65rem;color:var(--gray)">4 weeks ago</div></div>
</div>
<div style="font-weight:700;font-size:.85rem;margin-bottom:.6rem"><i class="bi bi-lightbulb"></i> Tips</div>
<div class="neon-card" style="padding:.8rem;font-size:.78rem;color:var(--gray);line-height:1.6" id="gdTips">Stay consistent with your nutrition plan. Small calorie deficits lead to sustainable weight loss. Aim for 0.5-1 kg per week.</div>
<button class="btn-solid" style="width:100%;padding:.75rem;margin-top:1rem" onclick="closeModal('goalDetailModal')">Close</button>
</div></div>

<script>
var goalData={
  weight:{name:'TARGET WEIGHT',current:78,target:75,unit:'kg',pct:80,color:'var(--accent)',min:60,max:100,h1:'78 kg',h2:'79 kg',h3:'82 kg',tips:'Stay consistent with your nutrition plan. Small calorie deficits lead to sustainable weight loss. Aim for 0.5-1 kg per week.'},
  workout:{name:'WEEKLY WORKOUTS',current:2,target:4,unit:'days',pct:50,color:'#60a5fa',min:0,max:7,h1:'2 days',h2:'3 days',h3:'1 day',tips:'Try scheduling workouts at the same time each day. Consistency beats intensity. Mix cardio and strength for best results.'},
  hydration:{name:'DAILY HYDRATION',current:1.8,target:3.0,unit:'L',pct:60,color:'#34d399',min:0,max:5,h1:'1.8 L',h2:'2.0 L',h3:'1.2 L',tips:'Keep a water bottle at your desk. Set hourly reminders. Add lemon or fruit for flavor variety.'},
  sleep:{name:'SLEEP QUALITY',current:7.2,target:8,unit:'hrs',pct:85,color:'#a78bfa',min:0,max:12,h1:'7.2 hrs',h2:'6.8 hrs',h3:'6.0 hrs',tips:'Maintain a consistent sleep schedule. Avoid screens 1 hour before bed. Keep your room cool and dark.'},
  steps:{name:'DAILY STEPS',current:5600,target:10000,unit:'steps',pct:56,color:'#f87171',min:0,max:15000,h1:'5,600',h2:'7,200',h3:'3,400',tips:'Take walking breaks every hour. Use stairs instead of elevator. A 30-min walk adds ~3,000 steps.'},
  bf:{name:'BODY FAT',current:18,target:15,unit:'%',pct:40,color:'#fbbf24',min:5,max:35,h1:'18%',h2:'19%',h3:'22%',tips:'Focus on strength training to preserve muscle. High protein diet helps reduce body fat. Track measurements weekly.'}
};
var currentGoalType='';
function updateGoalProgress(type){
  currentGoalType=type;var g=goalData[type];
  document.getElementById('ugTitle').textContent=g.name;
  document.getElementById('ugValueDisplay').textContent=g.current;
  document.getElementById('ugUnit').textContent=g.unit;
  document.getElementById('ugSlider').min=g.min;
  document.getElementById('ugSlider').max=g.max;
  document.getElementById('ugSlider').value=g.current;
  if(g.unit==='L'){document.getElementById('ugSlider').step='0.1';}else if(g.unit==='hrs'){document.getElementById('ugSlider').step='0.1';}else{document.getElementById('ugSlider').step='1';}
  document.getElementById('ugMin').textContent=g.min+' '+g.unit;
  document.getElementById('ugMax').textContent=g.max+' '+g.unit;
  document.getElementById('ugNotes').value='';
  openModal('updateGoalModal');
}
function saveGoalUpdate(){
  var val=parseFloat(document.getElementById('ugSlider').value);
  var g=goalData[currentGoalType];
  g.current=val;
  closeModal('updateGoalModal');
  showToast(g.name+' updated to '+val+' '+g.unit+' \u2705');
  // Sync to ApexState
  if(typeof ApexState!=='undefined'){
    var keyMap={weight:'weight',workout:'workoutsThisWeek',hydration:'waterIntakeL',sleep:'sleepHrs',steps:'stepsToday',bf:'bodyFat'};
    var k=keyMap[currentGoalType];
    if(k) ApexState.set(k, val);
  }
}
function showGoalDetails(type){
  var g=goalData[type];
  document.getElementById('gdTitle').textContent=g.name;
  document.getElementById('gdCurrent').textContent=g.current+' '+g.unit;
  document.getElementById('gdCurrent').style.color=g.color;
  document.getElementById('gdTarget').textContent=g.target+' '+g.unit;
  document.getElementById('gdPct').textContent=g.pct+'%';
  document.getElementById('gdBar').style.width=g.pct+'%';
  document.getElementById('gdH1Val').textContent=g.h1;
  document.getElementById('gdH2Val').textContent=g.h2;
  document.getElementById('gdH3Val').textContent=g.h3;
  document.getElementById('gdTips').textContent=g.tips;
  openModal('goalDetailModal');
}
function saveNewGoal(){var n=document.getElementById('newGoalName').value.trim();if(!n){showToast('Please enter a goal name');return;}closeModal('addGoalModal');showToast('Goal "'+n+'" created! \uD83C\uDFAF');document.getElementById('newGoalName').value='';}
function resetGoals(){showToast('Goals reset to defaults');}
window.updateGoalProgress=updateGoalProgress;window.saveGoalUpdate=saveGoalUpdate;window.showGoalDetails=showGoalDetails;window.saveNewGoal=saveNewGoal;window.resetGoals=resetGoals;
</script>
</div>

<!-- HEALTH -->
<div class="mp-sec" id="sec-health">
<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;margin-bottom:1.5rem">
  <h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin:0">HEALTH <span style="color:var(--accent)">DASHBOARD</span></h2>
  <div style="display:flex;gap:.5rem">
    <button class="btn-g" onclick="openModal('logMetricsModal')"><i class="bi bi-pencil-square"></i> Log Metrics</button>
    <button class="btn-g" onclick="exportHealthData()"><i class="bi bi-download"></i> Export</button>
  </div>
</div>

<!-- Health Score Hero -->
<div class="neon-card" style="display:flex;align-items:center;gap:2rem;padding:2rem;margin-bottom:1.5rem;flex-wrap:wrap">
  <div style="position:relative;width:110px;height:110px;flex-shrink:0">
    <svg viewBox="0 0 120 120" width="110" height="110" style="transform:rotate(-90deg)">
      <circle cx="60" cy="60" r="52" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="10"/>
      <circle cx="60" cy="60" r="52" fill="none" stroke="var(--accent)" stroke-width="10" stroke-linecap="round" stroke-dasharray="327" stroke-dashoffset="46" id="healthScoreRing"/>
    </svg>
    <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
      <div style="font-family:var(--font-display);font-size:2.2rem;color:var(--accent);line-height:1" id="healthScoreVal">86</div>
      <div style="font-size:.55rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">SCORE</div>
    </div>
  </div>
  <div style="flex:1;min-width:200px">
    <div style="font-size:.65rem;color:var(--accent);font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:.3rem">Overall Health Score</div>
    <div style="font-size:1rem;font-weight:700;margin-bottom:.5rem">Excellent Condition</div>
    <div style="font-size:.78rem;color:var(--gray);line-height:1.6">Your health metrics are above average. Sleep quality and hydration are strong. Focus on increasing daily step count to reach optimal levels.</div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:.6rem;min-width:220px">
    <div style="text-align:center;padding:.6rem;background:rgba(200,240,61,.05);border-radius:10px;border:1px solid rgba(200,240,61,.1)"><div style="font-family:var(--font-display);font-size:1.2rem;color:var(--accent)">92%</div><div style="font-size:.6rem;color:var(--gray)">HYDRATION</div></div>
    <div style="text-align:center;padding:.6rem;background:rgba(167,139,250,.05);border-radius:10px;border:1px solid rgba(167,139,250,.1)"><div style="font-family:var(--font-display);font-size:1.2rem;color:#a78bfa">85%</div><div style="font-size:.6rem;color:var(--gray)">SLEEP</div></div>
    <div style="text-align:center;padding:.6rem;background:rgba(248,113,113,.05);border-radius:10px;border:1px solid rgba(248,113,113,.1)"><div style="font-family:var(--font-display);font-size:1.2rem;color:#f87171">72</div><div style="font-size:.6rem;color:var(--gray)">RESTING HR</div></div>
    <div style="text-align:center;padding:.6rem;background:rgba(52,211,153,.05);border-radius:10px;border:1px solid rgba(52,211,153,.1)"><div style="font-family:var(--font-display);font-size:1.2rem;color:#34d399">88%</div><div style="font-size:.6rem;color:var(--gray)">RECOVERY</div></div>
  </div>
</div>

<!-- Water + Sleep + Heart Rate Row -->
<div class="mp-grid3" style="margin-bottom:1.5rem">
  <!-- Water Tracker -->
  <div class="mp-card">
    <h4><i class="bi bi-droplet-fill"></i> Water Intake</h4>
    <div class="water-grid">
      <div class="water-glass filled" onclick="toggleGlass(this)"></div>
      <div class="water-glass filled" onclick="toggleGlass(this)"></div>
      <div class="water-glass filled" onclick="toggleGlass(this)"></div>
      <div class="water-glass filled" onclick="toggleGlass(this)"></div>
      <div class="water-glass filled" onclick="toggleGlass(this)"></div>
      <div class="water-glass" onclick="toggleGlass(this)"></div>
      <div class="water-glass" onclick="toggleGlass(this)"></div>
      <div class="water-glass" onclick="toggleGlass(this)"></div>
      <div class="water-actions">
        <div class="water-add-btn" onclick="addGlass()" title="Add glass"><i class="bi bi-plus"></i></div>
        <div class="water-remove-btn" onclick="removeGlass()" title="Remove glass"><i class="bi bi-dash"></i></div>
      </div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:.5rem">
      <div style="font-size:.8rem;color:var(--gray)"><span id="waterCount" style="color:#fff;font-weight:700">1.25</span>L / 2.00L</div>
      <div style="font-size:.65rem;color:var(--accent);font-weight:700" id="waterPctDisplay">63%</div>
    </div>
    <div class="pbar" style="margin-top:.4rem"><div class="pbar-fill green" style="width:63%" id="waterBar"></div></div>
  </div>

  <!-- Sleep Tracker -->
  <div class="mp-card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem"><h4 style="margin:0"><i class="bi bi-moon-fill"></i> Sleep Tracker</h4><button class="btn-g" style="font-size:.65rem;padding:.25rem .6rem" onclick="openModal('sleepModal')"><i class="bi bi-pencil"></i> Log</button></div>
    <div style="font-family:var(--font-display);font-size:2.5rem;color:#a78bfa;line-height:1;margin-bottom:.5rem" id="sleepDisplay" data-bind="sleepHrs">7h 15m</div>
    <div class="sleep-bar"><div class="sleep-label">Quality</div><div class="sleep-quality"><div class="sleep-quality-fill" style="width:85%" id="sleepQualBar"></div></div><span style="font-size:.7rem;color:#a78bfa;font-weight:700" id="sleepQualPct">85%</span></div>
    
    <!-- Sleep Stage Visualization -->
    <div style="margin:.6rem 0;height:8px;border-radius:4px;display:flex;overflow:hidden;gap:1px">
      <div style="flex:2.0;background:#60a5fa;border-radius:4px 0 0 4px" title="Deep Sleep"></div>
      <div style="flex:1.5;background:#a78bfa" title="REM"></div>
      <div style="flex:3.5;background:rgba(52,211,153,.5);border-radius:0 4px 4px 0" title="Light"></div>
    </div>
    <div style="display:flex;gap:.6rem;margin-bottom:.6rem">
      <div style="display:flex;align-items:center;gap:.25rem;font-size:.58rem;color:var(--gray)"><span style="width:6px;height:6px;border-radius:50%;background:#60a5fa;display:inline-block"></span> Deep</div>
      <div style="display:flex;align-items:center;gap:.25rem;font-size:.58rem;color:var(--gray)"><span style="width:6px;height:6px;border-radius:50%;background:#a78bfa;display:inline-block"></span> REM</div>
      <div style="display:flex;align-items:center;gap:.25rem;font-size:.58rem;color:var(--gray)"><span style="width:6px;height:6px;border-radius:50%;background:rgba(52,211,153,.5);display:inline-block"></span> Light</div>
    </div>

    <div style="display:flex;gap:.6rem;margin-top:.5rem">
      <div id="sleepBedCard" style="flex:1;text-align:center;padding:.4rem;background:rgba(167,139,250,.06);border:1px solid rgba(167,139,250,.08);border-radius:8px"><div style="font-size:.85rem;font-weight:700;color:#a78bfa" id="sleepBedVal">11:30</div><div style="font-size:.58rem;color:var(--gray)">BEDTIME</div></div>
      <div id="sleepWakeCard" style="flex:1;text-align:center;padding:.4rem;background:rgba(96,165,250,.06);border:1px solid rgba(96,165,250,.08);border-radius:8px"><div style="font-size:.85rem;font-weight:700;color:#60a5fa" id="sleepWakeVal">6:45</div><div style="font-size:.58rem;color:var(--gray)">WAKE UP</div></div>
      <div id="sleepDeepCard" style="flex:1;text-align:center;padding:.4rem;background:rgba(52,211,153,.06);border:1px solid rgba(52,211,153,.08);border-radius:8px"><div style="font-size:.85rem;font-weight:700;color:#34d399" id="sleepDeepVal">2</div><div style="font-size:.58rem;color:var(--gray)">DEEP HRS</div></div>
    </div>
    <!-- Mood Display -->
    <div style="display:flex;align-items:center;gap:.5rem;margin-top:.6rem;padding:.35rem .6rem;background:rgba(167,139,250,.04);border-radius:8px;border:1px solid rgba(167,139,250,.06)">
      <span style="font-size:.9rem" id="sleepMoodEmoji">😊</span>
      <span style="font-size:.65rem;color:var(--gray)">Mood:</span>
      <span style="font-size:.68rem;font-weight:600;color:#a78bfa" id="sleepMoodText">Good</span>
    </div>
  </div>

  <!-- Heart Rate -->
  <div class="mp-card">
    <h4><i class="bi bi-heart-pulse-fill"></i> Heart Rate</h4>
    <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.8rem">
      <div style="font-family:var(--font-display);font-size:3rem;color:#f87171;line-height:1" id="hrValue">72</div>
      <div><div style="font-size:.7rem;color:var(--gray)">BPM</div><div style="font-size:.6rem;color:#34d399;font-weight:700"><i class="bi bi-circle-fill" style="font-size:.35rem"></i> Normal</div></div>
    </div>
    <svg width="100%" height="50" viewBox="0 0 300 50" style="display:block"><path d="M0,25 L30,25 L40,10 L50,40 L60,5 L70,45 L80,25 L110,25 L120,15 L130,35 L140,8 L150,42 L160,25 L190,25 L200,12 L210,38 L220,6 L230,44 L240,25 L300,25" class="ecg-path" style="stroke-dasharray:600;stroke-dashoffset:600;animation:ecgDraw 3s linear infinite"/></svg>
    <div style="display:flex;justify-content:space-between;margin-top:.8rem;font-size:.68rem;color:var(--gray)">
      <div>Resting: <span style="color:#fff;font-weight:600">58</span></div>
      <div>Average: <span style="color:#fff;font-weight:600">72</span></div>
      <div>Max: <span style="color:#fff;font-weight:600">165</span></div>
    </div>
  </div>
</div>

<!-- Body Composition + Weight Chart Row -->
<div class="mp-grid2" style="margin-bottom:1.5rem">
  <!-- Body Composition -->
  <div class="mp-card">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem"><h4 style="margin:0"><i class="bi bi-person-lines-fill"></i> Body Composition</h4><button class="btn-g" style="font-size:.65rem;padding:.25rem .6rem" onclick="openModal('logMetricsModal')"><i class="bi bi-pencil"></i> Update</button></div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.8rem;margin-bottom:1rem">
      <div style="text-align:center;padding:.8rem;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px"><div style="font-family:var(--font-display);font-size:1.8rem;color:#fff" id="dispWeight">78</div><div style="font-size:.6rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">Weight (kg)</div></div>
      <div style="text-align:center;padding:.8rem;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px"><div style="font-family:var(--font-display);font-size:1.8rem;color:#f87171" id="dispBF">18</div><div style="font-size:.6rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">Body Fat %</div></div>
      <div style="text-align:center;padding:.8rem;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px"><div style="font-family:var(--font-display);font-size:1.8rem;color:var(--accent)" id="dispMuscle">35</div><div style="font-size:.6rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px">Muscle (kg)</div></div>
    </div>
    <!-- BMI Calculator -->
    <div style="background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px;padding:1rem">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.6rem"><span style="font-size:.72rem;font-weight:700;color:var(--accent);letter-spacing:1px">BMI CALCULATOR</span><span style="font-size:.65rem;color:var(--gray)" id="bmiCategory">Normal Weight</span></div>
      <div style="display:flex;gap:.6rem;align-items:center">
        <input type="number" id="bmiHeight" placeholder="Height (cm)" value="175" style="flex:1;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px;padding:.5rem;color:#fff;font-size:.8rem;outline:none;font-family:var(--font-body)" oninput="calcBMI()">
        <input type="number" id="bmiWeight" placeholder="Weight (kg)" value="78" style="flex:1;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px;padding:.5rem;color:#fff;font-size:.8rem;outline:none;font-family:var(--font-body)" oninput="calcBMI()">
        <div style="font-family:var(--font-display);font-size:1.5rem;color:var(--accent);min-width:50px;text-align:center" id="bmiResult">25.5</div>
      </div>
      <div class="pbar" style="margin-top:.6rem;height:8px;background:linear-gradient(90deg,#34d399 0%,#34d399 25%,var(--accent) 25%,var(--accent) 50%,#fbbf24 50%,#fbbf24 75%,#f87171 75%)"><div style="width:2px;height:16px;background:#fff;border-radius:2px;margin-top:-4px;margin-left:51%;transition:margin-left .3s" id="bmiMarker"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:.55rem;color:var(--gray);margin-top:.3rem"><span>Under</span><span>Normal</span><span>Over</span><span>Obese</span></div>
    </div>
  </div>

  <!-- Weight Trend Chart -->
  <div class="mp-card">
    <h4><i class="bi bi-graph-up-arrow"></i> Weight Trend</h4>
    <canvas id="weightTrendChart" height="220"></canvas>
  </div>
</div>

<!-- Daily Steps + Calories + Stress Row -->
<div class="sec-subheading"><i class="bi bi-activity"></i> Daily Vitals</div>
<div class="mp-grid4" style="margin-bottom:1.5rem">
  <div class="ms"><div class="ms-icon green"><i class="bi bi-footsteps"></i></div><div class="ms-val" id="stepsVal">8,420</div><div class="ms-lbl">Steps Today</div></div>
  <div class="ms"><div class="ms-icon red"><i class="bi bi-fire"></i></div><div class="ms-val">1,850</div><div class="ms-lbl">Calories In</div></div>
  <div class="ms"><div class="ms-icon blue"><i class="bi bi-lightning-charge-fill"></i></div><div class="ms-val">520</div><div class="ms-lbl">Calories Out</div></div>
  <div class="ms"><div class="ms-icon yellow"><i class="bi bi-emoji-smile"></i></div><div class="ms-val">Low</div><div class="ms-lbl">Stress Level</div></div>
</div>

<!-- Weekly Sleep Chart -->
<div class="mp-card" style="margin-bottom:1.5rem">
  <h4><i class="bi bi-moon-stars-fill"></i> Sleep History</h4>
  <canvas id="sleepHistChart" height="140"></canvas>
</div>

<!-- Log Metrics Modal -->
<div class="modal-overlay" id="logMetricsModal">
<div class="modal-box">
<button class="modal-close" onclick="closeModal('logMetricsModal')">&times;</button>
<h3 class="m-title">LOG <span style="color:var(--accent)">METRICS</span></h3>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
  <div class="edit-form-field"><label>Weight (kg)</label><input type="number" id="logWeight" placeholder="78" value="78"></div>
  <div class="edit-form-field"><label>Body Fat %</label><input type="number" id="logBF" placeholder="18" value="18"></div>
  <div class="edit-form-field"><label>Muscle Mass (kg)</label><input type="number" id="logMuscle" placeholder="35" value="35"></div>
  <div class="edit-form-field"><label>Waist (cm)</label><input type="number" id="logWaist" placeholder="82"></div>
  <div class="edit-form-field"><label>Chest (cm)</label><input type="number" id="logChest" placeholder="98"></div>
  <div class="edit-form-field"><label>Arms (cm)</label><input type="number" id="logArms" placeholder="36"></div>
</div>
<button class="btn-solid" style="width:100%;padding:.75rem;margin-top:1rem" onclick="saveHealthMetrics()"><i class="bi bi-check-lg"></i> Save Metrics</button>
</div></div>

<!-- Sleep Log Modal -->
<div class="modal-overlay" id="sleepModal">
<div class="modal-box" style="max-width:520px;padding:0;overflow-y:auto;max-height:90vh">
<button class="modal-close" onclick="closeModal('sleepModal')" style="z-index:2;top:1rem;right:1rem;color:rgba(255,255,255,.5)">&times;</button>

<!-- Modal Header -->
<div style="background:linear-gradient(135deg,rgba(167,139,250,.12),rgba(96,165,250,.06));padding:1.8rem 2rem 1.2rem;border-bottom:1px solid rgba(167,139,250,.12)">
  <div style="display:flex;align-items:center;gap:.8rem;margin-bottom:.8rem">
    <div style="width:44px;height:44px;border-radius:14px;background:rgba(167,139,250,.15);border:1px solid rgba(167,139,250,.25);display:flex;align-items:center;justify-content:center;font-size:1.2rem;color:#a78bfa"><i class="bi bi-moon-stars-fill"></i></div>
    <div>
      <div style="font-family:var(--font-display);font-size:1.5rem;letter-spacing:1px">LOG <span style="color:#a78bfa">SLEEP</span></div>
      <div style="font-size:.7rem;color:var(--gray)">Track your sleep for better recovery</div>
    </div>
  </div>
  <!-- Live Duration Preview -->
  <div style="display:flex;align-items:center;justify-content:center;gap:.6rem;padding:.6rem 1rem;background:rgba(0,0,0,.25);border-radius:12px;border:1px solid rgba(167,139,250,.1)">
    <i class="bi bi-clock-history" style="color:#a78bfa;font-size:.85rem"></i>
    <span style="font-size:.72rem;color:var(--gray)">Estimated Duration:</span>
    <span style="font-family:var(--font-display);font-size:1.1rem;color:#a78bfa;letter-spacing:1px" id="sleepDurationPreview">7h 15m</span>
  </div>
</div>

<!-- Modal Body -->
<div style="padding:1.5rem 2rem 2rem">
  <!-- Bedtime & Wake Time Row -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.2rem">
    <div>
      <label style="display:block;font-size:.68rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:.4rem"><i class="bi bi-moon-fill" style="margin-right:.3rem;color:#a78bfa"></i> Bedtime</label>
      <input type="time" id="logBedtime" value="23:30" style="width:100%;background:rgba(255,255,255,.04);border:1px solid rgba(167,139,250,.15);border-radius:10px;padding:.65rem .8rem;color:#fff;font-size:.9rem;font-family:var(--font-body);outline:none;transition:border-color .2s" onfocus="this.style.borderColor='#a78bfa'" onblur="this.style.borderColor='rgba(167,139,250,.15)'" onchange="updateSleepPreview()">
    </div>
    <div>
      <label style="display:block;font-size:.68rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:.4rem"><i class="bi bi-sunrise-fill" style="margin-right:.3rem;color:#fbbf24"></i> Wake Time</label>
      <input type="time" id="logWake" value="06:45" style="width:100%;background:rgba(255,255,255,.04);border:1px solid rgba(167,139,250,.15);border-radius:10px;padding:.65rem .8rem;color:#fff;font-size:.9rem;font-family:var(--font-body);outline:none;transition:border-color .2s" onfocus="this.style.borderColor='#a78bfa'" onblur="this.style.borderColor='rgba(167,139,250,.15)'" onchange="updateSleepPreview()">
    </div>
  </div>

  <!-- Sleep Quality Slider -->
  <div style="margin-bottom:1.2rem">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.4rem">
      <label style="font-size:.68rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px"><i class="bi bi-stars" style="margin-right:.3rem;color:#fbbf24"></i> Sleep Quality</label>
      <div style="display:flex;align-items:center;gap:.3rem">
        <span style="font-family:var(--font-display);font-size:1.1rem;color:#a78bfa" id="sleepQualNum">8</span>
        <span style="font-size:.65rem;color:var(--gray)">/10</span>
      </div>
    </div>
    <input type="range" id="logSleepQual" min="1" max="10" value="8" style="width:100%;accent-color:#a78bfa;height:6px" oninput="updateQualDisplay(this.value)">
    <div style="display:flex;justify-content:space-between;font-size:.6rem;color:var(--gray);margin-top:.2rem"><span>Poor</span><span>Fair</span><span>Good</span><span>Excellent</span></div>
  </div>

  <!-- Sleep Phases -->
  <div style="margin-bottom:1.2rem">
    <label style="display:block;font-size:.68rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:.5rem"><i class="bi bi-activity" style="margin-right:.3rem;color:#34d399"></i> Sleep Phases (hours)</label>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:.6rem">
      <div style="text-align:center;padding:.6rem;background:rgba(96,165,250,.06);border:1px solid rgba(96,165,250,.12);border-radius:10px">
        <input type="number" id="logDeepSleep" value="2" min="0" max="12" step="0.5" style="width:100%;background:transparent;border:none;color:#60a5fa;font-family:var(--font-display);font-size:1.3rem;text-align:center;outline:none">
        <div style="font-size:.58rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin-top:.1rem">Deep</div>
      </div>
      <div style="text-align:center;padding:.6rem;background:rgba(167,139,250,.06);border:1px solid rgba(167,139,250,.12);border-radius:10px">
        <input type="number" id="logRemSleep" value="1.5" min="0" max="12" step="0.5" style="width:100%;background:transparent;border:none;color:#a78bfa;font-family:var(--font-display);font-size:1.3rem;text-align:center;outline:none">
        <div style="font-size:.58rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin-top:.1rem">REM</div>
      </div>
      <div style="text-align:center;padding:.6rem;background:rgba(52,211,153,.06);border:1px solid rgba(52,211,153,.12);border-radius:10px">
        <input type="number" id="logLightSleep" value="3.5" min="0" max="12" step="0.5" style="width:100%;background:transparent;border:none;color:#34d399;font-family:var(--font-display);font-size:1.3rem;text-align:center;outline:none">
        <div style="font-size:.58rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin-top:.1rem">Light</div>
      </div>
    </div>
  </div>

  <!-- Mood Selector -->
  <div style="margin-bottom:1.2rem">
    <label style="display:block;font-size:.68rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:.5rem"><i class="bi bi-emoji-smile" style="margin-right:.3rem;color:#fbbf24"></i> Wake-up Mood</label>
    <div style="display:flex;gap:.5rem" id="moodSelector">
      <div class="sleep-mood-btn" data-mood="exhausted" onclick="selectMood(this)" title="Exhausted">😫</div>
      <div class="sleep-mood-btn" data-mood="tired" onclick="selectMood(this)" title="Tired">😴</div>
      <div class="sleep-mood-btn" data-mood="okay" onclick="selectMood(this)" title="Okay">😐</div>
      <div class="sleep-mood-btn active" data-mood="good" onclick="selectMood(this)" title="Good">😊</div>
      <div class="sleep-mood-btn" data-mood="great" onclick="selectMood(this)" title="Energized">😄</div>
      <div class="sleep-mood-btn" data-mood="amazing" onclick="selectMood(this)" title="Amazing">🤩</div>
    </div>
  </div>

  <!-- Notes -->
  <div style="margin-bottom:1.5rem">
    <label style="display:block;font-size:.68rem;font-weight:700;color:rgba(255,255,255,.5);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:.4rem"><i class="bi bi-journal-text" style="margin-right:.3rem;color:var(--accent)"></i> Notes (optional)</label>
    <textarea id="logSleepNotes" placeholder="How did you sleep? Any dreams?" rows="2" style="width:100%;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:.6rem .8rem;color:#fff;font-size:.82rem;font-family:var(--font-body);resize:none;outline:none;transition:border-color .2s" onfocus="this.style.borderColor='#a78bfa'" onblur="this.style.borderColor='rgba(255,255,255,.08)'"></textarea>
  </div>

  <!-- Sleep Tip -->
  <div style="display:flex;align-items:flex-start;gap:.6rem;padding:.7rem .9rem;background:rgba(167,139,250,.04);border:1px solid rgba(167,139,250,.1);border-radius:10px;margin-bottom:1.5rem">
    <i class="bi bi-lightbulb-fill" style="color:#fbbf24;font-size:.85rem;flex-shrink:0;margin-top:.1rem"></i>
    <div style="font-size:.72rem;color:rgba(255,255,255,.55);line-height:1.5">
      <strong style="color:rgba(255,255,255,.7)">Pro Tip:</strong> Maintain a consistent sleep schedule. Going to bed and waking up at the same time daily improves sleep quality by 35%.
    </div>
  </div>

  <!-- Save Button -->
  <button class="btn-solid" style="width:100%;padding:.85rem;font-size:.9rem;background:linear-gradient(135deg,#a78bfa,#8b5cf6);border-radius:12px;letter-spacing:.5px" onclick="saveSleepLog()"><i class="bi bi-check2-circle" style="margin-right:.3rem"></i> Save Sleep Data</button>
</div>
</div>
</div>

<script>
/* BMI Calculator */
function calcBMI(){var h=parseFloat(document.getElementById('bmiHeight').value)/100,w=parseFloat(document.getElementById('bmiWeight').value);if(!h||!w)return;var b=w/(h*h);document.getElementById('bmiResult').textContent=b.toFixed(1);var cat=b<18.5?'Underweight':b<25?'Normal Weight':b<30?'Overweight':'Obese';document.getElementById('bmiCategory').textContent=cat;var pct=Math.min(Math.max((b-15)/25*100,0),100);document.getElementById('bmiMarker').style.marginLeft=pct+'%';}
window.calcBMI=calcBMI;calcBMI();

/* Save Health Metrics */
function saveHealthMetrics(){var w=document.getElementById('logWeight').value,bf=document.getElementById('logBF').value,m=document.getElementById('logMuscle').value;if(w)document.getElementById('dispWeight').textContent=w;if(bf)document.getElementById('dispBF').textContent=bf;if(m)document.getElementById('dispMuscle').textContent=m;if(w){document.getElementById('bmiWeight').value=w;calcBMI();}closeModal('logMetricsModal');showToast('Health metrics logged successfully! 📊');}
window.saveHealthMetrics=saveHealthMetrics;

/* Save Sleep */
function updateSleepPreview() {
  var bed = document.getElementById('logBedtime').value;
  var wake = document.getElementById('logWake').value;
  if (!bed || !wake) return;
  var bp = bed.split(':'), wp = wake.split(':');
  var bedMin = parseInt(bp[0]) * 60 + parseInt(bp[1]);
  var wakeMin = parseInt(wp[0]) * 60 + parseInt(wp[1]);
  var diff = wakeMin - bedMin;
  if (diff <= 0) diff += 1440;
  var h = Math.floor(diff / 60), m = diff % 60;
  var el = document.getElementById('sleepDurationPreview');
  if (el) el.textContent = h + 'h ' + (m < 10 ? '0' : '') + m + 'm';
}
function updateQualDisplay(val) {
  var el = document.getElementById('sleepQualNum');
  if (el) el.textContent = val;
}
function selectMood(btn) {
  document.querySelectorAll('.sleep-mood-btn').forEach(function(b) { b.classList.remove('active'); });
  btn.classList.add('active');
}
function saveSleepLog() {
  var bed = document.getElementById('logBedtime').value || '23:30';
  var wake = document.getElementById('logWake').value || '06:45';
  var q = parseInt(document.getElementById('logSleepQual').value) || 8;
  var deep = parseFloat(document.getElementById('logDeepSleep').value) || 0;

  // Calculate duration — handle edge cases
  var bp = bed.split(':');
  var wp = wake.split(':');
  if (bp.length < 2 || wp.length < 2) { closeModal('sleepModal'); showToast('Please enter valid times','error'); return; }
  var bedMin = (parseInt(bp[0]) || 0) * 60 + (parseInt(bp[1]) || 0);
  var wakeMin = (parseInt(wp[0]) || 0) * 60 + (parseInt(wp[1]) || 0);
  var diff = wakeMin - bedMin;
  if (diff <= 0) diff += 1440;
  var h = Math.floor(diff / 60), m = diff % 60;

  // Update dashboard card — duration
  var display = document.getElementById('sleepDisplay');
  if (display) display.textContent = h + 'h ' + (m < 10 ? '0' : '') + m + 'm';

  // Update quality bar
  var pct = q * 10;
  var bar = document.getElementById('sleepQualBar');
  if (bar) bar.style.width = pct + '%';
  var pctEl = document.getElementById('sleepQualPct');
  if (pctEl) pctEl.textContent = pct + '%';

  // Update bedtime display
  var bedH = parseInt(bp[0]);
  bedH = bedH % 12 || 12;
  var bedVal = document.getElementById('sleepBedVal');
  if (bedVal) bedVal.textContent = bedH + ':' + bp[1];

  // Update wake time display
  var wakeH = parseInt(wp[0]);
  wakeH = wakeH % 12 || 12;
  var wakeVal = document.getElementById('sleepWakeVal');
  if (wakeVal) wakeVal.textContent = wakeH + ':' + wp[1];

  // Update deep hrs
  var deepVal = document.getElementById('sleepDeepVal');
  if (deepVal) deepVal.textContent = deep;

  // Update mood
  var activeMood = document.querySelector('.sleep-mood-btn.active');
  if (activeMood) {
    var moodMap = {exhausted:['😫','Exhausted'],tired:['😴','Tired'],okay:['😐','Okay'],good:['😊','Good'],great:['😄','Energized'],amazing:['🤩','Amazing']};
    var moodKey = activeMood.dataset.mood;
    var moodData = moodMap[moodKey] || ['😊','Good'];
    var moodEmoji = document.getElementById('sleepMoodEmoji');
    var moodText = document.getElementById('sleepMoodText');
    if (moodEmoji) moodEmoji.textContent = moodData[0];
    if (moodText) moodText.textContent = moodData[1];
  }

  // Sync to ApexState — store as decimal hours (e.g. 7.25 = 7h 15m)
  if (typeof ApexState !== 'undefined') {
    ApexState.set('sleepHrs', h + (m / 60));
  }

  closeModal('sleepModal');
  showToast('Sleep data logged successfully! 😴');
}
window.saveSleepLog = saveSleepLog;
window.updateSleepPreview = updateSleepPreview;
window.updateQualDisplay = updateQualDisplay;
window.selectMood = selectMood;

/* Export */
function exportHealthData(){showToast('Health report exported as PDF! 📄');}
window.exportHealthData=exportHealthData;

/* Charts */
if(typeof Chart!=='undefined'){
  if(document.getElementById('weightTrendChart')){new Chart(document.getElementById('weightTrendChart'),{type:'line',data:{labels:['Week 1','Week 2','Week 3','Week 4','Week 5','Week 6','Week 7','Week 8'],datasets:[{label:'Weight (kg)',data:[82,81.2,80.5,80,79.2,78.8,78.3,78],borderColor:'#C8F03D',backgroundColor:'rgba(200,240,61,.1)',fill:true,tension:.4,pointRadius:5,pointBackgroundColor:'#C8F03D',pointBorderColor:'#000',pointBorderWidth:2}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{min:75,max:84}}}});}
  if(document.getElementById('sleepHistChart')){new Chart(document.getElementById('sleepHistChart'),{type:'bar',data:{labels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],datasets:[{label:'Hours',data:[7.2,6.8,7.5,8.1,6.5,8.5,7.3],backgroundColor:'rgba(167,139,250,.3)',borderColor:'#a78bfa',borderWidth:1,borderRadius:8,barThickness:28}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{min:4,max:10,ticks:{callback:function(v){return v+'h'}}}}}});}
}

/* Animate HR */
(function(){var hr=document.getElementById('hrValue');if(!hr)return;setInterval(function(){hr.textContent=Math.floor(68+Math.random()*10);},3000);})();
</script>
</div>

<!-- AI INSIGHTS -->
<div class="mp-sec" id="sec-ai">
<h2 class="sec-title">AI <span>INSIGHTS</span><span class="sample-badge"><i class="bi bi-info-circle"></i> Sample Data</span></h2>

<!-- AI Score + Refresh Bar -->
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
<div style="display:flex;align-items:center;gap:1rem">
  <div style="width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#60a5fa);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.1rem;color:#000">82</div>
  <div><div style="font-weight:700;font-size:.95rem">Your AI Fitness Score</div><div style="font-size:.72rem;color:var(--gray)">Based on activity, nutrition & recovery</div></div>
</div>
<button class="btn-g" onclick="refreshAiInsights()" id="aiRefreshBtn"><i class="bi bi-arrow-clockwise"></i> Refresh Insights</button>
</div>

<!-- Dynamic Insight Cards -->
<div class="mp-grid3" id="aiCardsGrid">

<!-- Card 1: Performance -->
<div class="ai-card" style="grid-column:span 2" id="aiCard1">
<div style="display:flex;justify-content:space-between;align-items:flex-start">
  <div class="ai-tag"><i class="bi bi-stars"></i> Performance Analysis</div>
  <button onclick="dismissAiCard('aiCard1')" style="background:none;border:none;color:var(--gray);cursor:pointer;font-size:.9rem;padding:4px" title="Dismiss"><i class="bi bi-x-lg"></i></button>
</div>
<h4 id="aiTitle1">Weekly Trend Detected</h4>
<p id="aiBody1">Your workout intensity drops by 20% on Thursdays. We recommend switching Thursday to an active recovery day like Yoga or light Cardio to maintain consistency without burnout.</p>
<button class="btn-solid" style="margin-top:1rem" onclick="applyAiAction(this, 'Schedule adjusted! Thursday is now set as your active recovery day. 🧘')">Adjust My Schedule</button>
</div>

<!-- Card 2: Alert -->
<div class="ai-card" style="border-color:#f87171" id="aiCard2">
<div style="display:flex;justify-content:space-between;align-items:flex-start">
  <div class="ai-tag" style="color:#f87171"><i class="bi bi-exclamation-triangle"></i> Action Required</div>
  <button onclick="dismissAiCard('aiCard2')" style="background:none;border:none;color:var(--gray);cursor:pointer;font-size:.9rem;padding:4px" title="Dismiss"><i class="bi bi-x-lg"></i></button>
</div>
<h4 id="aiTitle2">Inactivity Alert</h4>
<p id="aiBody2">You haven't logged any cardio sessions this week. Add 20 mins of treadmill to your next workout to hit your cardiovascular goals.</p>
<button class="btn-solid" style="margin-top:1rem;background:#f87171;color:#000" onclick="applyAiAction(this, 'Cardio plan added! 20 min treadmill session queued for your next workout. 🏃')">Start Cardio Plan</button>
</div>

<!-- Card 3: Tip of the Day -->
<div class="ai-card" style="border-color:#34d399" id="aiCard3">
<div style="display:flex;justify-content:space-between;align-items:flex-start">
  <div class="ai-tag" style="color:#34d399"><i class="bi bi-lightbulb-fill"></i> Tip of the Day</div>
  <button onclick="dismissAiCard('aiCard3')" style="background:none;border:none;color:var(--gray);cursor:pointer;font-size:.9rem;padding:4px" title="Dismiss"><i class="bi bi-x-lg"></i></button>
</div>
<h4 id="aiTitle3">Optimize Your Protein Timing</h4>
<p id="aiBody3">Consume 25-30g of protein within 45 minutes of your workout to maximize muscle protein synthesis. A whey shake or chicken breast works best.</p>
</div>

<!-- Card 4: Weekly Summary -->
<div class="ai-card" style="grid-column:span 2;border-color:#60a5fa" id="aiCard4">
<div style="display:flex;justify-content:space-between;align-items:flex-start">
  <div class="ai-tag" style="color:#60a5fa"><i class="bi bi-graph-up-arrow"></i> Weekly Summary</div>
  <button onclick="dismissAiCard('aiCard4')" style="background:none;border:none;color:var(--gray);cursor:pointer;font-size:.9rem;padding:4px" title="Dismiss"><i class="bi bi-x-lg"></i></button>
</div>
<h4>This Week at a Glance</h4>
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-top:1rem">
  <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:var(--accent)">4</div><div style="font-size:.68rem;color:var(--gray)">Workouts</div></div>
  <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#60a5fa">1,320</div><div style="font-size:.68rem;color:var(--gray)">Kcal Burned</div></div>
  <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#34d399">2.1L</div><div style="font-size:.68rem;color:var(--gray)">Avg Water</div></div>
  <div style="text-align:center"><div style="font-size:1.5rem;font-weight:800;color:#a78bfa">7.2h</div><div style="font-size:.68rem;color:var(--gray)">Avg Sleep</div></div>
</div>
<p style="margin-top:1rem;font-size:.78rem;color:var(--gray)">You're <span style="color:var(--accent);font-weight:700">12% ahead</span> of last week. Keep this momentum going!</p>
</div>

<!-- Card 5: Motivation -->
<div class="ai-card" style="border-color:#fbbf24" id="aiCard5">
<div style="display:flex;justify-content:space-between;align-items:flex-start">
  <div class="ai-tag" style="color:#fbbf24"><i class="bi bi-trophy-fill"></i> Milestone Alert</div>
  <button onclick="dismissAiCard('aiCard5')" style="background:none;border:none;color:var(--gray);cursor:pointer;font-size:.9rem;padding:4px" title="Dismiss"><i class="bi bi-x-lg"></i></button>
</div>
<h4>You're 3 workouts away from your 50-session badge!</h4>
<p>Keep going — only 3 more sessions to unlock the <strong style="color:#fbbf24">Gold Warrior</strong> achievement. Your consistency is paying off!</p>
</div>

</div>

<script>
/* AI Insights — dynamic content pool */
var aiPool = [
  {tag:'Performance Analysis',icon:'bi-stars',color:'var(--accent)',title:'Leg Day Improvement',body:'Your squat form has improved by 15% this month based on rep consistency. Consider adding 5kg to your working set next session.',action:'Apply Suggestion'},
  {tag:'Recovery Alert',icon:'bi-heart-pulse',color:'#f87171',title:'Rest Day Recommended',body:'Your recovery score has dropped to 62%. Your body needs rest. We recommend taking tomorrow off or doing light stretching only.',action:'Schedule Rest Day'},
  {tag:'Nutrition Insight',icon:'bi-egg-fried',color:'#34d399',title:'Protein Deficit Detected',body:'You\'ve been averaging 120g protein daily, 40g below your target. Try adding a protein shake post-workout and Greek yogurt as a snack.',action:null},
  {tag:'Sleep Analysis',icon:'bi-moon-stars',color:'#a78bfa',title:'Sleep Pattern Shift',body:'Your sleep schedule shifted 45 minutes later this week. Consistent sleep times improve recovery by up to 23%. Try going to bed by 10:30 PM.',action:null},
  {tag:'Cardio Progress',icon:'bi-speedometer2',color:'#60a5fa',title:'Cardio Endurance Up',body:'Your average treadmill session increased from 18 to 25 minutes. At this pace, you\'ll hit your 5K goal within 3 weeks.',action:'View Running Plan'},
  {tag:'Strength Milestone',icon:'bi-lightning-fill',color:'#fbbf24',title:'New PR Approaching',body:'Your bench press is trending at 117kg. Based on your progression, you could attempt 120kg within the next 2 weeks.',action:'Set PR Reminder'},
  {tag:'Hydration Alert',icon:'bi-droplet-fill',color:'#60a5fa',title:'Hydration Below Target',body:'You\'ve averaged only 1.8L daily this week. Dehydration reduces strength by up to 25%. Set hourly reminders to drink water.',action:'Set Reminders'},
  {tag:'Workout Variety',icon:'bi-shuffle',color:'var(--accent)',title:'Muscle Group Imbalance',body:'You\'ve trained chest 4x this week but skipped back entirely. Add rows or lat pulldowns to prevent posture issues and imbalances.',action:'Fix My Split'},
  {tag:'Progress Update',icon:'bi-graph-up',color:'#34d399',title:'Body Composition Improving',body:'Based on your logged metrics, your body fat has decreased from 19.5% to 18% over the past month while muscle mass increased by 0.8kg.',action:null},
  {tag:'Consistency Check',icon:'bi-calendar-check',color:'#fbbf24',title:'Streak at Risk!',body:'You\'ve worked out 6 days straight — amazing! But your recovery score is low. Take tomorrow off to protect your 7-day streak quality.',action:null}
];
var aiIndex = 0;

function refreshAiInsights() {
  var btn = document.getElementById('aiRefreshBtn');
  btn.innerHTML = '<i class="bi bi-arrow-clockwise" style="animation:spin .5s linear infinite"></i> Refreshing...';
  btn.disabled = true;
  
  setTimeout(function() {
    // Rotate through pool
    var c1 = aiPool[aiIndex % aiPool.length];
    var c2 = aiPool[(aiIndex + 1) % aiPool.length];
    var c3 = aiPool[(aiIndex + 2) % aiPool.length];
    aiIndex += 3;
    
    // Update card 1
    updateAiCard('aiCard1', c1);
    // Update card 2
    updateAiCard('aiCard2', c2);
    // Update card 3
    updateAiCard('aiCard3', c3);
    
    // Restore dismissed cards
    ['aiCard1','aiCard2','aiCard3','aiCard4','aiCard5'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) { el.style.display = ''; el.style.opacity = '1'; }
    });
    
    btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Refresh Insights';
    btn.disabled = false;
    if (typeof showToast === 'function') showToast('AI insights refreshed with latest analysis! 🤖');
  }, 800);
}

function updateAiCard(cardId, data) {
  var card = document.getElementById(cardId);
  if (!card) return;
  var tagEl = card.querySelector('.ai-tag');
  var titleEl = card.querySelector('h4');
  var bodyEl = card.querySelector('p');
  var actionBtn = card.querySelector('.btn-solid');
  
  if (tagEl) { tagEl.innerHTML = '<i class="bi ' + data.icon + '"></i> ' + data.tag; tagEl.style.color = data.color; }
  if (titleEl) titleEl.textContent = data.title;
  if (bodyEl) bodyEl.textContent = data.body;
  card.style.borderColor = data.color === 'var(--accent)' ? '' : data.color;
  
  if (actionBtn) {
    if (data.action) { actionBtn.textContent = data.action; actionBtn.style.display = ''; actionBtn.disabled = false; actionBtn.style.background = ''; }
    else { actionBtn.style.display = 'none'; }
  }
  
  card.style.opacity = '0'; card.style.transform = 'translateY(10px)';
  setTimeout(function() { card.style.transition = 'all .3s ease'; card.style.opacity = '1'; card.style.transform = 'translateY(0)'; }, 100);
}

function dismissAiCard(id) {
  var el = document.getElementById(id);
  if (!el) return;
  el.style.transition = 'opacity .3s ease, transform .3s ease';
  el.style.opacity = '0';
  el.style.transform = 'scale(0.95)';
  setTimeout(function() { el.style.display = 'none'; if (typeof showToast === 'function') showToast('Insight dismissed. Refresh for new insights.'); }, 300);
}

function applyAiAction(btn, msg) {
  btn.disabled = true;
  btn.innerHTML = '<i class="bi bi-check-circle-fill"></i> Applied!';
  btn.style.background = '#34d399';
  btn.style.color = '#000';
  if (typeof showToast === 'function') showToast(msg);
}
</script>
<style>@keyframes spin{to{transform:rotate(360deg)}}</style>
</div><!-- /sec-ai -->

<!-- CHAT -->
<div class="mp-sec" id="sec-chat">
<h2 class="sec-title">CHAT & <span>ALERTS</span></h2>
<div class="mp-grid2">
<div class="mp-card">
<h4><i class="bi bi-chat-dots"></i> Message Trainer</h4>
<div class="chat-messages" id="chatMessages">
<div class="chat-msg received">Hey! How are you feeling after yesterday's leg day?<div class="chat-time">Trainer · 09:00 AM</div></div>
<div class="chat-msg sent">A bit sore, but feeling good! Got my protein in.<div class="chat-time">10:15 AM</div></div>
<div class="chat-msg received">Awesome. Today we're focusing on Upper Body Power. Check your routine tab.<div class="chat-time">Trainer · 10:20 AM</div></div>
</div>
<div class="chat-input-bar">
<input type="text" class="chat-input" id="chatInput" placeholder="Type a message...">
<button class="chat-send" onclick="sendChat()"><i class="bi bi-send-fill"></i></button>
</div>
</div>
<div class="mp-card">
<h4><i class="bi bi-megaphone"></i> Gym Announcements</h4>
<div class="announce-item"><div class="announce-icon warn"><i class="bi bi-tools"></i></div><div><div style="font-weight:700;font-size:.85rem">Maintenance Notice</div><div style="font-size:.75rem;color:var(--gray)">Sauna will be closed tomorrow from 10AM-2PM.</div></div></div>
<div class="announce-item"><div class="announce-icon success"><i class="bi bi-tags-fill"></i></div><div><div style="font-weight:700;font-size:.85rem">New Supplements Arrived</div><div style="font-size:.75rem;color:var(--gray)">ON Gold Standard Whey is back in stock!</div></div></div>
<div class="announce-item"><div class="announce-icon info"><i class="bi bi-calendar-event"></i></div><div><div style="font-weight:700;font-size:.85rem">Yoga Workshop</div><div class="pill pill-blue" style="margin-top:.3rem;padding:.15rem .5rem;font-size:.6rem">Register Now</div></div></div>
</div>
</div>
</div>

<!-- NOTIFICATIONS -->
<div class="mp-sec" id="sec-notif">
<h2 style="font-family:var(--font-display);font-size:2rem;letter-spacing:1px;margin-bottom:1.5rem"><span style="color:var(--accent)">NOTIFICATIONS</span></h2>
<div style="display:flex;flex-direction:column;gap:1rem">
<div style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:1rem;display:flex;gap:1rem;align-items:flex-start"><div class="ir-ic" style="background:rgba(96,165,250,.1);color:#60a5fa"><i class="bi bi-calendar-event"></i></div><div><div style="font-weight:700;font-size:.9rem">Class Reminder</div><div style="font-size:.8rem;color:var(--gray)">You have Vinyasa Yoga booked for tomorrow at 6:30 PM.</div><div style="font-size:.7rem;color:var(--gray2);margin-top:.3rem">2 hours ago</div></div></div>
<div style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:1rem;display:flex;gap:1rem;align-items:flex-start"><div class="ir-ic" style="background:rgba(var(--accent-rgb),.1);color:var(--accent)"><i class="bi bi-trophy"></i></div><div><div style="font-weight:700;font-size:.9rem">Goal Achieved!</div><div style="font-size:.8rem;color:var(--gray)">You hit your 7-day workout streak. Keep it up!</div><div style="font-size:.7rem;color:var(--gray2);margin-top:.3rem">Yesterday</div></div></div>
</div></div>

<!-- PAYMENTS -->
<div class="mp-sec" id="sec-payments">
<div class="sec-header">
<h2 class="sec-title">BILLING & <span>PAYMENTS</span></h2>
<button class="btn-solid" onclick="openModal('renewModal')">Renew Plan</button>
</div>
<div class="mp-grid3">
<div class="mp-card" style="grid-column:span 2;overflow-x:auto">
<h4><i class="bi bi-clock-history"></i> Payment History</h4>
<table class="pay-table" style="min-width:500px">
<tr><th>Date</th><th>Description</th><th>Amount</th><th>Status</th><th>Invoice</th></tr>
<tr><td>Oct 01, 2025</td><td>Standard Plan (Monthly)</td><td>Rs. 4,500</td><td><span class="pay-status paid">PAID</span></td><td><button class="nb" onclick="openInvoice('INV-20251001','Oct 01, 2025','Rs. 4,500')"><i class="bi bi-download"></i></button></td></tr>
<tr><td>Sep 01, 2025</td><td>Standard Plan (Monthly)</td><td>Rs. 4,500</td><td><span class="pay-status paid">PAID</span></td><td><button class="nb" onclick="openInvoice('INV-20250901','Sep 01, 2025','Rs. 4,500')"><i class="bi bi-download"></i></button></td></tr>
<tr><td>Aug 15, 2025</td><td>Supplement: ON Whey</td><td>Rs. 20,000</td><td><span class="pay-status paid">PAID</span></td><td><button class="nb" onclick="openInvoice('INV-20250815','Aug 15, 2025','Rs. 20,000')"><i class="bi bi-download"></i></button></td></tr>
</table>
</div>
<div class="mp-card">
<h4><i class="bi bi-credit-card"></i> Saved Methods</h4>
<div class="ir"><div class="ir-ic" style="background:#1a1f36;color:#fff"><i class="bi bi-stripe"></i></div><div style="flex:1"><div class="ir-val">Visa ending in 4242</div><div class="ir-lbl">Expires 12/26</div></div></div>
<div class="toggle-wrap" style="margin-top:1.5rem"><div class="toggle-label">Auto-Renew Membership<div class="toggle-sub">Card will be charged automatically</div></div><button class="toggle-switch on" onclick="toggleSwitch(this)"></button></div>
<div style="margin-top:1.5rem;padding-top:1.5rem;border-top:1px solid var(--border)">
<div style="font-size:.8rem;color:var(--gray);margin-bottom:.5rem">Have a Promo Code?</div>
<div style="display:flex;gap:.5rem">
<input type="text" id="promoInput" placeholder="Enter code" style="flex:1;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px;padding:.5rem 1rem;color:#fff;outline:none">
<button class="btn-g" onclick="applyPromo()">Apply</button>
</div>
</div>
</div>
</div>
</div>

</main></div>

<!-- FAB -->
<div class="fab-portal">
<button class="fab-btn" id="fabBtn"><i class="bi bi-plus-lg"></i></button>
<div class="fab-actions" id="fabActions">
<div class="fab-action" data-tip="Start Workout" onclick="showSec('workout')"><i class="bi bi-play-fill"></i></div>
<div class="fab-action" data-tip="Log Meal" onclick="showSec('nutrition')"><i class="bi bi-apple"></i></div>
<div class="fab-action" data-tip="Message Trainer" onclick="showSec('chat')"><i class="bi bi-chat-dots"></i></div>
<div class="fab-action" data-tip="Check In" onclick="showSec('checkin')"><i class="bi bi-qr-code-scan"></i></div>
</div>
</div>

<!-- MODALS -->
<div class="modal-overlay" id="renewModal">
  <div class="modal-box">
    <button class="modal-close" onclick="closeModal('renewModal')">&times;</button>
    <div class="m-title">RENEW <span style="color:var(--accent)">MEMBERSHIP</span></div>
    <div class="m-plan-card">
      <div style="font-size:.7rem;color:var(--gray);text-transform:uppercase">Current Plan</div>
      <div style="font-family:var(--font-display);font-size:1.8rem;color:var(--accent)" id="rn-plan-name">${empty member.planName ? 'Standard Plan' : member.planName}</div>
      <div style="font-size:.8rem;color:var(--gray);margin-top:.4rem">Expires: <span style="color:#f87171">in 15 days</span></div>
    </div>
    <div style="font-size:.8rem;color:var(--gray);margin-bottom:.8rem">Select Duration</div>
    <div class="m-dur-grid">
      <div class="m-dur-btn" onclick="selDur(this, 1)">
        <div class="m-mos">1 Month</div>
      </div>
      <div class="m-dur-btn active" onclick="selDur(this, 3)">
        <div class="m-mos">3 Months</div>
        <div class="m-dsc">Save 10%</div>
      </div>
      <div class="m-dur-btn" onclick="selDur(this, 6)">
        <div class="m-mos">6 Months</div>
        <div class="m-dsc">Save 15%</div>
      </div>
      <div class="m-dur-btn" onclick="selDur(this, 12)">
        <div class="m-mos">12 Months</div>
        <div class="m-dsc">Save 25%</div>
      </div>
    </div>
    <div style="font-size:.8rem;color:var(--gray);margin-bottom:.8rem">Payment Method</div>
    <div class="pay-grid">
      <div class="pay-btn active" onclick="selPay(this)"><i class="bi bi-credit-card-2-front"></i> Credit Card</div>
      <div class="pay-btn" onclick="selPay(this)"><i class="bi bi-paypal"></i> PayPal</div>
    </div>
    <div class="m-total">
      <span style="color:var(--gray)">Total Amount:</span>
      <span style="font-size:1.5rem;font-weight:700;color:var(--white)" id="rn-total">Rs.12,150</span>
    </div>
    <button class="btn-solid" style="width:100%;padding:1rem;font-size:1rem" onclick="confirmRenew(this)"><span class="btn-loader"></span> Confirm Renewal</button>
  </div>
</div>

<div class="modal-overlay" id="upgradeModal">
  <div class="modal-box" style="max-width:700px">
    <button class="modal-close" onclick="closeModal('upgradeModal')">&times;</button>
    <div class="m-title">UPGRADE <span style="color:var(--accent)">PLAN</span></div>
    <div class="mp-grid2">
      <!-- Standard (Current) -->
      <div class="mp-card" style="opacity:.6;position:relative">
        <div class="pill pill-accent" style="position:absolute;top:-10px;right:10px">Current</div>
        <div style="font-size:.7rem;color:var(--gray);text-transform:uppercase">From</div>
        <h4 style="margin-bottom:.5rem">Standard Plan</h4>
        <div style="font-size:1.5rem;font-weight:700;margin-bottom:1rem">Rs.4,500<span style="font-size:.8rem;color:var(--gray);font-weight:400">/mo</span></div>
        <ul style="list-style:none;font-size:.8rem;color:var(--gray);line-height:2">
          <li style="color:#fff"><i class="bi bi-check" style="color:var(--accent)"></i> 24/7 Access</li>
          <li style="color:#fff"><i class="bi bi-check" style="color:var(--accent)"></i> Group Classes</li>
          <li><i class="bi bi-x"></i> Personal Trainer</li>
        </ul>
      </div>
      <!-- Premium (Upgrade) -->
      <div class="mp-card" style="border-color:var(--accent);position:relative">
        <div class="pill pill-blue" style="position:absolute;top:-10px;right:10px"><i class="bi bi-star-fill"></i> Recommended</div>
        <div style="font-size:.7rem;color:var(--accent);text-transform:uppercase">To</div>
        <h4 style="margin-bottom:.5rem">Premium Plan</h4>
        <div style="font-size:1.5rem;font-weight:700;color:var(--accent);margin-bottom:1rem">Rs.7,500<span style="font-size:.8rem;color:var(--gray);font-weight:400">/mo</span></div>
        <ul style="list-style:none;font-size:.8rem;color:var(--gray);line-height:2">
          <li style="color:#fff"><i class="bi bi-check" style="color:var(--accent)"></i> 24/7 Access</li>
          <li style="color:#fff"><i class="bi bi-check" style="color:var(--accent)"></i> All Classes</li>
          <li style="color:#fff"><i class="bi bi-check" style="color:var(--accent)"></i> Personal Trainer</li>
        </ul>
      </div>
    </div>
    <div class="m-total" style="margin-top:1.5rem">
      <div>
        <div style="color:var(--gray);font-size:.8rem">Prorated Upgrade Cost:</div>
        <div style="color:var(--accent);font-size:.75rem">Remaining 15 days adjusted</div>
      </div>
      <span style="font-size:1.5rem;font-weight:700;color:var(--white)">Rs.1,500</span>
    </div>
    <button class="btn-solid" style="width:100%;padding:1rem;font-size:1rem" onclick="confirmUpgrade(this)"><span class="btn-loader"></span> Confirm Upgrade</button>
  </div>
</div>

<div class="modal-overlay" id="checkoutModal">
  <div class="modal-box">
    <button class="modal-close" onclick="closeModal('checkoutModal')">&times;</button>
    <div class="m-title">SECURE <span style="color:var(--accent)">CHECKOUT</span></div>
    
    <div style="background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:12px;padding:1.5rem;margin-bottom:1.5rem">
      <div style="font-size:.8rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin-bottom:.5rem">Order Summary</div>
      <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border);padding-bottom:1rem;margin-bottom:1rem">
        <div style="font-weight:700;color:#fff" id="co-prod-name">MuscleTech Whey</div>
        <div style="font-family:var(--font-display);font-size:1.5rem;color:var(--accent)" id="co-prod-price">Rs. 15,000</div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:.9rem;color:var(--gray)">
        <span>Shipping (Standard)</span>
        <span>Rs. 500</span>
      </div>
    </div>

    <div style="font-size:.8rem;color:var(--gray);margin-bottom:.8rem">Select Payment Method</div>
    <div class="pay-grid" style="grid-template-columns:1fr 1fr 1fr">
      <div class="pay-btn active" onclick="selCheckoutPay(this)"><i class="bi bi-credit-card"></i> Card</div>
      <div class="pay-btn" onclick="selCheckoutPay(this)"><i class="bi bi-paypal"></i> PayPal</div>
      <div class="pay-btn" onclick="selCheckoutPay(this)"><i class="bi bi-cash"></i> Koko</div>
    </div>
    
    <div id="card-details" style="display:block;margin-bottom:1.5rem">
      <input type="text" placeholder="Card Number (0000 0000 0000 0000)" style="width:100%;background:rgba(0,0,0,.5);border:1px solid var(--border);border-radius:8px;padding:.8rem;color:#fff;margin-bottom:.8rem">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem">
        <input type="text" placeholder="MM/YY" style="width:100%;background:rgba(0,0,0,.5);border:1px solid var(--border);border-radius:8px;padding:.8rem;color:#fff">
        <input type="text" placeholder="CVV" style="width:100%;background:rgba(0,0,0,.5);border:1px solid var(--border);border-radius:8px;padding:.8rem;color:#fff">
      </div>
    </div>

    <div class="m-total">
      <span style="color:var(--gray)">Total Payable:</span>
      <span style="font-size:1.5rem;font-weight:700;color:var(--white)" id="co-total">Rs. 15,500</span>
    </div>
    <button class="btn-solid" style="width:100%;padding:1rem;font-size:1rem" onclick="processCheckout(this)"><span class="btn-loader"></span> Pay Now</button>
  </div>
</div>

<div class="toast-msg" id="toastMsg"><i class="bi bi-check-circle"></i> <span>Success!</span></div>

<!-- NEW MODALS -->
<div class="modal-overlay" id="restTimerModal">
<div class="modal-box narrow">
<button class="modal-close" onclick="closeModal('restTimerModal'); stopTimer();">&times;</button>
<div class="m-title" style="text-align:center">REST <span style="color:var(--accent)">TIMER</span></div>
<div class="timer-ring-wrap">
<svg width="180" height="180"><circle class="ring-bg" cx="90" cy="90" r="80"></circle><circle class="ring-fg" id="timerRing" cx="90" cy="90" r="80"></circle></svg>
<div style="position:absolute;display:flex;flex-direction:column;align-items:center"><div class="timer-display" id="timerDisplay">01:00</div><div class="timer-label">Remaining</div></div>
</div>
<div class="timer-presets">
<button class="timer-preset" onclick="setTimerPreset(this, 30)">30s</button>
<button class="timer-preset active" onclick="setTimerPreset(this, 60)">60s</button>
<button class="timer-preset" onclick="setTimerPreset(this, 90)">90s</button>
<button class="timer-preset" onclick="setTimerPreset(this, 120)">120s</button>
</div>
<div style="display:flex;gap:1rem;margin-top:1.5rem">
<button class="btn-solid" style="flex:1" id="timerStartBtn" onclick="startTimer()">Start</button>
<button class="btn-g" style="flex:1;justify-content:center" onclick="stopTimer()">Reset</button>
</div>
</div>
</div>

<div class="modal-overlay" id="groceryListModal">
<div class="modal-box narrow">
<button class="modal-close" onclick="closeModal('groceryListModal')">&times;</button>
<div class="m-title">GROCERY <span style="color:var(--accent)">LIST</span></div>
<div class="modal-body-scroll">
<div style="font-size:.8rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin:1rem 0 .5rem">Proteins</div>
<div class="grocery-item"><div class="grocery-check" onclick="toggleGrocery(this)"><i class="bi bi-check-lg"></i></div><div class="grocery-text">Chicken Breast</div><div class="grocery-qty">1 kg</div></div>
<div class="grocery-item"><div class="grocery-check" onclick="toggleGrocery(this)"><i class="bi bi-check-lg"></i></div><div class="grocery-text">Eggs</div><div class="grocery-qty">1 dozen</div></div>
<div class="grocery-item"><div class="grocery-check" onclick="toggleGrocery(this)"><i class="bi bi-check-lg"></i></div><div class="grocery-text">Salmon Fillets</div><div class="grocery-qty">500 g</div></div>
<div style="font-size:.8rem;color:var(--gray);text-transform:uppercase;letter-spacing:1px;margin:1.5rem 0 .5rem">Carbs & Veggies</div>
<div class="grocery-item"><div class="grocery-check" onclick="toggleGrocery(this)"><i class="bi bi-check-lg"></i></div><div class="grocery-text">Sweet Potatoes</div><div class="grocery-qty">1 kg</div></div>
<div class="grocery-item"><div class="grocery-check" onclick="toggleGrocery(this)"><i class="bi bi-check-lg"></i></div><div class="grocery-text">Broccoli</div><div class="grocery-qty">2 heads</div></div>
<div class="grocery-item"><div class="grocery-check" onclick="toggleGrocery(this)"><i class="bi bi-check-lg"></i></div><div class="grocery-text">Brown Rice</div><div class="grocery-qty">1 pack</div></div>
</div>
<button class="btn-solid" style="width:100%;margin-top:1.5rem" onclick="closeModal('groceryListModal')">Done</button>
</div>
</div>

<div class="modal-overlay" id="invoiceModal">
<div class="modal-box narrow">
<button class="modal-close" onclick="closeModal('invoiceModal')">&times;</button>
<div style="text-align:center;margin-bottom:1.5rem">
<div style="font-family:var(--font-display);font-size:2rem;letter-spacing:2px">APEX<span style="color:var(--accent)">FITNESS</span></div>
<div style="font-size:.7rem;color:var(--gray)">Invoice Details</div>
</div>
<div style="background:rgba(255,255,255,.03);border:1px dashed var(--border);border-radius:12px;padding:1.5rem;margin-bottom:1.5rem">
<div class="ir"><div class="ir-lbl" style="width:80px">Invoice No</div><div class="ir-val" id="inv-num">INV-000</div></div>
<div class="ir"><div class="ir-lbl" style="width:80px">Date</div><div class="ir-val" id="inv-date">Jan 01, 2026</div></div>
<div class="ir"><div class="ir-lbl" style="width:80px">Status</div><div class="ir-val" style="color:#34d399;font-weight:700">PAID</div></div>
<div style="border-top:1px solid var(--border);margin-top:1rem;padding-top:1rem;display:flex;justify-content:space-between;align-items:center">
<div style="color:var(--gray)">Total Amount</div>
<div style="font-size:1.5rem;font-weight:700;color:var(--white)" id="inv-amount">Rs. 0</div>
</div>
</div>
<button class="btn-solid" style="width:100%"><i class="bi bi-download"></i> Download PDF</button>
</div>
</div>

<!-- ══════════════ WORKOUT SESSION OVERLAY ══════════════ -->
<div class="ws-overlay" id="wsOverlay">
  <!-- TOP BAR -->
  <div class="ws-topbar">
    <div class="ws-plan-name" id="wsPlanName">Upper Body Power</div>
    <div class="ws-topbar-center">
      <div class="ws-timer-display" id="wsMainTimer">00:00</div>
      <div class="ws-timer-label">Workout Time</div>
    </div>
    <button class="ws-end-btn" onclick="endWorkoutSession()"><i class="bi bi-x-lg"></i> End Workout</button>
  </div>

  <!-- PROGRESS BAR + STATS -->
  <div class="ws-progress-bar-wrap">
    <div class="ws-prog-stats">
      <span id="wsExDone">0</span>/<span id="wsExTotal">6</span> Exercises
      &nbsp;·&nbsp;
      <span id="wsSetsDone">0</span> Sets Done
      &nbsp;·&nbsp;
      <span id="wsKcal">0</span> kcal
    </div>
    <div class="ws-prog-track"><div class="ws-prog-fill" id="wsProgFill" style="width:0%"></div></div>
    <div class="ws-prog-pct" id="wsProgPct">0% Complete</div>
  </div>

  <!-- MAIN BODY -->
  <div class="ws-body">
    <!-- LEFT: Exercise list -->
    <div class="ws-ex-list-panel">
      <div class="ws-panel-title"><i class="bi bi-list-check"></i> Exercise Queue</div>
      <div class="ws-ex-list" id="wsExList"></div>
    </div>

    <!-- CENTER: Active exercise -->
    <div class="ws-active-panel">
      <div class="ws-ex-header">
        <div class="ws-ex-num" id="wsExNum">Exercise 1 of 6</div>
        <div class="ws-ex-name" id="wsExName">Barbell Bench Press</div>
        <div class="ws-ex-target" id="wsExTarget">4 sets × 8–10 reps</div>
        <div class="ws-ex-muscle" id="wsExMuscle"><i class="bi bi-lightning-fill"></i> Chest · Primary</div>
      </div>

      <!-- Set tracker -->
      <div class="ws-sets-wrap">
        <div class="ws-sets-header">
          <span>Set</span><span>Target</span><span>Reps Done</span><span>Weight</span><span>Status</span>
        </div>
        <div id="wsSetsBody"></div>
      </div>

      <!-- Action buttons -->
      <div class="ws-action-row">
        <button class="ws-act-btn skip" onclick="wsSkipExercise()"><i class="bi bi-skip-forward-fill"></i> Skip</button>
        <button class="ws-act-btn complete" id="wsCompleteSetBtn" onclick="wsCompleteCurrentSet()"><i class="bi bi-check-lg"></i> Complete Set</button>
        <button class="ws-act-btn rest" onclick="wsStartRest()"><i class="bi bi-stopwatch-fill"></i> Rest Timer</button>
      </div>

      <!-- Rest timer (inline) -->
      <div class="ws-rest-panel" id="wsRestPanel" style="display:none">
        <div class="ws-rest-title"><i class="bi bi-moon-stars-fill"></i> Rest Period</div>
        <div class="ws-rest-ring-wrap">
          <svg width="140" height="140" style="transform:rotate(-90deg)">
            <circle cx="70" cy="70" r="60" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="8"/>
            <circle id="wsRestRing" cx="70" cy="70" r="60" fill="none" stroke="var(--accent)" stroke-width="8"
              stroke-dasharray="377" stroke-dashoffset="0" stroke-linecap="round"/>
          </svg>
          <div class="ws-rest-center">
            <div class="ws-rest-secs" id="wsRestSecs">60</div>
            <div style="font-size:.65rem;color:var(--gray);letter-spacing:1px">SECONDS</div>
          </div>
        </div>
        <div class="ws-rest-presets">
          <button onclick="wsSetRest(30)">30s</button>
          <button class="active" onclick="wsSetRest(60)">60s</button>
          <button onclick="wsSetRest(90)">90s</button>
          <button onclick="wsSetRest(120)">2m</button>
        </div>
        <div class="ws-rest-btns">
          <button class="ws-act-btn skip" onclick="wsStopRest()"><i class="bi bi-skip-forward-fill"></i> Skip Rest</button>
          <button class="ws-act-btn complete" id="wsRestStartBtn" onclick="wsToggleRest()"><i class="bi bi-play-fill"></i> Start</button>
        </div>
      </div>

      <!-- Next exercise preview -->
      <div class="ws-next-ex" id="wsNextEx">
        <span class="ws-next-label">UP NEXT</span>
        <span id="wsNextName">Incline Dumbbell Press</span>
        <span id="wsNextMeta" style="color:var(--gray);font-size:.75rem">3×10-12</span>
      </div>
    </div>

    <!-- RIGHT: Progress ring + tips -->
    <div class="ws-right-panel">
      <!-- Circular progress -->
      <div class="ws-ring-wrap">
        <svg width="160" height="160" style="transform:rotate(-90deg)">
          <circle cx="80" cy="80" r="68" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="10"/>
          <circle id="wsProgressRing" cx="80" cy="80" r="68" fill="none" stroke="var(--accent)" stroke-width="10"
            stroke-dasharray="427" stroke-dashoffset="427" stroke-linecap="round" style="transition:stroke-dashoffset .6s ease"/>
        </svg>
        <div class="ws-ring-center">
          <div class="ws-ring-pct" id="wsRingPct">0%</div>
          <div style="font-size:.6rem;color:var(--gray);letter-spacing:1px">DONE</div>
        </div>
      </div>

      <!-- Live stats cards -->
      <div class="ws-live-stats">
        <div class="ws-stat-card"><i class="bi bi-clock-fill"></i><div class="ws-sc-val" id="wsTimeStat">0m</div><div class="ws-sc-lbl">Time</div></div>
        <div class="ws-stat-card"><i class="bi bi-fire" style="color:#f87171"></i><div class="ws-sc-val" id="wsKcalStat">0</div><div class="ws-sc-lbl">kcal</div></div>
        <div class="ws-stat-card"><i class="bi bi-repeat" style="color:#60a5fa"></i><div class="ws-sc-val" id="wsTotalSets">0</div><div class="ws-sc-lbl">Sets</div></div>
        <div class="ws-stat-card"><i class="bi bi-trophy-fill" style="color:#fbbf24"></i><div class="ws-sc-val" id="wsVolume">0</div><div class="ws-sc-lbl">Vol (kg)</div></div>
      </div>

      <!-- Motivational tip -->
      <div class="ws-tip-card">
        <div class="ws-tip-label"><i class="bi bi-stars"></i> Coach Tip</div>
        <div class="ws-tip-text" id="wsTip">Focus on full range of motion. Control the weight on the way down.</div>
      </div>
    </div>
  </div>
</div>

<!-- WORKOUT SUMMARY OVERLAY -->
<div class="ws-summary-overlay" id="wsSummary">
  <div class="ws-summary-box">
    <div class="ws-sum-confetti" id="wsSumConfetti"></div>
    <div class="ws-sum-header">
      <div class="ws-sum-icon"><i class="bi bi-trophy-fill"></i></div>
      <h2 class="ws-sum-title">WORKOUT <span>COMPLETE!</span></h2>
      <p class="ws-sum-sub" id="wsSumPlanName">Upper Body Power</p>
    </div>
    <div class="ws-sum-stats">
      <div class="ws-sum-stat"><div class="ws-ss-val" id="wsSumTime">--</div><div class="ws-ss-lbl">Duration</div></div>
      <div class="ws-sum-stat"><div class="ws-ss-val" id="wsSumExercises">--</div><div class="ws-ss-lbl">Exercises</div></div>
      <div class="ws-sum-stat"><div class="ws-ss-val" id="wsSumSets">--</div><div class="ws-ss-lbl">Sets Done</div></div>
      <div class="ws-sum-stat"><div class="ws-ss-val" id="wsSumKcal">--</div><div class="ws-ss-lbl">kcal Burned</div></div>
    </div>
    <div class="ws-sum-prog">
      <div class="ws-sum-prog-label">Session Completion</div>
      <div class="ws-sum-prog-track"><div class="ws-sum-prog-fill" id="wsSumProgFill"></div></div>
      <div class="ws-sum-prog-pct" id="wsSumProgPct">0%</div>
    </div>
    <div class="ws-sum-actions">
      <button class="btn-solid" onclick="closeSummary()"><i class="bi bi-house-fill"></i> Back to Dashboard</button>
      <button class="btn-g" onclick="closeSummary(); openWorkoutSession('upper')"><i class="bi bi-arrow-repeat"></i> Do Again</button>
    </div>
  </div>
</div>

<!-- EDIT PROFILE MODAL -->
<div class="modal-overlay" id="editProfileModal">
<div class="modal-box" style="max-width:520px">
<button class="modal-close" onclick="closeModal('editProfileModal')">&times;</button>
<div class="m-title">EDIT <span style="color:var(--accent)">PROFILE</span></div>
<div class="edit-prof-photo-section">
<div class="edit-prof-avatar" id="editProfAvatar">
<span class="edit-prof-initial" id="editProfInitial"><%= initial %></span>
<img id="editProfImg" style="display:none" alt="Profile">
<label class="edit-prof-cam" for="editPhotoInput"><i class="bi bi-camera-fill"></i></label>
<input type="file" id="editPhotoInput" accept="image/*" style="display:none" onchange="handlePhotoUpload(this)">
</div>
<div style="font-size:.75rem;color:var(--gray);margin-top:.5rem">Click camera to upload</div>
</div>
<div class="edit-prof-fields">
<div class="edit-field"><label>Full Name</label><input type="text" id="editName" value="${member.name}" placeholder="Your name"></div>
<div class="edit-field"><label>Email Address</label><input type="email" id="editEmail" value="${member.email}" placeholder="your@email.com"></div>
<div class="edit-field"><label>Phone Number</label><input type="tel" id="editPhone" value="${empty member.phone ? '' : member.phone}" placeholder="+94 7X XXX XXXX"></div>
</div>
<button class="btn-solid" style="width:100%;padding:.9rem;font-size:.95rem;margin-top:1.5rem" onclick="saveProfile()"><i class="bi bi-check-lg"></i> Save Changes</button>
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="${pageContext.request.contextPath}/static/js/member-state.js?t=<%= new java.util.Date().getTime() %>"></script>
<script src="${pageContext.request.contextPath}/static/js/member-portal.js?t=<%= new java.util.Date().getTime() %>"></script>
<script>if(typeof ApexState!=='undefined')ApexState.updateUI();</script>
<script>
/* ── Share Functions ── */
function shareVia(platform) {
  var msg = '🏆 Check out my Apex Fitness achievements! Level 12 Fitness Warrior with 4 badges, 7-day streak & Rank #3! 💪';
  var url = window.location.origin + '/member-profile#achievements';
  var encoded = encodeURIComponent(msg);
  var encodedUrl = encodeURIComponent(url);
  var shareUrl = '';
  switch(platform) {
    case 'whatsapp':
      shareUrl = 'https://wa.me/?text=' + encodeURIComponent(msg + '\n' + url);
      break;
    case 'email':
      shareUrl = 'mailto:?subject=' + encodeURIComponent('My Apex Fitness Achievements') + '&body=' + encodeURIComponent(msg + '\n\n' + url);
      break;
    case 'facebook':
      shareUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + encodedUrl + '&quote=' + encoded;
      break;
    case 'twitter':
      shareUrl = 'https://twitter.com/intent/tweet?text=' + encoded + '&url=' + encodedUrl;
      break;
    case 'linkedin':
      shareUrl = 'https://www.linkedin.com/sharing/share-offsite/?url=' + encodedUrl;
      break;
    case 'copy':
      navigator.clipboard.writeText(msg + '\n' + url).then(function() {
        showToast('Link copied to clipboard! 📋');
      });
      closeModal('shareModal');
      return;
  }
  if (shareUrl) window.open(shareUrl, '_blank', 'width=600,height=500');
  closeModal('shareModal');
  showToast('Opening ' + platform + '... 🚀');
}
window.shareVia = shareVia;

/* ── PDF Generator ── */
function downloadAchievementsPDF() {
  var jsPDF = window.jspdf.jsPDF;
  var doc = new jsPDF('p', 'mm', 'a4');
  var W = 210, margin = 20, y = 0;
  var cW = W - margin * 2;

  // Colors
  var dark = [15, 17, 21];
  var accent = [200, 240, 61];
  var white = [255, 255, 255];
  var gray = [140, 140, 150];
  var purple = [167, 139, 250];
  var gold = [251, 191, 36];

  // Background
  doc.setFillColor(dark[0], dark[1], dark[2]);
  doc.rect(0, 0, W, 297, 'F');

  // Header bar
  doc.setFillColor(20, 22, 28);
  doc.rect(0, 0, W, 40, 'F');
  doc.setFillColor(accent[0], accent[1], accent[2]);
  doc.rect(0, 38, W, 2, 'F');

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.setTextColor(white[0], white[1], white[2]);
  doc.text('APEX', margin, 18);
  doc.setTextColor(accent[0], accent[1], accent[2]);
  doc.text('FITNESS', margin + 28, 18);

  doc.setFontSize(9);
  doc.setTextColor(gray[0], gray[1], gray[2]);
  doc.text('Achievement Report', margin, 28);
  doc.text(new Date().toLocaleDateString('en-US', {year:'numeric',month:'long',day:'numeric'}), W - margin, 28, {align:'right'});

  y = 52;

  // Member Info Box
  doc.setFillColor(25, 27, 33);
  doc.roundedRect(margin, y, cW, 28, 4, 4, 'F');
  doc.setDrawColor(40, 42, 50);
  doc.roundedRect(margin, y, cW, 28, 4, 4, 'S');

  doc.setFontSize(16);
  doc.setTextColor(white[0], white[1], white[2]);
  doc.setFont('helvetica', 'bold');
  doc.text('John Doe', margin + 8, y + 12);

  doc.setFontSize(9);
  doc.setTextColor(gold[0], gold[1], gold[2]);
  doc.text('Level 12 — Fitness Warrior', margin + 8, y + 20);

  doc.setTextColor(accent[0], accent[1], accent[2]);
  doc.text('2,340 / 3,000 XP', W - margin - 8, y + 12, {align:'right'});
  doc.setTextColor(gray[0], gray[1], gray[2]);
  doc.setFontSize(8);
  doc.text('78% to Level 13', W - margin - 8, y + 20, {align:'right'});

  y += 38;

  // Stats Row
  var stats = [
    {val:'47',label:'WORKOUTS',color:accent},
    {val:'4/8',label:'BADGES',color:accent},
    {val:'7',label:'DAY STREAK',color:[248,113,113]},
    {val:'#3',label:'RANK',color:[96,165,250]}
  ];
  var boxW = (cW - 9) / 4;
  stats.forEach(function(s, i) {
    var x = margin + i * (boxW + 3);
    doc.setFillColor(25, 27, 33);
    doc.roundedRect(x, y, boxW, 22, 3, 3, 'F');
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(s.color[0], s.color[1], s.color[2]);
    doc.text(s.val, x + boxW/2, y + 10, {align:'center'});
    doc.setFontSize(6);
    doc.setTextColor(gray[0], gray[1], gray[2]);
    doc.text(s.label, x + boxW/2, y + 17, {align:'center'});
  });

  y += 32;

  // Badges Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(white[0], white[1], white[2]);
  doc.text('BADGES', margin, y);
  doc.setFontSize(8);
  doc.setTextColor(gray[0], gray[1], gray[2]);
  doc.text('4 of 8 unlocked', W - margin, y, {align:'right'});
  y += 6;

  var badges = [
    {name:'First Blood',desc:'Completed 1st workout',unlocked:true},
    {name:'7-Day Streak',desc:'7 days straight',unlocked:true},
    {name:'Hydro King',desc:'3L water 5 days',unlocked:true},
    {name:'Deep Sleep',desc:'8 hours sleep',unlocked:true},
    {name:'30-Day Streak',desc:'7/30 days (23%)',unlocked:false},
    {name:'Iron Pusher',desc:'6,200/10,000 kg (62%)',unlocked:false},
    {name:'Cardio Bunny',desc:'32/50 km (64%)',unlocked:false},
    {name:'Apex Legend',desc:'4/12 months (33%)',unlocked:false}
  ];
  var bW = (cW - 6) / 2;
  badges.forEach(function(b, i) {
    var col = i % 2;
    var row = Math.floor(i / 2);
    var x = margin + col * (bW + 6);
    var by = y + row * 16;
    doc.setFillColor(25, 27, 33);
    doc.roundedRect(x, by, bW, 13, 3, 3, 'F');
    if (b.unlocked) {
      doc.setTextColor(accent[0], accent[1], accent[2]);
      doc.setFontSize(8);
      doc.text('✓', x + 5, by + 6);
    } else {
      doc.setTextColor(80, 80, 90);
      doc.setFontSize(8);
      doc.text('🔒', x + 5, by + 6);
    }
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(b.unlocked ? 255 : 100, b.unlocked ? 255 : 100, b.unlocked ? 255 : 110);
    doc.text(b.name, x + 14, by + 6);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(gray[0], gray[1], gray[2]);
    doc.text(b.desc, x + 14, by + 11);
  });

  y += 72;

  // Streak Section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(white[0], white[1], white[2]);
  doc.text('WEEKLY STREAK', margin, y);
  y += 6;

  var days = ['MON','TUE','WED','THU','FRI','SAT','SUN'];
  var dayW = (cW - 18) / 7;
  days.forEach(function(d, i) {
    var x = margin + i * (dayW + 3);
    doc.setFillColor(25, 30, 20);
    doc.roundedRect(x, y, dayW, 16, 2, 2, 'F');
    doc.setFontSize(6);
    doc.setTextColor(gray[0], gray[1], gray[2]);
    doc.text(d, x + dayW/2, y + 5, {align:'center'});
    doc.setFontSize(9);
    doc.setTextColor(accent[0], accent[1], accent[2]);
    doc.text('✓', x + dayW/2, y + 12, {align:'center'});
  });

  y += 28;

  // Leaderboard
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(white[0], white[1], white[2]);
  doc.text('LEADERBOARD', margin, y);
  y += 6;

  var leaders = [
    {rank:'1',name:'Alex Johnson',pts:'2,450',me:false},
    {rank:'2',name:'Sarah Connor',pts:'2,100',me:false},
    {rank:'3',name:'You (John Doe)',pts:'1,850',me:true},
    {rank:'4',name:'Mike Tyson',pts:'1,600',me:false},
    {rank:'5',name:'Bruce Lee',pts:'1,420',me:false}
  ];
  leaders.forEach(function(l) {
    if (l.me) {
      doc.setFillColor(25, 30, 20);
      doc.setDrawColor(accent[0], accent[1], accent[2]);
      doc.roundedRect(margin, y, cW, 10, 2, 2, 'FD');
    } else {
      doc.setFillColor(25, 27, 33);
      doc.roundedRect(margin, y, cW, 10, 2, 2, 'F');
    }
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(l.me ? accent[0] : 255, l.me ? accent[1] : 255, l.me ? accent[2] : 255);
    doc.text('#' + l.rank, margin + 6, y + 7);
    doc.setFont('helvetica', 'normal');
    doc.text(l.name, margin + 18, y + 7);
    doc.setTextColor(l.me ? accent[0] : gray[0], l.me ? accent[1] : gray[1], l.me ? accent[2] : gray[2]);
    doc.text(l.pts + ' XP', W - margin - 6, y + 7, {align:'right'});
    y += 13;
  });

  y += 8;

  // Footer
  doc.setFillColor(accent[0], accent[1], accent[2]);
  doc.rect(0, 285, W, 12, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('APEX FITNESS — Your Fitness Journey, Visualized', W/2, 292, {align:'center'});

  // Save
  doc.save('Apex_Fitness_Achievements.pdf');
  closeModal('shareModal');
  showToast('PDF downloaded successfully! 📄');
}
window.downloadAchievementsPDF = downloadAchievementsPDF;
</script>
</body></html>

